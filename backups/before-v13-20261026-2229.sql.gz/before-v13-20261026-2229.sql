--
-- PostgreSQL database dump
--

\restrict 192N2oB6AKhsJ0tPCT9b2Cpm5djJTUDdZPEkZqIuDOhd8BRRNbNOs5NPm6FjUfM

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: advances; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.advances (
    id bigint NOT NULL,
    advance_no character varying(32) NOT NULL,
    vin character varying(32) NOT NULL,
    credit_line_id bigint NOT NULL,
    amount bigint NOT NULL,
    paid_at timestamp with time zone,
    status character varying(16) NOT NULL,
    payment_ref character varying(64),
    idempotency_key character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    purchase_order_id bigint,
    payee_supplier_id bigint,
    payee_supplier_type character varying(24),
    payee_account_snapshot text,
    applicant character varying(64),
    reviewer character varying(64),
    reviewed_at timestamp with time zone,
    disburser character varying(64)
);


ALTER TABLE public.advances OWNER TO floorplan;

--
-- Name: COLUMN advances.payee_account_snapshot; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.advances.payee_account_snapshot IS '放款时冻结的收款方事实（不可变）；与下单时快照是两件事';


--
-- Name: COLUMN advances.applicant; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.advances.applicant IS '垫款申请人（自然人，来自令牌身份）';


--
-- Name: COLUMN advances.reviewer; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.advances.reviewer IS '垫款复核人（自然人，须≠申请人）';


--
-- Name: COLUMN advances.disburser; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.advances.disburser IS '支付人（自然人，须≠申请人且≠复核人）';


--
-- Name: advances_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.advances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.advances_id_seq OWNER TO floorplan;

--
-- Name: advances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.advances_id_seq OWNED BY public.advances.id;


--
-- Name: aging_plans; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.aging_plans (
    id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    rule_version character varying(16),
    first_trigger_date date,
    period_days integer,
    reduce_ratio numeric(5,4),
    reduce_amount bigint DEFAULT 0 NOT NULL,
    paid_periods integer DEFAULT 0 NOT NULL,
    next_due_date date,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL
);


ALTER TABLE public.aging_plans OWNER TO floorplan;

--
-- Name: aging_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.aging_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aging_plans_id_seq OWNER TO floorplan;

--
-- Name: aging_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.aging_plans_id_seq OWNED BY public.aging_plans.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.alerts (
    id bigint NOT NULL,
    dealer_id bigint,
    vin character varying(32),
    alert_type character varying(32) NOT NULL,
    severity character varying(8) NOT NULL,
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL,
    detail text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    handler character varying(64),
    handled_at timestamp with time zone,
    handle_note text
);


ALTER TABLE public.alerts OWNER TO floorplan;

--
-- Name: COLUMN alerts.handler; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.alerts.handler IS '告警处置人（自然人，来自令牌身份）';


--
-- Name: COLUMN alerts.handle_note; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.alerts.handle_note IS '处置说明：为什么这样处置，供事后复核';


--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alerts_id_seq OWNER TO floorplan;

--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: annual_reviews; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.annual_reviews (
    id bigint NOT NULL,
    review_no character varying(32) NOT NULL,
    dealer_id bigint NOT NULL,
    credit_line_id bigint,
    review_cycle character varying(16),
    status character varying(16) DEFAULT 'PENDING'::character varying NOT NULL,
    frozen_amount bigint DEFAULT 0 NOT NULL,
    result_note character varying(255),
    initiated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.annual_reviews OWNER TO floorplan;

--
-- Name: annual_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.annual_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.annual_reviews_id_seq OWNER TO floorplan;

--
-- Name: annual_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.annual_reviews_id_seq OWNED BY public.annual_reviews.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    biz_type character varying(32) NOT NULL,
    biz_id bigint NOT NULL,
    object_key character varying(256) NOT NULL,
    bucket character varying(64),
    region character varying(64),
    original_filename character varying(256),
    content_type character varying(64) NOT NULL,
    content_length bigint NOT NULL,
    sha256 character varying(64),
    etag character varying(64),
    object_lock_mode character varying(16),
    uploaded_by character varying(64),
    uploaded_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_attachment_lock CHECK (((object_lock_mode IS NULL) OR ((object_lock_mode)::text = ANY ((ARRAY['COMPLIANCE'::character varying, 'GOVERNANCE'::character varying])::text[]))))
);


ALTER TABLE public.attachments OWNER TO floorplan;

--
-- Name: TABLE attachments; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.attachments IS '附件元数据（文件本体存对象存储，数据库不存 BLOB）';


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO floorplan;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.audit_events (
    id bigint NOT NULL,
    actor character varying(64),
    actor_role character varying(32),
    action character varying(32) NOT NULL,
    target_type character varying(32),
    target_id character varying(64),
    before_snapshot text,
    after_snapshot text,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_events OWNER TO floorplan;

--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.audit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_events_id_seq OWNER TO floorplan;

--
-- Name: audit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.audit_events_id_seq OWNED BY public.audit_events.id;


--
-- Name: batch_runs; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.batch_runs (
    id bigint NOT NULL,
    job_name character varying(64) NOT NULL,
    biz_date date NOT NULL,
    status character varying(16) NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    error_detail text
);


ALTER TABLE public.batch_runs OWNER TO floorplan;

--
-- Name: batch_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.batch_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.batch_runs_id_seq OWNER TO floorplan;

--
-- Name: batch_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.batch_runs_id_seq OWNED BY public.batch_runs.id;


--
-- Name: collateral_evidence_links; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.collateral_evidence_links (
    id bigint NOT NULL,
    ledger_id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    evidence_type character varying(24) NOT NULL,
    ref_type character varying(16) DEFAULT 'INTERNAL'::character varying NOT NULL,
    ref_id character varying(64) NOT NULL,
    attachment_id bigint,
    event_at timestamp with time zone,
    note character varying(500),
    recorded_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.collateral_evidence_links OWNER TO floorplan;

--
-- Name: TABLE collateral_evidence_links; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.collateral_evidence_links IS '担保物证据链：合同·登记·放款·盘点·回款·处置按 VIN 串成可追溯链';


--
-- Name: COLUMN collateral_evidence_links.evidence_type; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_evidence_links.evidence_type IS '证据类型：CONTRACT/REGISTRATION_CERT/CANCELLATION_CERT/ADVANCE/INVENTORY_AUDIT/REPAYMENT/DISPOSAL/INSURANCE/REPURCHASE';


--
-- Name: COLUMN collateral_evidence_links.ref_type; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_evidence_links.ref_type IS '证据来源：INTERNAL=内部业务单据（ref_id 存单号）/ ATTACHMENT=附件（ref_id 存 attachments.id）';


--
-- Name: collateral_evidence_links_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.collateral_evidence_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collateral_evidence_links_id_seq OWNER TO floorplan;

--
-- Name: collateral_evidence_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.collateral_evidence_links_id_seq OWNED BY public.collateral_evidence_links.id;


--
-- Name: collateral_ledger; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.collateral_ledger (
    id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    dealer_id bigint NOT NULL,
    financed boolean DEFAULT false NOT NULL,
    financed_at timestamp with time zone,
    advance_no character varying(32),
    sold boolean DEFAULT false NOT NULL,
    sold_at timestamp with time zone,
    sold_flagged_by character varying(64),
    repaid boolean DEFAULT false NOT NULL,
    repaid_at timestamp with time zone,
    repaid_amount bigint,
    released boolean DEFAULT false NOT NULL,
    released_at timestamp with time zone,
    release_reason character varying(24),
    security_type character varying(24),
    security_status character varying(16) DEFAULT 'NONE'::character varying NOT NULL,
    required_account_ref character varying(32),
    account_checked boolean DEFAULT false NOT NULL,
    account_checked_at timestamp with time zone,
    account_checked_by character varying(64),
    last_audit_date date,
    audit_mismatch_count integer DEFAULT 0 NOT NULL,
    last_audit_by character varying(64),
    disposal_case_no character varying(32),
    disposed_at timestamp with time zone,
    registration_due boolean DEFAULT false NOT NULL,
    registration_note character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.collateral_ledger OWNER TO floorplan;

--
-- Name: TABLE collateral_ledger; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.collateral_ledger IS '担保物台账：按 VIN 一台一行，四个状态独立标记（已放款/已售出/已回款/已解除担保）';


--
-- Name: COLUMN collateral_ledger.vin; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_ledger.vin IS '车架号：台账唯一主键，一台一行';


--
-- Name: COLUMN collateral_ledger.financed; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_ledger.financed IS '已放款：垫款 PAID（银行回调确认）时置真';


--
-- Name: COLUMN collateral_ledger.sold; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_ledger.sold IS '已售出：标记售出时置真，同时触发库存释放规则';


--
-- Name: COLUMN collateral_ledger.repaid; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_ledger.repaid IS '已回款：还款核销时置真';


--
-- Name: COLUMN collateral_ledger.released; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_ledger.released IS '已解除担保：结清或处置完成后置真';


--
-- Name: COLUMN collateral_ledger.required_account_ref; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_ledger.required_account_ref IS '要求的回款账户引用码（不存明文账号）';


--
-- Name: COLUMN collateral_ledger.registration_due; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_ledger.registration_due IS '存在待处理的登记/抹消事项（需人工处置）';


--
-- Name: collateral_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.collateral_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collateral_ledger_id_seq OWNER TO floorplan;

--
-- Name: collateral_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.collateral_ledger_id_seq OWNED BY public.collateral_ledger.id;


--
-- Name: collateral_registration_batches; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.collateral_registration_batches (
    id bigint NOT NULL,
    batch_no character varying(32) NOT NULL,
    registration_no character varying(64),
    registration_type character varying(24) DEFAULT 'ASSIGNMENT'::character varying NOT NULL,
    perfection_method character varying(24) DEFAULT 'REGISTRATION'::character varying NOT NULL,
    registry_office character varying(128),
    registered_at timestamp with time zone,
    expires_at timestamp with time zone,
    contract_attachment_id bigint,
    contract_no character varying(64),
    contract_signed_at timestamp with time zone,
    certificate_attachment_id bigint,
    certificate_no character varying(64),
    certificate_uploaded_at timestamp with time zone,
    cancellation_status character varying(16) DEFAULT 'NOT_REQUIRED'::character varying NOT NULL,
    cancellation_no character varying(64),
    cancellation_applied_at timestamp with time zone,
    cancellation_completed_at timestamp with time zone,
    cancellation_certificate_attachment_id bigint,
    cancellation_requested_by character varying(64),
    cancellation_note character varying(500),
    priority_rank integer,
    co_signed_by character varying(128),
    vehicle_count integer DEFAULT 0 NOT NULL,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_cancel_status CHECK (((cancellation_status)::text = ANY ((ARRAY['NOT_DUE'::character varying, 'NOT_REQUIRED'::character varying, 'REQUESTED'::character varying, 'APPLIED'::character varying, 'DONE'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.collateral_registration_batches OWNER TO floorplan;

--
-- Name: TABLE collateral_registration_batches; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.collateral_registration_batches IS '担保登记批次：一批车一次法务局登记，共享一个登记编号与一份担保合同';


--
-- Name: COLUMN collateral_registration_batches.registration_no; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_registration_batches.registration_no IS '法务省登记编号（字符串；东京法务局动产登记课出具）';


--
-- Name: COLUMN collateral_registration_batches.expires_at; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_registration_batches.expires_at IS '登记失效日：让渡担保登记 5 年期限且不可续展，到期须重新设定';


--
-- Name: COLUMN collateral_registration_batches.contract_attachment_id; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_registration_batches.contract_attachment_id IS '让渡担保合同附件（S3）——担保权成立的实体依据';


--
-- Name: COLUMN collateral_registration_batches.certificate_attachment_id; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_registration_batches.certificate_attachment_id IS '登记事项证明书附件（謄本）——担保权成立的公示依据';


--
-- Name: COLUMN collateral_registration_batches.cancellation_status; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_registration_batches.cancellation_status IS '抹消状态：NOT_DUE=未到抹消时点（担保存续中，将来需抹消）/ REQUESTED=待共同申请 / APPLIED=已提交 / DONE=抹消完成 / NOT_REQUIRED=确定无需抹消 / CANCELLED=免于抹消';


--
-- Name: collateral_registration_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.collateral_registration_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collateral_registration_batches_id_seq OWNER TO floorplan;

--
-- Name: collateral_registration_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.collateral_registration_batches_id_seq OWNED BY public.collateral_registration_batches.id;


--
-- Name: collateral_registration_items; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.collateral_registration_items (
    id bigint NOT NULL,
    batch_id bigint NOT NULL,
    ledger_id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.collateral_registration_items OWNER TO floorplan;

--
-- Name: TABLE collateral_registration_items; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.collateral_registration_items IS '登记批次 ↔ 车辆明细：同一次登记覆盖多台车';


--
-- Name: COLUMN collateral_registration_items.ledger_id; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.collateral_registration_items.ledger_id IS '对应担保物台账行';


--
-- Name: collateral_registration_items_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.collateral_registration_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collateral_registration_items_id_seq OWNER TO floorplan;

--
-- Name: collateral_registration_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.collateral_registration_items_id_seq OWNED BY public.collateral_registration_items.id;


--
-- Name: credit_lines; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.credit_lines (
    id bigint NOT NULL,
    dealer_id bigint NOT NULL,
    approved_limit bigint NOT NULL,
    used_amount bigint DEFAULT 0 NOT NULL,
    frozen_amount bigint DEFAULT 0 NOT NULL,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_credit_within_limit CHECK (((used_amount + frozen_amount) <= approved_limit))
);


ALTER TABLE public.credit_lines OWNER TO floorplan;

--
-- Name: credit_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.credit_lines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_lines_id_seq OWNER TO floorplan;

--
-- Name: credit_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.credit_lines_id_seq OWNED BY public.credit_lines.id;


--
-- Name: curtailment_payments; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.curtailment_payments (
    id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    period_no integer NOT NULL,
    amount bigint NOT NULL,
    paid_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key character varying(64),
    operator character varying(64)
);


ALTER TABLE public.curtailment_payments OWNER TO floorplan;

--
-- Name: curtailment_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.curtailment_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.curtailment_payments_id_seq OWNER TO floorplan;

--
-- Name: curtailment_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.curtailment_payments_id_seq OWNED BY public.curtailment_payments.id;


--
-- Name: dealer_bank_accounts; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.dealer_bank_accounts (
    id bigint NOT NULL,
    dealer_id bigint NOT NULL,
    bank_name character varying(64) NOT NULL,
    account_holder character varying(128) NOT NULL,
    account_no_cipher text NOT NULL,
    account_no_mask character varying(32) NOT NULL,
    account_ref character varying(32),
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    effective_from date,
    effective_to date,
    reviewer character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_dealer_account_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'PENDING_REVIEW'::character varying, 'FROZEN'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.dealer_bank_accounts OWNER TO floorplan;

--
-- Name: TABLE dealer_bank_accounts; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.dealer_bank_accounts IS '经销商结算账户（场景C：库存抵押周转回款至经销商自身账户）';


--
-- Name: dealer_bank_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.dealer_bank_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dealer_bank_accounts_id_seq OWNER TO floorplan;

--
-- Name: dealer_bank_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.dealer_bank_accounts_id_seq OWNED BY public.dealer_bank_accounts.id;


--
-- Name: dealers; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.dealers (
    id bigint NOT NULL,
    dealer_code character varying(32) NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    risk_grade character varying(8),
    business_years integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contact_person character varying(64),
    contact_phone character varying(32),
    address character varying(255),
    remark character varying(500)
);


ALTER TABLE public.dealers OWNER TO floorplan;

--
-- Name: COLUMN dealers.contact_person; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.dealers.contact_person IS '联系人（授信准入登记的接口人）';


--
-- Name: COLUMN dealers.contact_phone; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.dealers.contact_phone IS '联系电话';


--
-- Name: COLUMN dealers.address; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.dealers.address IS '营业地址';


--
-- Name: COLUMN dealers.remark; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.dealers.remark IS '备注';


--
-- Name: dealers_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.dealers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dealers_id_seq OWNER TO floorplan;

--
-- Name: dealers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.dealers_id_seq OWNED BY public.dealers.id;


--
-- Name: disposal_cases; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.disposal_cases (
    id bigint NOT NULL,
    case_no character varying(32) NOT NULL,
    vin character varying(32) NOT NULL,
    dealer_id bigint,
    credit_line_id bigint,
    reason character varying(64),
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL,
    repossessed_at timestamp with time zone,
    proceeds bigint DEFAULT 0 NOT NULL,
    loss_amount bigint DEFAULT 0 NOT NULL,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone
);


ALTER TABLE public.disposal_cases OWNER TO floorplan;

--
-- Name: disposal_cases_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.disposal_cases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.disposal_cases_id_seq OWNER TO floorplan;

--
-- Name: disposal_cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.disposal_cases_id_seq OWNED BY public.disposal_cases.id;


--
-- Name: domain_events; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.domain_events (
    id bigint NOT NULL,
    event_type character varying(48) NOT NULL,
    source character varying(32) NOT NULL,
    dealer_id bigint,
    vin character varying(32),
    biz_key character varying(128) NOT NULL,
    payload jsonb NOT NULL,
    ref_type character varying(32),
    ref_id character varying(64),
    event_time timestamp with time zone NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(16) DEFAULT 'RECEIVED'::character varying NOT NULL,
    error_detail text,
    processed_at timestamp with time zone
);


ALTER TABLE public.domain_events OWNER TO floorplan;

--
-- Name: TABLE domain_events; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.domain_events IS '统一事件总线：外部与人工数据统一入口，保证幂等、可重放、可对账';


--
-- Name: domain_events_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.domain_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.domain_events_id_seq OWNER TO floorplan;

--
-- Name: domain_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.domain_events_id_seq OWNED BY public.domain_events.id;


--
-- Name: extension_requests; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.extension_requests (
    id bigint NOT NULL,
    request_no character varying(32) NOT NULL,
    vin character varying(32) NOT NULL,
    ext_days integer NOT NULL,
    reason character varying(128),
    status character varying(16) DEFAULT 'APPROVED'::character varying NOT NULL,
    original_due date,
    new_due date,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.extension_requests OWNER TO floorplan;

--
-- Name: extension_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.extension_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.extension_requests_id_seq OWNER TO floorplan;

--
-- Name: extension_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.extension_requests_id_seq OWNED BY public.extension_requests.id;


--
-- Name: financing_lien_checks; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.financing_lien_checks (
    id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    check_source character varying(24) NOT NULL,
    encumbered boolean DEFAULT false NOT NULL,
    checked_at timestamp with time zone DEFAULT now() NOT NULL,
    note character varying(255),
    operator character varying(64)
);


ALTER TABLE public.financing_lien_checks OWNER TO floorplan;

--
-- Name: financing_lien_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.financing_lien_checks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financing_lien_checks_id_seq OWNER TO floorplan;

--
-- Name: financing_lien_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.financing_lien_checks_id_seq OWNED BY public.financing_lien_checks.id;


--
-- Name: financing_terms; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.financing_terms (
    id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    change_type character varying(24) NOT NULL,
    old_maturity_date date,
    new_maturity_date date NOT NULL,
    old_grace_days integer,
    new_grace_days integer,
    term_source character varying(16) NOT NULL,
    source_ref character varying(128),
    reason character varying(500),
    operator character varying(64) NOT NULL,
    operated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.financing_terms OWNER TO floorplan;

--
-- Name: TABLE financing_terms; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.financing_terms IS '融资担保期限变更历史：原始约定 + 展期链 + 人工修订，全程可追溯';


--
-- Name: COLUMN financing_terms.source_ref; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.financing_terms.source_ref IS '期限依据（合同附件ID / 登记批次号 / 工单号）——人工读合同路径必填';


--
-- Name: financing_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.financing_terms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financing_terms_id_seq OWNER TO floorplan;

--
-- Name: financing_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.financing_terms_id_seq OWNED BY public.financing_terms.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO floorplan;

--
-- Name: holidays; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.holidays (
    biz_date date NOT NULL,
    is_business_day boolean NOT NULL,
    note character varying(128)
);


ALTER TABLE public.holidays OWNER TO floorplan;

--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.import_batches (
    id bigint NOT NULL,
    channel character varying(16) NOT NULL,
    filename character varying(255),
    file_hash character varying(64),
    total_rows integer DEFAULT 0 NOT NULL,
    accepted_rows integer DEFAULT 0 NOT NULL,
    rejected_rows integer DEFAULT 0 NOT NULL,
    total_amount bigint DEFAULT 0 NOT NULL,
    status character varying(16) DEFAULT 'PREVIEWED'::character varying NOT NULL,
    operator character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    committed_at timestamp with time zone,
    CONSTRAINT ck_import_batch_channel CHECK (((channel)::text = ANY ((ARRAY['API'::character varying, 'EXCEL'::character varying])::text[]))),
    CONSTRAINT ck_import_batch_status CHECK (((status)::text = ANY ((ARRAY['PREVIEWED'::character varying, 'COMMITTED'::character varying, 'REJECTED'::character varying])::text[])))
);


ALTER TABLE public.import_batches OWNER TO floorplan;

--
-- Name: TABLE import_batches; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.import_batches IS '采购清单导入批次（行级结果留痕：成功/失败数、文件哈希、操作人）';


--
-- Name: import_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.import_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.import_batches_id_seq OWNER TO floorplan;

--
-- Name: import_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.import_batches_id_seq OWNED BY public.import_batches.id;


--
-- Name: import_row_errors; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.import_row_errors (
    id bigint NOT NULL,
    batch_id bigint NOT NULL,
    row_no integer NOT NULL,
    field_name character varying(64),
    reason character varying(500) NOT NULL,
    raw_value character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.import_row_errors OWNER TO floorplan;

--
-- Name: TABLE import_row_errors; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.import_row_errors IS '导入行级错误明细（行号+字段+原因，可下载修正后重传）';


--
-- Name: import_row_errors_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.import_row_errors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.import_row_errors_id_seq OWNER TO floorplan;

--
-- Name: import_row_errors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.import_row_errors_id_seq OWNED BY public.import_row_errors.id;


--
-- Name: insurance_policies; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.insurance_policies (
    id bigint NOT NULL,
    policy_no character varying(64) NOT NULL,
    vin character varying(32) NOT NULL,
    insurer character varying(128),
    insured_amount bigint DEFAULT 0 NOT NULL,
    start_date date,
    end_date date,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    claimed_amount bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.insurance_policies OWNER TO floorplan;

--
-- Name: insurance_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.insurance_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.insurance_policies_id_seq OWNER TO floorplan;

--
-- Name: insurance_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.insurance_policies_id_seq OWNED BY public.insurance_policies.id;


--
-- Name: interest_ledger; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.interest_ledger (
    id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    biz_date date NOT NULL,
    principal_balance bigint NOT NULL,
    daily_interest bigint NOT NULL,
    rate_snapshot numeric(7,4),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.interest_ledger OWNER TO floorplan;

--
-- Name: interest_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.interest_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interest_ledger_id_seq OWNER TO floorplan;

--
-- Name: interest_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.interest_ledger_id_seq OWNED BY public.interest_ledger.id;


--
-- Name: interest_ledger_archive; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.interest_ledger_archive (
    id bigint DEFAULT nextval('public.interest_ledger_id_seq'::regclass) NOT NULL,
    vin character varying(32) NOT NULL,
    biz_date date NOT NULL,
    principal_balance bigint NOT NULL,
    daily_interest bigint NOT NULL,
    rate_snapshot numeric(7,4),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.interest_ledger_archive OWNER TO floorplan;

--
-- Name: payoff_certificates; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.payoff_certificates (
    id bigint NOT NULL,
    cert_no character varying(32) NOT NULL,
    vin character varying(32) NOT NULL,
    principal bigint DEFAULT 0 NOT NULL,
    interest bigint DEFAULT 0 NOT NULL,
    total_amount bigint DEFAULT 0 NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    operator character varying(64)
);


ALTER TABLE public.payoff_certificates OWNER TO floorplan;

--
-- Name: payoff_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.payoff_certificates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payoff_certificates_id_seq OWNER TO floorplan;

--
-- Name: payoff_certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.payoff_certificates_id_seq OWNED BY public.payoff_certificates.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.purchase_orders (
    id bigint NOT NULL,
    order_no character varying(64) NOT NULL,
    dealer_id bigint NOT NULL,
    credit_line_id bigint,
    supplier_id bigint,
    supplier_type character varying(24) NOT NULL,
    payee_account_id bigint NOT NULL,
    payee_account_snapshot text,
    total_amount bigint DEFAULT 0 NOT NULL,
    vehicle_count integer DEFAULT 0 NOT NULL,
    purchased_at date,
    evidence_no character varying(64),
    evidence_attachment_id bigint,
    status character varying(16) DEFAULT 'CONFIRMED'::character varying NOT NULL,
    ingest_channel character varying(16) NOT NULL,
    import_batch_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_po_amount CHECK ((total_amount >= 0)),
    CONSTRAINT ck_po_channel CHECK (((ingest_channel)::text = ANY ((ARRAY['API'::character varying, 'EXCEL'::character varying])::text[]))),
    CONSTRAINT ck_po_status CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'CONFIRMED'::character varying, 'DISBURSED'::character varying, 'SETTLED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT ck_po_supplier_type CHECK (((supplier_type)::text = ANY ((ARRAY['MAKER_SALES_CO'::character varying, 'REGIONAL_AGENCY'::character varying, 'WHOLESALER'::character varying, 'AUCTION'::character varying, 'USED_WHOLESALER'::character varying, 'DEALER_SELF'::character varying])::text[])))
);


ALTER TABLE public.purchase_orders OWNER TO floorplan;

--
-- Name: TABLE purchase_orders; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.purchase_orders IS '采购订单主单（放款前置锚点；两条导入通道产出同一份主单）';


--
-- Name: COLUMN purchase_orders.supplier_type; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.purchase_orders.supplier_type IS '上游类型；payee_mode 由它派生，不可人工覆盖';


--
-- Name: COLUMN purchase_orders.payee_account_snapshot; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.purchase_orders.payee_account_snapshot IS '下单时账户快照（与放款时快照不是同一份事实）';


--
-- Name: COLUMN purchase_orders.ingest_channel; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.purchase_orders.ingest_channel IS '导入通道：API 直连 / EXCEL 批量';


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.purchase_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_orders_id_seq OWNER TO floorplan;

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: rating_configs; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.rating_configs (
    grade character varying(8) NOT NULL,
    grade_name character varying(64),
    rate_surcharge numeric(6,4) DEFAULT 0 NOT NULL,
    allowed boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    remark character varying(255),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by character varying(64)
);


ALTER TABLE public.rating_configs OWNER TO floorplan;

--
-- Name: repayments; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.repayments (
    id bigint NOT NULL,
    repayment_no character varying(32) NOT NULL,
    vin character varying(32) NOT NULL,
    principal bigint NOT NULL,
    interest bigint NOT NULL,
    total_amount bigint NOT NULL,
    settled_at timestamp with time zone,
    operator_id bigint,
    idempotency_key character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    repayment_type character varying(16) DEFAULT 'FULL'::character varying NOT NULL,
    account_ref character varying(32),
    designated_use boolean DEFAULT false NOT NULL
);


ALTER TABLE public.repayments OWNER TO floorplan;

--
-- Name: COLUMN repayments.account_ref; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.repayments.account_ref IS '回款账户引用码（对应经销商结算账户，用于库存释放规则核验）';


--
-- Name: COLUMN repayments.designated_use; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.repayments.designated_use IS '是否被指定专用于偿还本台垫款（库存释放规则要求）';


--
-- Name: repayments_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.repayments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repayments_id_seq OWNER TO floorplan;

--
-- Name: repayments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.repayments_id_seq OWNED BY public.repayments.id;


--
-- Name: repurchase_requests; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.repurchase_requests (
    id bigint NOT NULL,
    request_no character varying(32) NOT NULL,
    vin character varying(32) NOT NULL,
    dealer_id bigint,
    credit_line_id bigint,
    reason character varying(128),
    status character varying(16) DEFAULT 'REQUESTED'::character varying NOT NULL,
    repurchase_amount bigint DEFAULT 0 NOT NULL,
    fulfilled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.repurchase_requests OWNER TO floorplan;

--
-- Name: repurchase_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.repurchase_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repurchase_requests_id_seq OWNER TO floorplan;

--
-- Name: repurchase_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.repurchase_requests_id_seq OWNED BY public.repurchase_requests.id;


--
-- Name: risk_alerts; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.risk_alerts (
    id bigint NOT NULL,
    alert_code character varying(48) NOT NULL,
    severity character varying(8) NOT NULL,
    dealer_id bigint,
    vin character varying(32),
    batch_id bigint,
    metric_value numeric(18,4),
    threshold_value numeric(18,4),
    detail text,
    evidence_refs jsonb,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    occurrence_count integer DEFAULT 1 NOT NULL,
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL
);


ALTER TABLE public.risk_alerts OWNER TO floorplan;

--
-- Name: TABLE risk_alerts; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.risk_alerts IS '风险预警实例：规则引擎产出，带阈值快照与去重计数';


--
-- Name: COLUMN risk_alerts.threshold_value; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.risk_alerts.threshold_value IS '触发时的阈值快照——阈值可配置，历史预警须能复现当时依据';


--
-- Name: risk_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.risk_alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_alerts_id_seq OWNER TO floorplan;

--
-- Name: risk_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.risk_alerts_id_seq OWNED BY public.risk_alerts.id;


--
-- Name: risk_concentration_snapshots; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.risk_concentration_snapshots (
    id bigint NOT NULL,
    biz_date date NOT NULL,
    dimension character varying(16) NOT NULL,
    dimension_key character varying(128) NOT NULL,
    exposure numeric(18,2) NOT NULL,
    total_exposure numeric(18,2) NOT NULL,
    ratio numeric(10,6) NOT NULL,
    vehicle_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.risk_concentration_snapshots OWNER TO floorplan;

--
-- Name: TABLE risk_concentration_snapshots; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.risk_concentration_snapshots IS '集中度每日快照：车型/品牌/经销商/区域敞口占比趋势';


--
-- Name: risk_concentration_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.risk_concentration_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_concentration_snapshots_id_seq OWNER TO floorplan;

--
-- Name: risk_concentration_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.risk_concentration_snapshots_id_seq OWNED BY public.risk_concentration_snapshots.id;


--
-- Name: risk_rules; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.risk_rules (
    id bigint NOT NULL,
    rule_code character varying(48) NOT NULL,
    metric character varying(32) NOT NULL,
    threshold_type character varying(16) NOT NULL,
    threshold_value numeric(18,4) NOT NULL,
    unit character varying(16),
    severity character varying(8) NOT NULL,
    window_days integer,
    enabled boolean DEFAULT true NOT NULL,
    applies_to character varying(16) DEFAULT 'ALL'::character varying NOT NULL,
    updated_by character varying(64),
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.risk_rules OWNER TO floorplan;

--
-- Name: TABLE risk_rules; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.risk_rules IS '预警规则与阈值配置：后台可改，即时生效，勿写死在代码里';


--
-- Name: risk_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.risk_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_rules_id_seq OWNER TO floorplan;

--
-- Name: risk_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.risk_rules_id_seq OWNED BY public.risk_rules.id;


--
-- Name: security_records; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.security_records (
    id bigint NOT NULL,
    vin character varying(32) NOT NULL,
    security_type character varying(24) NOT NULL,
    reg_no character varying(64),
    owner_name character varying(128),
    set_date date,
    release_date date,
    doc_status character varying(16),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.security_records OWNER TO floorplan;

--
-- Name: security_records_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.security_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.security_records_id_seq OWNER TO floorplan;

--
-- Name: security_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.security_records_id_seq OWNED BY public.security_records.id;


--
-- Name: supplier_bank_accounts; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.supplier_bank_accounts (
    id bigint NOT NULL,
    supplier_id bigint NOT NULL,
    bank_name character varying(64) NOT NULL,
    account_holder character varying(128) NOT NULL,
    account_no_cipher text NOT NULL,
    account_no_mask character varying(32) NOT NULL,
    account_ref character varying(32),
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    effective_from date,
    effective_to date,
    reviewer character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_supplier_account_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'PENDING_REVIEW'::character varying, 'FROZEN'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.supplier_bank_accounts OWNER TO floorplan;

--
-- Name: TABLE supplier_bank_accounts; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.supplier_bank_accounts IS '上游收款账户（账号密文落库，对外只返掩码；account_ref 供导入引用）';


--
-- Name: supplier_bank_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.supplier_bank_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_bank_accounts_id_seq OWNER TO floorplan;

--
-- Name: supplier_bank_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.supplier_bank_accounts_id_seq OWNED BY public.supplier_bank_accounts.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.suppliers (
    id bigint NOT NULL,
    supplier_code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    supplier_type character varying(24) NOT NULL,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    risk_grade character varying(8),
    guarantee_ability character varying(16),
    contact_person character varying(64),
    contact_phone character varying(32),
    remark character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_supplier_guarantee CHECK (((guarantee_ability IS NULL) OR ((guarantee_ability)::text = ANY ((ARRAY['STRONG'::character varying, 'LIMITED'::character varying, 'NONE'::character varying])::text[])))),
    CONSTRAINT ck_supplier_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'SUSPENDED'::character varying, 'TERMINATED'::character varying])::text[]))),
    CONSTRAINT ck_supplier_type CHECK (((supplier_type)::text = ANY ((ARRAY['MAKER_SALES_CO'::character varying, 'REGIONAL_AGENCY'::character varying, 'WHOLESALER'::character varying, 'AUCTION'::character varying, 'USED_WHOLESALER'::character varying, 'DEALER_SELF'::character varying])::text[])))
);


ALTER TABLE public.suppliers OWNER TO floorplan;

--
-- Name: TABLE suppliers; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.suppliers IS '上游主数据（制造商销售公司/区域总代理/批发公司/拍卖行/中古批发商/经销商自身）';


--
-- Name: COLUMN suppliers.supplier_type; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.suppliers.supplier_type IS '上游类型，派生打款模式：DIRECT_PAY(除DEALER_SELF) / SELF_PAY(DEALER_SELF)';


--
-- Name: COLUMN suppliers.guarantee_ability; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.suppliers.guarantee_ability IS '回购/担保能力：STRONG强 / LIMITED有限 / NONE无——不可按上游类型一刀切';


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_id_seq OWNER TO floorplan;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.user_roles (
    id bigint NOT NULL,
    username character varying(64) NOT NULL,
    role_code character varying(40) NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    granted_at timestamp without time zone DEFAULT now() NOT NULL,
    granted_by character varying(64),
    CONSTRAINT ck_user_role_code CHECK (((role_code)::text = ANY ((ARRAY['SYSTEM_ADMIN'::character varying, 'CREDIT_REVIEWER'::character varying, 'PURCHASE_OPERATOR'::character varying, 'PURCHASE_REVIEWER'::character varying, 'BUSINESS_OPERATOR'::character varying, 'FUNDING_REVIEWER'::character varying, 'FUNDING_CASHIER'::character varying, 'COLLATERAL_OFFICER'::character varying, 'POST_LENDING_MANAGER'::character varying, 'COLLECTION_OFFICER'::character varying, 'SETTLEMENT_OFFICER'::character varying, 'DISPOSAL_OFFICER'::character varying, 'RISK_ADVISORY_OFFICER'::character varying, 'READONLY_USER'::character varying])::text[])))
);


ALTER TABLE public.user_roles OWNER TO floorplan;

--
-- Name: TABLE user_roles; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.user_roles IS '用户角色关联表：一人多岗，角色决定有效权限点';


--
-- Name: COLUMN user_roles.role_code; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.user_roles.role_code IS 'UserRole 枚举名，须与 domain 层 UserRole 保持一致';


--
-- Name: COLUMN user_roles.is_primary; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.user_roles.is_primary IS '主角色标记；每人至多一条 is_primary=TRUE';


--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.user_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_roles_id_seq OWNER TO floorplan;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(100) NOT NULL,
    display_name character varying(64),
    role character varying(40) DEFAULT 'USER'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO floorplan;

--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.users.role IS '主角色（UserRole 枚举名）；完整角色集合见 user_roles 表';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO floorplan;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicle_units; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.vehicle_units (
    vin character varying(32) NOT NULL,
    dealer_id bigint NOT NULL,
    credit_line_id bigint,
    advance_id bigint,
    brand character varying(64),
    model character varying(64),
    model_year integer,
    mileage integer,
    color character varying(32),
    vehicle_type character varying(32),
    supplier_name character varying(128),
    purchase_channel character varying(16),
    invoice_amount bigint DEFAULT 0 NOT NULL,
    advance_amount bigint DEFAULT 0 NOT NULL,
    advance_ratio numeric(5,4),
    advanced_at date,
    principal_balance bigint DEFAULT 0 NOT NULL,
    paid_principal bigint DEFAULT 0 NOT NULL,
    annual_rate numeric(7,4),
    rate_type character varying(16),
    accrued_interest bigint DEFAULT 0 NOT NULL,
    last_interest_date date,
    stock_in_date date,
    sold_at date,
    settle_due_date date,
    settled_at date,
    aging_days integer DEFAULT 0 NOT NULL,
    turnover_days integer,
    status character varying(24) NOT NULL,
    security_type character varying(24),
    security_status character varying(16),
    overdue_days integer DEFAULT 0 NOT NULL,
    risk_level character varying(8),
    oot_suspected boolean DEFAULT false NOT NULL,
    last_audit_date date,
    audit_mismatch_count integer DEFAULT 0 NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    purchase_order_id bigint,
    maturity_date date,
    grace_period_days integer,
    overdue_rate numeric(10,6),
    term_source character varying(16),
    term_confirmed_at timestamp with time zone,
    term_confirmed_by character varying(64),
    residual_value_estimated numeric(18,2),
    residual_value_source character varying(16),
    residual_value_at timestamp with time zone
);


ALTER TABLE public.vehicle_units OWNER TO floorplan;

--
-- Name: COLUMN vehicle_units.maturity_date; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.maturity_date IS '融资担保期限到期日（合同约定）——逾期判定与罚息计时的基准';


--
-- Name: COLUMN vehicle_units.grace_period_days; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.grace_period_days IS '合同约定的宽限期（天）；逾期自 到期日+宽限期 起算';


--
-- Name: COLUMN vehicle_units.overdue_rate; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.overdue_rate IS '逾期罚息年利率（可空=沿用基准利率）';


--
-- Name: COLUMN vehicle_units.term_source; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.term_source IS '期限来源：CONTRACT 合同录入 / REGISTRATION 登记带出 / MANUAL_REVIEW 人工读合同 / INFERRED 系统推断 / UNKNOWN 未知';


--
-- Name: COLUMN vehicle_units.term_confirmed_at; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.term_confirmed_at IS '期限确认时间';


--
-- Name: COLUMN vehicle_units.term_confirmed_by; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.term_confirmed_by IS '期限确认人（自然人；人工读合同的路径必填）';


--
-- Name: COLUMN vehicle_units.residual_value_estimated; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.residual_value_estimated IS '估算残值（一阶段：车龄+里程折旧曲线）——仅用于预警，不作处置定价依据';


--
-- Name: COLUMN vehicle_units.residual_value_source; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.vehicle_units.residual_value_source IS '残值来源：ESTIMATED 估算 / MARKET 行情接入 / MANUAL 人工估价';


--
-- Name: work_order_actions; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.work_order_actions (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    action_type character varying(32) NOT NULL,
    action_data jsonb,
    attachment_id bigint,
    operator character varying(64) NOT NULL,
    operated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.work_order_actions OWNER TO floorplan;

--
-- Name: work_order_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.work_order_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.work_order_actions_id_seq OWNER TO floorplan;

--
-- Name: work_order_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.work_order_actions_id_seq OWNED BY public.work_order_actions.id;


--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: floorplan
--

CREATE TABLE public.work_orders (
    id bigint NOT NULL,
    order_no character varying(32) NOT NULL,
    order_type character varying(32) NOT NULL,
    source_alert_id bigint,
    dealer_id bigint,
    vin character varying(32),
    batch_id bigint,
    severity character varying(8) NOT NULL,
    priority character varying(8) NOT NULL,
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL,
    assignee character varying(64),
    sla_due_at timestamp with time zone NOT NULL,
    sla_breached boolean DEFAULT false NOT NULL,
    resolution text,
    resolution_code character varying(32),
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    acknowledged_at timestamp with time zone,
    resolved_at timestamp with time zone,
    CONSTRAINT chk_wo_status CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'ACKNOWLEDGED'::character varying, 'IN_PROGRESS'::character varying, 'PENDING_EXTERNAL'::character varying, 'RESOLVED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.work_orders OWNER TO floorplan;

--
-- Name: TABLE work_orders; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON TABLE public.work_orders IS '贷后工单：异常分派给贷后人员，带 SLA 与处理记录';


--
-- Name: COLUMN work_orders.sla_due_at; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON COLUMN public.work_orders.sla_due_at IS '处理时限（按工作日历计算——日本节假日不能按自然日算）';


--
-- Name: work_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: floorplan
--

CREATE SEQUENCE public.work_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.work_orders_id_seq OWNER TO floorplan;

--
-- Name: work_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: floorplan
--

ALTER SEQUENCE public.work_orders_id_seq OWNED BY public.work_orders.id;


--
-- Name: advances id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.advances ALTER COLUMN id SET DEFAULT nextval('public.advances_id_seq'::regclass);


--
-- Name: aging_plans id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.aging_plans ALTER COLUMN id SET DEFAULT nextval('public.aging_plans_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: annual_reviews id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.annual_reviews ALTER COLUMN id SET DEFAULT nextval('public.annual_reviews_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: audit_events id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.audit_events ALTER COLUMN id SET DEFAULT nextval('public.audit_events_id_seq'::regclass);


--
-- Name: batch_runs id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.batch_runs ALTER COLUMN id SET DEFAULT nextval('public.batch_runs_id_seq'::regclass);


--
-- Name: collateral_evidence_links id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_evidence_links ALTER COLUMN id SET DEFAULT nextval('public.collateral_evidence_links_id_seq'::regclass);


--
-- Name: collateral_ledger id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_ledger ALTER COLUMN id SET DEFAULT nextval('public.collateral_ledger_id_seq'::regclass);


--
-- Name: collateral_registration_batches id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_batches ALTER COLUMN id SET DEFAULT nextval('public.collateral_registration_batches_id_seq'::regclass);


--
-- Name: collateral_registration_items id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_items ALTER COLUMN id SET DEFAULT nextval('public.collateral_registration_items_id_seq'::regclass);


--
-- Name: credit_lines id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.credit_lines ALTER COLUMN id SET DEFAULT nextval('public.credit_lines_id_seq'::regclass);


--
-- Name: curtailment_payments id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.curtailment_payments ALTER COLUMN id SET DEFAULT nextval('public.curtailment_payments_id_seq'::regclass);


--
-- Name: dealer_bank_accounts id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.dealer_bank_accounts ALTER COLUMN id SET DEFAULT nextval('public.dealer_bank_accounts_id_seq'::regclass);


--
-- Name: dealers id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.dealers ALTER COLUMN id SET DEFAULT nextval('public.dealers_id_seq'::regclass);


--
-- Name: disposal_cases id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.disposal_cases ALTER COLUMN id SET DEFAULT nextval('public.disposal_cases_id_seq'::regclass);


--
-- Name: domain_events id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.domain_events ALTER COLUMN id SET DEFAULT nextval('public.domain_events_id_seq'::regclass);


--
-- Name: extension_requests id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.extension_requests ALTER COLUMN id SET DEFAULT nextval('public.extension_requests_id_seq'::regclass);


--
-- Name: financing_lien_checks id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.financing_lien_checks ALTER COLUMN id SET DEFAULT nextval('public.financing_lien_checks_id_seq'::regclass);


--
-- Name: financing_terms id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.financing_terms ALTER COLUMN id SET DEFAULT nextval('public.financing_terms_id_seq'::regclass);


--
-- Name: import_batches id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.import_batches ALTER COLUMN id SET DEFAULT nextval('public.import_batches_id_seq'::regclass);


--
-- Name: import_row_errors id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.import_row_errors ALTER COLUMN id SET DEFAULT nextval('public.import_row_errors_id_seq'::regclass);


--
-- Name: insurance_policies id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.insurance_policies ALTER COLUMN id SET DEFAULT nextval('public.insurance_policies_id_seq'::regclass);


--
-- Name: interest_ledger id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.interest_ledger ALTER COLUMN id SET DEFAULT nextval('public.interest_ledger_id_seq'::regclass);


--
-- Name: payoff_certificates id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.payoff_certificates ALTER COLUMN id SET DEFAULT nextval('public.payoff_certificates_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: repayments id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.repayments ALTER COLUMN id SET DEFAULT nextval('public.repayments_id_seq'::regclass);


--
-- Name: repurchase_requests id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.repurchase_requests ALTER COLUMN id SET DEFAULT nextval('public.repurchase_requests_id_seq'::regclass);


--
-- Name: risk_alerts id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_alerts ALTER COLUMN id SET DEFAULT nextval('public.risk_alerts_id_seq'::regclass);


--
-- Name: risk_concentration_snapshots id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_concentration_snapshots ALTER COLUMN id SET DEFAULT nextval('public.risk_concentration_snapshots_id_seq'::regclass);


--
-- Name: risk_rules id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_rules ALTER COLUMN id SET DEFAULT nextval('public.risk_rules_id_seq'::regclass);


--
-- Name: security_records id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.security_records ALTER COLUMN id SET DEFAULT nextval('public.security_records_id_seq'::regclass);


--
-- Name: supplier_bank_accounts id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.supplier_bank_accounts ALTER COLUMN id SET DEFAULT nextval('public.supplier_bank_accounts_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: work_order_actions id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.work_order_actions ALTER COLUMN id SET DEFAULT nextval('public.work_order_actions_id_seq'::regclass);


--
-- Name: work_orders id; Type: DEFAULT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.work_orders ALTER COLUMN id SET DEFAULT nextval('public.work_orders_id_seq'::regclass);


--
-- Data for Name: advances; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.advances (id, advance_no, vin, credit_line_id, amount, paid_at, status, payment_ref, idempotency_key, created_at, purchase_order_id, payee_supplier_id, payee_supplier_type, payee_account_snapshot, applicant, reviewer, reviewed_at, disburser) FROM stdin;
368	ADV-6E45B6C5	COLB017527	240	1665000	\N	PROCESSING	PAY-00000002	2f58bea0-cc0d-4ac2-9334-36e6ad33e5e5	2026-10-26 12:25:28.135342+00	\N	\N	\N	\N	operator	\N	\N	cashier
358	ADV-E9A2843C	TESTWN1026195105	238	1665000	2026-10-26 11:51:09.147863+00	PAID	BANK-REF-TESTWN1026195105	adv-ext-TESTWN1026195105	2026-10-26 11:51:09.070281+00	\N	\N	\N	\N	operator	\N	\N	cashier
369	ADV-40CC598E	COLA017554	241	1665000	\N	PROCESSING	PAY-00000003	32536944-a467-46d7-bc1f-975556660b92	2026-10-26 12:25:55.439866+00	\N	\N	\N	\N	operator	\N	\N	cashier
359	ADV-52FBF47B	TESTGR1026195105	238	1665000	2026-10-26 11:51:09.234987+00	PAID	BANK-REF-TESTGR1026195105	adv-ext-TESTGR1026195105	2026-10-26 11:51:09.195881+00	\N	\N	\N	\N	operator	\N	\N	cashier
378	ADV-8273C5C2	COLB018520	245	1665000	2026-10-26 12:42:01.374755+00	PAID	BANK-COL-018520	e952c08e-e26b-452d-93cd-a877b7810a0b	2026-10-26 12:42:01.333236+00	\N	\N	\N	\N	operator	\N	\N	cashier
374	ADV-D86C294A	COLB017866	243	1665000	2026-10-26 12:31:06.929492+00	PAID	BANK-COL-017866	2cb4a44a-9ecc-4d69-ab3b-59e95cc09d38	2026-10-26 12:31:06.880139+00	\N	\N	\N	\N	operator	\N	\N	cashier
360	ADV-E67D54CC	TESTDP1026195105	238	1665000	2026-10-26 11:51:09.413925+00	PAID	BANK-REF-TESTDP1026195105	adv-ext-TESTDP1026195105	2026-10-26 11:51:09.356314+00	\N	\N	\N	\N	operator	\N	\N	cashier
370	ADV-6B04396E	COLB017554	241	1665000	\N	PROCESSING	PAY-00000004	4ba1790e-4984-4874-ae8d-ffeac5e89813	2026-10-26 12:25:55.532244+00	\N	\N	\N	\N	operator	\N	\N	cashier
361	ADV-5C5B97BA	TESTSOD1026195105	238	1665000	2026-10-26 11:51:10.606793+00	PAID	BANK-SOD-REF	adv-sod-TESTSOD1026195105	2026-10-26 11:51:10.015506+00	\N	\N	\N	\N	operator	fund_rev	2026-10-26 11:51:10.13436+00	cashier
354	ADV-42B8C879	TESTVIN1026195105	238	1665000	2026-10-26 11:51:07.062373+00	PAID	BANK-REF-TESTVIN1026195105	adv-smoke-TESTVIN1026195105	2026-10-26 11:51:06.888235+00	\N	\N	\N	\N	operator	\N	\N	cashier
375	ADV-AE7150A1	COLA018493	244	1665000	2026-10-26 12:41:34.645701+00	PAID	BANK-COL-018493	a3b61c80-2d94-44bd-9d49-aa5a05fc57cc	2026-10-26 12:41:34.608939+00	\N	\N	\N	\N	operator	\N	\N	cashier
362	ADV-18D0DA85	TESTFAIL1026195105	238	1665000	\N	FAILED	PAY-00000009	adv-fail-TESTFAIL1026195105	2026-10-26 11:51:10.63679+00	\N	\N	\N	\N	operator	\N	\N	cashier
355	ADV-CA790C7E	TESTCT1026195105	238	1665000	2026-10-26 11:51:07.855368+00	PAID	BANK-REF-TESTCT1026195105	adv-ext-TESTCT1026195105	2026-10-26 11:51:07.810629+00	\N	\N	\N	\N	operator	\N	\N	cashier
363	ADV-F32CD84B	COLA017481	239	1665000	\N	PENDING	\N	493fac57-71fe-4952-8347-c7e6b6f29774	2026-10-26 12:24:42.443186+00	\N	\N	\N	\N	operator	\N	\N	\N
356	ADV-8A1EF8D7	TESTRP1026195105	238	1665000	2026-10-26 11:51:08.466432+00	PAID	BANK-REF-TESTRP1026195105	adv-ext-TESTRP1026195105	2026-10-26 11:51:08.411339+00	\N	\N	\N	\N	operator	\N	\N	cashier
364	ADV-35E83F18	COLB017481	239	1665000	\N	PENDING	\N	eba9dce9-e385-43f5-b333-6a011804e717	2026-10-26 12:24:42.4603+00	\N	\N	\N	\N	operator	\N	\N	\N
365	ADV-769FD65E	COLA017481	239	1665000	\N	PENDING	\N	470c35d5-3f78-4daf-a357-dac02858b3ba	2026-10-26 12:24:42.476471+00	\N	\N	\N	\N	operator	\N	\N	\N
357	ADV-FCA97A8E	TESTEX1026195105	238	1665000	2026-10-26 11:51:08.837621+00	PAID	BANK-REF-TESTEX1026195105	adv-ext-TESTEX1026195105	2026-10-26 11:51:08.800827+00	\N	\N	\N	\N	operator	\N	\N	cashier
371	ADV-D5A8AFFF	COLA017725	242	1665000	2026-10-26 12:28:46.55672+00	PAID	BANK-COL-017725	ecd54ad0-7beb-4c2d-b416-92c4e92a836e	2026-10-26 12:28:46.460004+00	\N	\N	\N	\N	operator	\N	\N	cashier
366	ADV-84EFC6CA	COLB017481	239	1665000	\N	PENDING	\N	c25d8c8f-36eb-4f52-9fd7-06546e38fc01	2026-10-26 12:24:42.489395+00	\N	\N	\N	\N	operator	\N	\N	\N
367	ADV-DA97FDDA	COLA017527	240	1665000	\N	PROCESSING	PAY-00000001	3575be25-42ff-49e1-90a1-8b0398b6d757	2026-10-26 12:25:28.08638+00	\N	\N	\N	\N	operator	\N	\N	cashier
379	ADV-D2C4F3E0	COLA018534	246	1665000	2026-10-26 12:42:14.74778+00	PAID	BANK-COL-018534	1f7c08fb-5c2e-47c4-ac1a-ff7a0418ed3d	2026-10-26 12:42:14.679225+00	\N	\N	\N	\N	operator	\N	\N	cashier
372	ADV-137BD379	COLB017725	242	1665000	2026-10-26 12:28:46.635252+00	PAID	BANK-COL-017725	efd47581-f559-4b6f-b550-25be6a2d48e8	2026-10-26 12:28:46.596113+00	\N	\N	\N	\N	operator	\N	\N	cashier
376	ADV-8246F5D6	COLB018493	244	1665000	2026-10-26 12:41:34.730076+00	PAID	BANK-COL-018493	0ad2ff00-c39a-4917-bbfb-d43bc66d89b3	2026-10-26 12:41:34.685725+00	\N	\N	\N	\N	operator	\N	\N	cashier
373	ADV-7D400122	COLA017866	243	1665000	2026-10-26 12:31:06.86874+00	PAID	BANK-COL-017866	d8735f83-d9b6-4a3b-af00-0a7e31d24a28	2026-10-26 12:31:06.804051+00	\N	\N	\N	\N	operator	\N	\N	cashier
377	ADV-483BA4AE	COLA018520	245	1665000	2026-10-26 12:42:01.32172+00	PAID	BANK-COL-018520	005868d5-c449-4643-8caa-0bb0e410f6e9	2026-10-26 12:42:01.294455+00	\N	\N	\N	\N	operator	\N	\N	cashier
380	ADV-B96BFDA2	COLB018534	246	1665000	2026-10-26 12:42:14.784799+00	PAID	BANK-COL-018534	c213a318-d29e-4abb-9fc1-188661dd73fd	2026-10-26 12:42:14.759501+00	\N	\N	\N	\N	operator	\N	\N	cashier
\.


--
-- Data for Name: aging_plans; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.aging_plans (id, vin, rule_version, first_trigger_date, period_days, reduce_ratio, reduce_amount, paid_periods, next_due_date, status) FROM stdin;
47	TESTCT1026195105	V1	2026-07-28	30	0.1000	166500	1	2026-11-25	ACTIVE
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.alerts (id, dealer_id, vin, alert_type, severity, status, detail, created_at, handler, handled_at, handle_note) FROM stdin;
219	285	\N	AUDIT_UNEXPECTED	MEDIUM	OPEN	现场发现台账外车辆 1 台：TESTVIN1026195105	2026-10-26 11:51:07.480332+00	\N	\N	\N
220	\N	TESTRP1026195105	INSURANCE_CLAIM	MEDIUM	OPEN	保险理赔 500000，请评估是否冲抵垫款	2026-10-26 11:51:08.752121+00	\N	\N	\N
221	285	TESTGR1026195105	OOT_SUSPECTED	HIGH	OPEN	售出后超结算窗口 12 天未还款（已超宽限期，脱信销售嫌疑）	2026-10-26 11:51:09.279627+00	\N	\N	\N
222	285	TESTDP1026195105	DISPOSAL_OPEN	HIGH	OPEN	开违约处置工单，原因=OVERDUE	2026-10-26 11:51:09.538916+00	\N	\N	\N
223	285	TESTGR1026195105	DISPOSAL_OPEN	HIGH	OPEN	开违约处置工单，原因=AUTO_OOT	2026-10-26 11:51:09.604886+00	\N	\N	\N
\.


--
-- Data for Name: annual_reviews; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.annual_reviews (id, review_no, dealer_id, credit_line_id, review_cycle, status, frozen_amount, result_note, initiated_at, completed_at) FROM stdin;
61	AR-C2918E2D	285	238	ANNUAL	PASSED	4995000	冒烟复核通过	2026-10-26 11:51:09.009813+00	2026-10-26 11:51:09.026385+00
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.attachments (id, biz_type, biz_id, object_key, bucket, region, original_filename, content_type, content_length, sha256, etag, object_lock_mode, uploaded_by, uploaded_at, created_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.audit_events (id, actor, actor_role, action, target_type, target_id, before_snapshot, after_snapshot, trace_id, created_at) FROM stdin;
1	1	\N	CREATE_DEALER	DEALER	1	\N	DL-SMOKE-45193	\N	2026-10-25 16:19:53.46294+00
2	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	1	\N	limit=50000000	\N	2026-10-25 16:19:53.52682+00
3	1	\N	BATCH_INGEST	DEALER	1	\N	accepted=1,rejected=0	\N	2026-10-25 16:19:53.547063+00
4	1	\N	ADVANCE	VEHICLE	TESTVIN1026001	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-25 16:19:53.565454+00
34	1	\N	CREATE_DEALER	DEALER	34	\N	DL-SMOKE-45426	\N	2026-10-25 16:23:47.010509+00
35	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	34	\N	limit=50000000	\N	2026-10-25 16:23:47.078193+00
36	1	\N	BATCH_INGEST	DEALER	34	\N	accepted=0,rejected=1	\N	2026-10-25 16:23:47.09969+00
67	1	\N	CREATE_DEALER	DEALER	67	\N	DL-SMOKE-46149	\N	2026-10-25 16:35:49.814159+00
68	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	67	\N	limit=50000000	\N	2026-10-25 16:35:49.837755+00
69	1	\N	BATCH_INGEST	DEALER	67	\N	accepted=1,rejected=0	\N	2026-10-25 16:35:49.85567+00
70	1	\N	ADVANCE	VEHICLE	TESTVIN1026003549	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-25 16:35:49.872634+00
71	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026003549	\N	type=RETENTION,regNo=REG-001	\N	2026-10-25 16:35:49.895807+00
100	1	\N	CREATE_DEALER	DEALER	100	\N	DL-SMOKE-46272	\N	2026-10-25 16:37:52.698189+00
101	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	100	\N	limit=50000000	\N	2026-10-25 16:37:52.722518+00
102	1	\N	BATCH_INGEST	DEALER	100	\N	accepted=1,rejected=0	\N	2026-10-25 16:37:52.743556+00
103	1	\N	ADVANCE	VEHICLE	TESTVIN1026003752	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-25 16:37:52.764641+00
104	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026003752	\N	type=RETENTION,regNo=REG-001	\N	2026-10-25 16:37:52.782742+00
105	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026003752	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-25 16:37:52.822693+00
106	1	\N	REPAYMENT	VEHICLE	TESTVIN1026003752	principal=1665000	settled,interest=0,released=1665000	\N	2026-10-25 16:37:52.83173+00
107	1	\N	INVENTORY_AUDIT	DEALER	100	\N	matched=0,missing=0,unexpected=1	\N	2026-10-25 16:37:52.860697+00
133	1	\N	CREATE_DEALER	DEALER	133	\N	DL-SMOKE-46425	\N	2026-10-25 16:40:25.096068+00
134	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	133	\N	limit=50000000	\N	2026-10-25 16:40:25.115062+00
135	1	\N	BATCH_INGEST	DEALER	133	\N	accepted=1,rejected=0	\N	2026-10-25 16:40:25.130322+00
136	1	\N	ADVANCE	VEHICLE	TESTVIN1026004024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-25 16:40:25.146845+00
137	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026004024	\N	type=RETENTION,regNo=REG-001	\N	2026-10-25 16:40:25.163931+00
138	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026004024	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-25 16:40:25.216455+00
139	1	\N	REPAYMENT	VEHICLE	TESTVIN1026004024	principal=1665000	settled,interest=548,released=1665000	\N	2026-10-25 16:40:25.225993+00
140	1	\N	INVENTORY_AUDIT	DEALER	133	\N	matched=0,missing=0,unexpected=1	\N	2026-10-25 16:40:25.253365+00
166	1	\N	CREATE_DEALER	DEALER	166	\N	DL-SMOKE-72188	\N	2026-10-25 23:49:48.372149+00
167	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	166	\N	limit=50000000	\N	2026-10-25 23:49:48.391122+00
168	1	\N	BATCH_INGEST	DEALER	166	\N	accepted=1,rejected=0	\N	2026-10-25 23:49:48.408519+00
169	1	\N	ADVANCE	VEHICLE	TESTVIN1026074948	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-25 23:49:48.421934+00
170	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026074948	\N	type=RETENTION,regNo=REG-001	\N	2026-10-25 23:49:48.437828+00
171	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026074948	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-25 23:49:48.482673+00
172	1	\N	REPAYMENT	VEHICLE	TESTVIN1026074948	principal=1665000	settled,interest=548,released=1665000	\N	2026-10-25 23:49:48.491603+00
173	1	\N	INVENTORY_AUDIT	DEALER	166	\N	matched=0,missing=0,unexpected=1	\N	2026-10-25 23:49:48.519355+00
199	1	\N	CREATE_DEALER	DEALER	199	\N	DL-SMOKE-78920	\N	2026-10-26 01:42:00.418976+00
200	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	199	\N	limit=200000000	\N	2026-10-26 01:42:00.460099+00
201	1	\N	BATCH_INGEST	DEALER	199	\N	accepted=1,rejected=0	\N	2026-10-26 01:42:00.49905+00
202	1	\N	ADVANCE	VEHICLE	TESTVIN1026094200	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:42:00.554244+00
203	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026094200	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 01:42:00.61583+00
204	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026094200	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 01:42:00.711031+00
205	1	\N	REPAYMENT	VEHICLE	TESTVIN1026094200	principal=1665000	settled,interest=0,released=1665000	\N	2026-10-26 01:42:00.721089+00
206	1	\N	INVENTORY_AUDIT	DEALER	199	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 01:42:00.75553+00
207	1	\N	BATCH_INGEST	DEALER	199	\N	accepted=0,rejected=1	\N	2026-10-26 01:42:00.817766+00
208	1	\N	BATCH_INGEST	DEALER	199	\N	accepted=1,rejected=0	\N	2026-10-26 01:42:00.855471+00
209	1	\N	ADVANCE	VEHICLE	TESTCT1026094200	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:42:00.879838+00
210	1	\N	BATCH_INGEST	DEALER	199	\N	accepted=1,rejected=0	\N	2026-10-26 01:42:00.899914+00
211	1	\N	ADVANCE	VEHICLE	TESTRP1026094200	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:42:00.926506+00
212	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026094200	\N	requestNo=RPR-4D132F2C	\N	2026-10-26 01:42:00.958177+00
213	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026094200	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 01:42:00.966812+00
214	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026094200	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 01:42:00.989433+00
215	1	\N	CREATE_DEALER	DEALER	200	\N	DL-SMOKE-79683	\N	2026-10-26 01:54:43.451928+00
216	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	200	\N	limit=200000000	\N	2026-10-26 01:54:43.459239+00
217	1	\N	BATCH_INGEST	DEALER	200	\N	accepted=1,rejected=0	\N	2026-10-26 01:54:43.465571+00
218	1	\N	ADVANCE	VEHICLE	TESTVIN1026095442	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:54:43.474092+00
219	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026095442	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 01:54:43.514531+00
220	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026095442	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 01:54:43.592548+00
221	1	\N	REPAYMENT	VEHICLE	TESTVIN1026095442	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 01:54:43.625551+00
222	1	\N	INVENTORY_AUDIT	DEALER	200	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 01:54:43.656103+00
223	1	\N	BATCH_INGEST	DEALER	200	\N	accepted=0,rejected=1	\N	2026-10-26 01:54:43.718665+00
224	1	\N	BATCH_INGEST	DEALER	200	\N	accepted=1,rejected=0	\N	2026-10-26 01:54:43.960312+00
225	1	\N	ADVANCE	VEHICLE	TESTCT1026095442	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:54:43.968745+00
226	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026095442	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 01:54:44.287215+00
227	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026095442	period=1	period=2,amount=166500,balance=1332000	\N	2026-10-26 01:54:44.298736+00
228	1	\N	BATCH_INGEST	DEALER	200	\N	accepted=1,rejected=0	\N	2026-10-26 01:54:44.334614+00
229	1	\N	ADVANCE	VEHICLE	TESTRP1026095442	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:54:44.342601+00
230	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026095442	\N	requestNo=RPR-A79C8AE5	\N	2026-10-26 01:54:44.350255+00
231	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026095442	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 01:54:44.365485+00
232	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026095442	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 01:54:44.396719+00
233	1	\N	BATCH_INGEST	DEALER	200	\N	accepted=1,rejected=0	\N	2026-10-26 01:54:44.467609+00
234	1	\N	ADVANCE	VEHICLE	TESTEX1026095442	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:54:44.474938+00
235	1	\N	MARK_SOLD	VEHICLE	TESTEX1026095442	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 01:54:44.506166+00
236	1	\N	EXTENSION	VEHICLE	TESTEX1026095442	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 01:54:44.537665+00
237	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026095442	\N	certNo=PAY-9F1F76CA,total=1665640	\N	2026-10-26 01:54:44.567916+00
238	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	200	used=4995000	frozen=4995000,reviewNo=AR-C6965673	\N	2026-10-26 01:54:44.599582+00
239	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	200	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 01:54:44.631595+00
241	1	\N	BATCH_INGEST	DEALER	200	\N	accepted=1,rejected=0	\N	2026-10-26 01:54:44.64819+00
242	1	\N	ADVANCE	VEHICLE	TESTWN1026095442	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:54:44.677819+00
243	1	\N	MARK_SOLD	VEHICLE	TESTWN1026095442	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 01:54:44.709077+00
244	1	\N	BATCH_INGEST	DEALER	200	\N	accepted=1,rejected=0	\N	2026-10-26 01:54:44.716854+00
245	1	\N	ADVANCE	VEHICLE	TESTGR1026095442	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 01:54:44.724691+00
246	1	\N	MARK_SOLD	VEHICLE	TESTGR1026095442	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 01:54:44.734302+00
248	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026095442	\N	caseNo=DSP-504722FE,reason=AUTO_OOT	\N	2026-10-26 01:55:30.47041+00
249	1	\N	CREATE_DEALER	DEALER	201	\N	DL-SMOKE-80759	\N	2026-10-26 02:12:39.649055+00
250	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	201	\N	limit=200000000	\N	2026-10-26 02:12:39.685694+00
251	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:39.70785+00
252	1	\N	ADVANCE	VEHICLE	TESTVIN1026101239	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 02:12:39.751508+00
253	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026101239	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 02:12:39.832253+00
254	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026101239	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 02:12:39.986723+00
255	1	\N	REPAYMENT	VEHICLE	TESTVIN1026101239	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 02:12:40.001907+00
256	1	\N	INVENTORY_AUDIT	DEALER	201	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 02:12:40.100586+00
257	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=0,rejected=1	\N	2026-10-26 02:12:40.182537+00
258	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:40.427726+00
259	1	\N	ADVANCE	VEHICLE	TESTCT1026101239	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 02:12:40.441479+00
260	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026101239	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 02:12:40.743325+00
261	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:40.795797+00
262	1	\N	ADVANCE	VEHICLE	TESTRP1026101239	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 02:12:40.822866+00
263	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026101239	\N	requestNo=RPR-BAF4554E	\N	2026-10-26 02:12:40.832036+00
264	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026101239	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 02:12:40.85613+00
265	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026101239	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 02:12:40.887675+00
266	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026101239	\N	policyNo=POL-SMOKE-1026101239,insured=2000000	\N	2026-10-26 02:12:40.907096+00
267	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026101239	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 02:12:40.937092+00
268	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:40.945201+00
269	1	\N	ADVANCE	VEHICLE	TESTEX1026101239	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 02:12:40.965487+00
270	1	\N	MARK_SOLD	VEHICLE	TESTEX1026101239	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 02:12:40.973169+00
271	1	\N	EXTENSION	VEHICLE	TESTEX1026101239	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 02:12:40.994918+00
272	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026101239	\N	certNo=PAY-900BBBCA,total=1665640	\N	2026-10-26 02:12:41.002885+00
273	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	201	used=4995000	frozen=4995000,reviewNo=AR-48C328B8	\N	2026-10-26 02:12:41.074266+00
274	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	201	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 02:12:41.085953+00
275	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	1	used=1665000	frozen=1665000,reviewNo=AR-9C8E0EA1	\N	2026-10-26 02:12:41.103785+00
276	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	67	used=1665000	frozen=1665000,reviewNo=AR-FE9C37E4	\N	2026-10-26 02:12:41.103785+00
277	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	199	used=3330000	frozen=3330000,reviewNo=AR-62D38E19	\N	2026-10-26 02:12:41.103785+00
278	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	200	used=8325000	frozen=8325000,reviewNo=AR-A426863E	\N	2026-10-26 02:12:41.103785+00
279	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:41.136075+00
280	1	\N	ADVANCE	VEHICLE	TESTWN1026101239	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 02:12:41.166726+00
281	1	\N	MARK_SOLD	VEHICLE	TESTWN1026101239	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 02:12:41.19826+00
282	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:41.205736+00
283	1	\N	ADVANCE	VEHICLE	TESTGR1026101239	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 02:12:41.230807+00
284	1	\N	MARK_SOLD	VEHICLE	TESTGR1026101239	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 02:12:41.240095+00
285	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:41.281094+00
286	1	\N	ADVANCE	VEHICLE	TESTDP1026101239	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 02:12:41.28814+00
287	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026101239	\N	caseNo=DSP-A6D0EFFA,reason=OVERDUE	\N	2026-10-26 02:12:41.326825+00
288	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-A6D0EFFA	\N	REPOSSESSED	\N	2026-10-26 02:12:41.342417+00
289	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-A6D0EFFA	\N	LIQUIDATING	\N	2026-10-26 02:12:41.370595+00
290	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-A6D0EFFA	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 02:12:41.37677+00
291	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026101239	\N	caseNo=DSP-FA75CA98,reason=AUTO_OOT	\N	2026-10-26 02:12:41.386352+00
292	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@c4443c	com.company.floorplan.domain.model.RatingConfig@5dcdb424	\N	2026-10-26 02:12:41.399936+00
293	1	\N	BATCH_INGEST	DEALER	201	\N	accepted=1,rejected=0	\N	2026-10-26 02:12:41.433145+00
294	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@2ebb226d	com.company.floorplan.domain.model.RatingConfig@21de185b	\N	2026-10-26 02:12:41.494795+00
295	1	\N	CREATE_DEALER	DEALER	202	\N	DL-SMOKE-86007	\N	2026-10-26 03:40:07.281788+00
296	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	202	\N	limit=200000000	\N	2026-10-26 03:40:07.293871+00
297	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:07.330301+00
298	1	\N	ADVANCE	VEHICLE	TESTVIN1026114006	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 03:40:07.35005+00
299	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026114006	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 03:40:07.39654+00
300	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026114006	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 03:40:07.451262+00
301	1	\N	REPAYMENT	VEHICLE	TESTVIN1026114006	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 03:40:07.474013+00
302	1	\N	INVENTORY_AUDIT	DEALER	202	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 03:40:07.517062+00
303	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=0,rejected=1	\N	2026-10-26 03:40:07.565736+00
304	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:07.815628+00
305	1	\N	ADVANCE	VEHICLE	TESTCT1026114006	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 03:40:07.826729+00
306	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026114006	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 03:40:08.127242+00
307	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:08.226192+00
308	1	\N	ADVANCE	VEHICLE	TESTRP1026114006	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 03:40:08.2369+00
309	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026114006	\N	requestNo=RPR-F1C09D60	\N	2026-10-26 03:40:08.247617+00
310	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026114006	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 03:40:08.256302+00
311	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026114006	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 03:40:08.267187+00
312	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026114006	\N	policyNo=POL-SMOKE-1026114006,insured=2000000	\N	2026-10-26 03:40:08.298484+00
313	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026114006	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 03:40:08.306831+00
314	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:08.31454+00
315	1	\N	ADVANCE	VEHICLE	TESTEX1026114006	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 03:40:08.323404+00
316	1	\N	MARK_SOLD	VEHICLE	TESTEX1026114006	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 03:40:08.334167+00
317	1	\N	EXTENSION	VEHICLE	TESTEX1026114006	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 03:40:08.343249+00
318	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026114006	\N	certNo=PAY-95670781,total=1665640	\N	2026-10-26 03:40:08.353623+00
319	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	202	used=4995000	frozen=4995000,reviewNo=AR-75718B00	\N	2026-10-26 03:40:08.391429+00
320	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	202	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 03:40:08.402535+00
321	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	201	used=9990000	frozen=9990000,reviewNo=AR-54721F53	\N	2026-10-26 03:40:08.411649+00
322	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:08.424465+00
323	1	\N	ADVANCE	VEHICLE	TESTWN1026114006	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 03:40:08.447906+00
324	1	\N	MARK_SOLD	VEHICLE	TESTWN1026114006	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 03:40:08.479167+00
325	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:08.509905+00
326	1	\N	ADVANCE	VEHICLE	TESTGR1026114006	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 03:40:08.521004+00
327	1	\N	MARK_SOLD	VEHICLE	TESTGR1026114006	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 03:40:08.55557+00
328	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:08.616321+00
329	1	\N	ADVANCE	VEHICLE	TESTDP1026114006	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 03:40:08.625208+00
330	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026114006	\N	caseNo=DSP-CCB08336,reason=OVERDUE	\N	2026-10-26 03:40:08.634552+00
331	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-CCB08336	\N	REPOSSESSED	\N	2026-10-26 03:40:08.645117+00
332	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-CCB08336	\N	LIQUIDATING	\N	2026-10-26 03:40:08.652434+00
333	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-CCB08336	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 03:40:08.66006+00
334	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026114006	\N	caseNo=DSP-318E7C8C,reason=AUTO_OOT	\N	2026-10-26 03:40:08.670351+00
335	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@3d1dc46a	com.company.floorplan.domain.model.RatingConfig@237a1e1	\N	2026-10-26 03:40:08.68834+00
336	1	\N	BATCH_INGEST	DEALER	202	\N	accepted=1,rejected=0	\N	2026-10-26 03:40:08.698856+00
337	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@43902a59	com.company.floorplan.domain.model.RatingConfig@69df082f	\N	2026-10-26 03:40:08.721608+00
338	admin	\N	CREATE_DEALER	DEALER	203	\N	undefined	\N	2026-10-26 04:14:52.091721+00
339	admin	\N	CREATE_DEALER	DEALER	204	\N	DL-2026-180120	\N	2026-10-26 04:16:21.943247+00
340	admin	\N	CREATE_DEALER	DEALER	205	\N	DL-2026-242588	\N	2026-10-26 04:17:24.315341+00
341	admin	\N	CREATE_CREDIT_LINE	CREDIT_LINE	203	\N	limit=50000000	\N	2026-10-26 04:17:31.856415+00
342	admin	\N	CREATE_DEALER	DEALER	206	\N	DL-2026-410140	\N	2026-10-26 04:20:11.852282+00
343	admin	\N	CREATE_CREDIT_LINE	CREDIT_LINE	204	\N	limit=50000000	\N	2026-10-26 04:20:19.359786+00
344	1	\N	CREATE_DEALER	DEALER	207	\N	DL-SMOKE-88471	\N	2026-10-26 04:21:11.021071+00
345	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	205	\N	limit=200000000	\N	2026-10-26 04:21:11.052394+00
346	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:11.085455+00
347	1	\N	ADVANCE	VEHICLE	TESTVIN1026122110	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:21:11.099371+00
348	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026122110	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:21:11.11717+00
349	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026122110	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:21:11.222555+00
350	1	\N	REPAYMENT	VEHICLE	TESTVIN1026122110	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:21:11.232182+00
351	1	\N	INVENTORY_AUDIT	DEALER	207	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:21:11.26941+00
352	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=0,rejected=1	\N	2026-10-26 04:21:11.309242+00
353	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:11.562714+00
354	1	\N	ADVANCE	VEHICLE	TESTCT1026122110	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:21:11.596526+00
355	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026122110	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:21:11.882081+00
356	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:11.957955+00
367	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026122110	\N	certNo=PAY-3B175A06,total=1665640	\N	2026-10-26 04:21:12.11459+00
369	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	205	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:21:12.144391+00
373	1	\N	MARK_SOLD	VEHICLE	TESTWN1026122110	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:21:12.180521+00
357	1	\N	ADVANCE	VEHICLE	TESTRP1026122110	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:21:11.969447+00
364	1	\N	ADVANCE	VEHICLE	TESTEX1026122110	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:21:12.077002+00
366	1	\N	EXTENSION	VEHICLE	TESTEX1026122110	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:21:12.094892+00
371	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:12.162656+00
375	1	\N	ADVANCE	VEHICLE	TESTGR1026122110	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:21:12.196891+00
377	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:12.239271+00
380	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-8E5F0879	\N	REPOSSESSED	\N	2026-10-26 04:21:12.279963+00
382	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-8E5F0879	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:21:12.294348+00
383	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026122110	\N	caseNo=DSP-B724F441,reason=AUTO_OOT	\N	2026-10-26 04:21:12.31666+00
386	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@39b7ca4c	com.company.floorplan.domain.model.RatingConfig@1d3f8f7a	\N	2026-10-26 04:21:12.378789+00
358	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026122110	\N	requestNo=RPR-8D12AE14	\N	2026-10-26 04:21:11.981645+00
359	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026122110	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:21:11.990481+00
360	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026122110	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:21:12.001186+00
361	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026122110	\N	policyNo=POL-SMOKE-1026122110,insured=2000000	\N	2026-10-26 04:21:12.037272+00
363	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:12.067739+00
370	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	202	used=9990000	frozen=9990000,reviewNo=AR-429CDEFF	\N	2026-10-26 04:21:12.151981+00
374	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:12.188266+00
378	1	\N	ADVANCE	VEHICLE	TESTDP1026122110	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:21:12.249265+00
379	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026122110	\N	caseNo=DSP-8E5F0879,reason=OVERDUE	\N	2026-10-26 04:21:12.27047+00
381	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-8E5F0879	\N	LIQUIDATING	\N	2026-10-26 04:21:12.28694+00
384	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@7b470b2f	com.company.floorplan.domain.model.RatingConfig@62035f5e	\N	2026-10-26 04:21:12.331434+00
385	1	\N	BATCH_INGEST	DEALER	207	\N	accepted=1,rejected=0	\N	2026-10-26 04:21:12.338355+00
362	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026122110	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:21:12.044894+00
365	1	\N	MARK_SOLD	VEHICLE	TESTEX1026122110	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:21:12.085983+00
368	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	205	used=4995000	frozen=4995000,reviewNo=AR-621037E9	\N	2026-10-26 04:21:12.133257+00
372	1	\N	ADVANCE	VEHICLE	TESTWN1026122110	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:21:12.170892+00
376	1	\N	MARK_SOLD	VEHICLE	TESTGR1026122110	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:21:12.204477+00
387	admin	\N	UPDATE_RISK_GRADE	DEALER	1	riskGrade=B	riskGrade=C	\N	2026-10-26 04:25:05.001838+00
388	verify-script	\N	CREATE_DEALER	DEALER	208	\N	DL-CRUD-001	\N	2026-10-26 04:37:00.968881+00
389	verify-script	\N	UPDATE_DEALER	DEALER	208	dealerCode=DL-CRUD-001,name=CRUD 测试株式会社,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-9999-0000,address=东京都港区青山1-2-3,remark=验证用	dealerCode=DL-CRUD-001,name=CRUD 测试改名字株式会社,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	\N	2026-10-26 04:37:00.983329+00
390	verify-script	\N	UPDATE_DEALER	DEALER	208	dealerCode=DL-CRUD-001,name=CRUD 测试改名字株式会社,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	dealerCode=DL-CRUD-001,name=CRUD 测试改名字株式会社,status=SUSPENDED,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	\N	2026-10-26 04:37:00.995651+00
391	verify-script	\N	UPDATE_DEALER	DEALER	208	dealerCode=DL-CRUD-001,name=CRUD 测试改名字株式会社,status=SUSPENDED,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	dealerCode=DL-CRUD-001,name=CRUD 测试改名字株式会社,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	\N	2026-10-26 04:37:01.005187+00
392	verify-script	\N	UPDATE_DEALER	DEALER	208	dealerCode=DL-CRUD-001,name=CRUD 测试改名字株式会社,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	dealerCode=DL-CRUD-001,name=自我改号,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	\N	2026-10-26 04:37:01.037211+00
393	verify-script	\N	UPDATE_DEALER	DEALER	208	dealerCode=DL-CRUD-001,name=自我改号,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	dealerCode=DL-CRUD-001,name=自我改号,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	\N	2026-10-26 04:37:01.057347+00
394	verify-script	\N	UPDATE_DEALER	DEALER	208	dealerCode=DL-CRUD-001,name=自我改号,status=ACTIVE,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	dealerCode=DL-CRUD-001,name=自我改号,status=TERMINATED,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	\N	2026-10-26 04:37:01.064416+00
395	verify-script	\N	DELETE_DEALER	DEALER	208	dealerCode=DL-CRUD-001,name=自我改号,status=TERMINATED,riskGrade=A,businessYears=12,contactPerson=山田 太郎,contactPhone=03-8888-1111,address=东京都港区青山1-2-3,remark=已编辑	\N	\N	2026-10-26 04:37:01.076999+00
396	verify-script	\N	CREATE_DEALER	DEALER	209	\N	DL-GUARD-001	\N	2026-10-26 04:37:11.282334+00
397	verify-script	\N	CREATE_CREDIT_LINE	CREDIT_LINE	206	\N	limit=50000000	\N	2026-10-26 04:37:11.289866+00
398	verify-script	\N	BATCH_INGEST	DEALER	209	\N	accepted=1,rejected=0	\N	2026-10-26 04:37:11.300199+00
399	verify-script	\N	UPDATE_DEALER	DEALER	209	dealerCode=DL-GUARD-001,name=护栏测试店,status=ACTIVE,riskGrade=B,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-GUARD-001,name=护栏测试店,status=TERMINATED,riskGrade=B,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:37:11.334374+00
400	admin	\N	UPDATE_DEALER	DEALER	1	dealerCode=DL-SMOKE-45193,name=冒烟测试经销商,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_470518,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:37:50.552681+00
401	admin	\N	UPDATE_DEALER	DEALER	1	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_470518,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_521216,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:38:41.252183+00
402	admin	\N	UPDATE_DEALER	DEALER	1	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_521216,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_470518DL-SMOKE-45193,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:38:59.690035+00
403	admin	\N	CREATE_DEALER	DEALER	210	\N	DL-BROWSER-89541500	\N	2026-10-26 04:39:04.271522+00
404	admin	\N	DELETE_DEALER	DEALER	210	dealerCode=DL-BROWSER-89541500,name=浏览器临时经销商,status=ACTIVE,riskGrade=null,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	\N	2026-10-26 04:39:06.107039+00
405	repair	\N	UPDATE_DEALER	DEALER	1	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_470518DL-SMOKE-45193,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-45193,name=冒烟测试经销商,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:39:18.93258+00
406	repair	\N	UPDATE_DEALER	DEALER	34	dealerCode=DL-SMOKE-45426,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-45426,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:18.958704+00
407	repair	\N	UPDATE_DEALER	DEALER	67	dealerCode=DL-SMOKE-46149,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-46149,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:18.965136+00
408	repair	\N	UPDATE_DEALER	DEALER	100	dealerCode=DL-SMOKE-46272,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-46272,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:18.989575+00
413	repair	\N	UPDATE_DEALER	DEALER	201	dealerCode=DL-SMOKE-80759,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-80759,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:19.017565+00
421	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	207	\N	limit=200000000	\N	2026-10-26 04:47:39.279644+00
425	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026124738	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:47:39.484905+00
431	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026124738	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:47:40.136048+00
444	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	207	used=4995000	frozen=4995000,reviewNo=AR-B8A57165	\N	2026-10-26 04:47:40.53442+00
460	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@7c5896a5	com.company.floorplan.domain.model.RatingConfig@205828a5	\N	2026-10-26 04:47:40.807392+00
471	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	208	\N	limit=200000000	\N	2026-10-26 04:47:47.825007+00
475	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026124747	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:47:47.973677+00
481	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026124747	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:47:48.659001+00
494	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	208	used=4995000	frozen=4995000,reviewNo=AR-93613B88	\N	2026-10-26 04:47:48.923847+00
510	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@6fd1a5ca	com.company.floorplan.domain.model.RatingConfig@e2da595	\N	2026-10-26 04:47:49.255819+00
521	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	209	\N	limit=200000000	\N	2026-10-26 04:47:50.893113+00
525	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026124750	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:47:50.992966+00
531	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026124750	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:47:51.651306+00
544	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	209	used=4995000	frozen=4995000,reviewNo=AR-8756B2FC	\N	2026-10-26 04:47:51.958711+00
560	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@7cfd6a20	com.company.floorplan.domain.model.RatingConfig@477b5c08	\N	2026-10-26 04:47:52.226418+00
409	repair	\N	UPDATE_DEALER	DEALER	133	dealerCode=DL-SMOKE-46425,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-46425,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:18.995785+00
412	repair	\N	UPDATE_DEALER	DEALER	200	dealerCode=DL-SMOKE-79683,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-79683,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:19.012188+00
414	repair	\N	UPDATE_DEALER	DEALER	202	dealerCode=DL-SMOKE-86007,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-86007,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:19.036204+00
416	admin	\N	UPDATE_DEALER	DEALER	1	dealerCode=DL-SMOKE-45193,name=冒烟测试经销商,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_576380,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:39:36.415929+00
420	1	\N	CREATE_DEALER	DEALER	212	\N	DL-SMOKE-90059	\N	2026-10-26 04:47:39.25628+00
430	1	\N	ADVANCE	VEHICLE	TESTCT1026124738	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:39.820275+00
433	1	\N	ADVANCE	VEHICLE	TESTRP1026124738	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:40.260613+00
436	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026124738	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:47:40.335816+00
442	1	\N	EXTENSION	VEHICLE	TESTEX1026124738	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:47:40.434237+00
450	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:40.634997+00
457	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-E84F7D6C	\N	LIQUIDATING	\N	2026-10-26 04:47:40.743823+00
464	1	\N	UPDATE_DEALER	DEALER	213	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:41.113504+00
467	1	\N	UPDATE_DEALER	DEALER	213	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:41.181247+00
470	1	\N	CREATE_DEALER	DEALER	214	\N	DL-SMOKE-90067	\N	2026-10-26 04:47:47.794556+00
480	1	\N	ADVANCE	VEHICLE	TESTCT1026124747	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:48.35956+00
483	1	\N	ADVANCE	VEHICLE	TESTRP1026124747	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:48.762366+00
486	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026124747	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:47:48.779519+00
492	1	\N	EXTENSION	VEHICLE	TESTEX1026124747	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:47:48.843046+00
500	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:49.016234+00
507	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-A5747370	\N	LIQUIDATING	\N	2026-10-26 04:47:49.223458+00
514	1	\N	UPDATE_DEALER	DEALER	215	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:49.585711+00
517	1	\N	UPDATE_DEALER	DEALER	215	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:49.645675+00
520	1	\N	CREATE_DEALER	DEALER	216	\N	DL-SMOKE-90070	\N	2026-10-26 04:47:50.861699+00
530	1	\N	ADVANCE	VEHICLE	TESTCT1026124750	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:51.354516+00
533	1	\N	ADVANCE	VEHICLE	TESTRP1026124750	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:51.740889+00
536	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026124750	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:47:51.804053+00
542	1	\N	EXTENSION	VEHICLE	TESTEX1026124750	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:47:51.903876+00
550	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:52.042654+00
557	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-CDEF2574	\N	LIQUIDATING	\N	2026-10-26 04:47:52.164897+00
564	1	\N	UPDATE_DEALER	DEALER	217	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:52.490622+00
567	1	\N	UPDATE_DEALER	DEALER	217	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:52.528651+00
410	repair	\N	UPDATE_DEALER	DEALER	166	dealerCode=DL-SMOKE-72188,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-72188,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:19.000888+00
415	repair	\N	UPDATE_DEALER	DEALER	207	dealerCode=DL-SMOKE-88471,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-88471,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:19.041703+00
428	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=0,rejected=1	\N	2026-10-26 04:47:39.567843+00
434	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026124738	\N	requestNo=RPR-2B193EF2	\N	2026-10-26 04:47:40.293581+00
443	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026124738	\N	certNo=PAY-D141D337,total=1665640	\N	2026-10-26 04:47:40.463768+00
451	1	\N	ADVANCE	VEHICLE	TESTGR1026124738	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:40.64433+00
458	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-E84F7D6C	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:47:40.749461+00
465	1	\N	UPDATE_DEALER	DEALER	213	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:41.121029+00
478	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=0,rejected=1	\N	2026-10-26 04:47:48.066654+00
484	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026124747	\N	requestNo=RPR-E291EFBB	\N	2026-10-26 04:47:48.769675+00
493	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026124747	\N	certNo=PAY-60A5293E,total=1665640	\N	2026-10-26 04:47:48.861926+00
501	1	\N	ADVANCE	VEHICLE	TESTGR1026124747	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:49.050572+00
508	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-A5747370	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:47:49.229735+00
515	1	\N	UPDATE_DEALER	DEALER	215	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:49.61479+00
528	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=0,rejected=1	\N	2026-10-26 04:47:51.098004+00
534	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026124750	\N	requestNo=RPR-2B87F840	\N	2026-10-26 04:47:51.75058+00
543	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026124750	\N	certNo=PAY-ADE8EC00,total=1665640	\N	2026-10-26 04:47:51.908521+00
551	1	\N	ADVANCE	VEHICLE	TESTGR1026124750	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:52.067468+00
558	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-CDEF2574	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:47:52.171607+00
565	1	\N	UPDATE_DEALER	DEALER	217	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:52.50151+00
411	repair	\N	UPDATE_DEALER	DEALER	199	dealerCode=DL-SMOKE-78920,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-78920,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:39:19.006654+00
417	admin	\N	UPDATE_DEALER	DEALER	1	dealerCode=DL-SMOKE-45193,name=浏览器测试编辑_576380,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-45193,name=冒烟测试经销商,status=ACTIVE,riskGrade=C,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:39:54.843285+00
418	admin	\N	CREATE_DEALER	DEALER	211	\N	DL-BROWSER-89596644	\N	2026-10-26 04:39:59.422561+00
429	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:39.808117+00
435	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026124738	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:47:40.324229+00
439	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:40.385565+00
447	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:40.588317+00
452	1	\N	MARK_SOLD	VEHICLE	TESTGR1026124738	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:47:40.657161+00
454	1	\N	ADVANCE	VEHICLE	TESTDP1026124738	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:40.721259+00
459	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026124738	\N	caseNo=DSP-F1AF9224,reason=AUTO_OOT	\N	2026-10-26 04:47:40.786949+00
466	1	\N	UPDATE_DEALER	DEALER	213	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:41.15044+00
468	1	\N	UPDATE_DEALER	DEALER	213	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:41.197142+00
479	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:48.327867+00
485	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026124747	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:47:48.773853+00
489	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:48.798438+00
497	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:48.958322+00
502	1	\N	MARK_SOLD	VEHICLE	TESTGR1026124747	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:47:49.082015+00
504	1	\N	ADVANCE	VEHICLE	TESTDP1026124747	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:49.154961+00
509	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026124747	\N	caseNo=DSP-C067B201,reason=AUTO_OOT	\N	2026-10-26 04:47:49.239331+00
516	1	\N	UPDATE_DEALER	DEALER	215	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:49.621939+00
518	1	\N	UPDATE_DEALER	DEALER	215	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:49.739899+00
529	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:51.344722+00
535	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026124750	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:47:51.772494+00
539	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:51.849897+00
547	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:52.020195+00
552	1	\N	MARK_SOLD	VEHICLE	TESTGR1026124750	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:47:52.097352+00
554	1	\N	ADVANCE	VEHICLE	TESTDP1026124750	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:52.128587+00
559	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026124750	\N	caseNo=DSP-F1B5CE0F,reason=AUTO_OOT	\N	2026-10-26 04:47:52.190161+00
566	1	\N	UPDATE_DEALER	DEALER	217	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:52.523897+00
568	1	\N	UPDATE_DEALER	DEALER	217	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:47:52.559303+00
419	admin	\N	DELETE_DEALER	DEALER	211	dealerCode=DL-BROWSER-89596644,name=浏览器临时经销商,status=ACTIVE,riskGrade=null,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	\N	2026-10-26 04:40:01.254159+00
422	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:39.287572+00
423	1	\N	ADVANCE	VEHICLE	TESTVIN1026124738	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:39.299207+00
424	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026124738	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:47:39.344287+00
426	1	\N	REPAYMENT	VEHICLE	TESTVIN1026124738	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:47:39.500345+00
427	1	\N	INVENTORY_AUDIT	DEALER	212	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:47:39.536331+00
432	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:40.229097+00
437	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026124738	\N	policyNo=POL-SMOKE-1026124738,insured=2000000	\N	2026-10-26 04:47:40.357581+00
438	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026124738	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:47:40.375804+00
440	1	\N	ADVANCE	VEHICLE	TESTEX1026124738	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:40.397185+00
441	1	\N	MARK_SOLD	VEHICLE	TESTEX1026124738	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:47:40.408342+00
445	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	207	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:47:40.558532+00
446	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	205	used=9990000	frozen=9990000,reviewNo=AR-C38D656D	\N	2026-10-26 04:47:40.570133+00
448	1	\N	ADVANCE	VEHICLE	TESTWN1026124738	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:40.615299+00
449	1	\N	MARK_SOLD	VEHICLE	TESTWN1026124738	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:47:40.624878+00
453	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:40.714986+00
455	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026124738	\N	caseNo=DSP-E84F7D6C,reason=OVERDUE	\N	2026-10-26 04:47:40.730073+00
456	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-E84F7D6C	\N	REPOSSESSED	\N	2026-10-26 04:47:40.737814+00
461	1	\N	BATCH_INGEST	DEALER	212	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:40.818999+00
462	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@98154ea	com.company.floorplan.domain.model.RatingConfig@428083f5	\N	2026-10-26 04:47:40.90106+00
463	1	\N	CREATE_DEALER	DEALER	213	\N	DL-CRUD-90061	\N	2026-10-26 04:47:41.103172+00
469	1	\N	DELETE_DEALER	DEALER	213	dealerCode=DL-CRUD-90061,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 04:47:41.244259+00
472	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:47.845719+00
473	1	\N	ADVANCE	VEHICLE	TESTVIN1026124747	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:47.85658+00
474	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026124747	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:47:47.901658+00
476	1	\N	REPAYMENT	VEHICLE	TESTVIN1026124747	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:47:47.979464+00
477	1	\N	INVENTORY_AUDIT	DEALER	214	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:47:48.035893+00
482	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:48.756397+00
487	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026124747	\N	policyNo=POL-SMOKE-1026124747,insured=2000000	\N	2026-10-26 04:47:48.789171+00
488	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026124747	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:47:48.793031+00
490	1	\N	ADVANCE	VEHICLE	TESTEX1026124747	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:48.829559+00
491	1	\N	MARK_SOLD	VEHICLE	TESTEX1026124747	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:47:48.837401+00
495	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	208	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:47:48.932289+00
496	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	207	used=9990000	frozen=9990000,reviewNo=AR-840F8E7F	\N	2026-10-26 04:47:48.942044+00
498	1	\N	ADVANCE	VEHICLE	TESTWN1026124747	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:48.97511+00
499	1	\N	MARK_SOLD	VEHICLE	TESTWN1026124747	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:47:48.999938+00
503	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:49.144665+00
505	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026124747	\N	caseNo=DSP-A5747370,reason=OVERDUE	\N	2026-10-26 04:47:49.164286+00
506	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-A5747370	\N	REPOSSESSED	\N	2026-10-26 04:47:49.192565+00
511	1	\N	BATCH_INGEST	DEALER	214	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:49.286424+00
512	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@632da8db	com.company.floorplan.domain.model.RatingConfig@bbeba11	\N	2026-10-26 04:47:49.365191+00
513	1	\N	CREATE_DEALER	DEALER	215	\N	DL-CRUD-90069	\N	2026-10-26 04:47:49.533722+00
519	1	\N	DELETE_DEALER	DEALER	215	dealerCode=DL-CRUD-90069,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 04:47:49.802212+00
522	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:50.898351+00
523	1	\N	ADVANCE	VEHICLE	TESTVIN1026124750	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:50.903933+00
524	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026124750	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:47:50.917071+00
526	1	\N	REPAYMENT	VEHICLE	TESTVIN1026124750	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:47:50.999302+00
527	1	\N	INVENTORY_AUDIT	DEALER	216	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:47:51.067157+00
532	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:51.718718+00
537	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026124750	\N	policyNo=POL-SMOKE-1026124750,insured=2000000	\N	2026-10-26 04:47:51.840437+00
538	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026124750	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:47:51.844702+00
540	1	\N	ADVANCE	VEHICLE	TESTEX1026124750	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:51.869209+00
541	1	\N	MARK_SOLD	VEHICLE	TESTEX1026124750	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:47:51.898482+00
545	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	209	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:47:51.988539+00
546	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	208	used=9990000	frozen=9990000,reviewNo=AR-AF5BC518	\N	2026-10-26 04:47:51.995238+00
548	1	\N	ADVANCE	VEHICLE	TESTWN1026124750	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:47:52.026656+00
549	1	\N	MARK_SOLD	VEHICLE	TESTWN1026124750	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:47:52.032475+00
553	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:52.119545+00
555	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026124750	\N	caseNo=DSP-CDEF2574,reason=OVERDUE	\N	2026-10-26 04:47:52.13921+00
556	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-CDEF2574	\N	REPOSSESSED	\N	2026-10-26 04:47:52.158822+00
562	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@5fc7c99f	com.company.floorplan.domain.model.RatingConfig@1b27ad1	\N	2026-10-26 04:47:52.286192+00
563	1	\N	CREATE_DEALER	DEALER	217	\N	DL-CRUD-90072	\N	2026-10-26 04:47:52.4827+00
569	1	\N	DELETE_DEALER	DEALER	217	dealerCode=DL-CRUD-90072,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 04:47:52.566844+00
561	1	\N	BATCH_INGEST	DEALER	216	\N	accepted=1,rejected=0	\N	2026-10-26 04:47:52.233143+00
570	system	\N	UPDATE_DEALER	DEALER	209	dealerCode=DL-GUARD-001,name=护栏测试店,status=TERMINATED,riskGrade=B,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-GUARD-001,name=护栏测试店,status=TERMINATED,riskGrade=B,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	2026-10-26 04:48:09.009969+00
571	1	\N	CREATE_DEALER	DEALER	218	\N	DL-SMOKE-90122	\N	2026-10-26 04:48:42.744174+00
572	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	210	\N	limit=200000000	\N	2026-10-26 04:48:42.751797+00
573	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:42.759027+00
574	1	\N	ADVANCE	VEHICLE	TESTVIN1026124842	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:48:42.788822+00
575	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026124842	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:48:42.823607+00
576	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026124842	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:48:42.904466+00
577	1	\N	REPAYMENT	VEHICLE	TESTVIN1026124842	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:48:42.911275+00
578	1	\N	INVENTORY_AUDIT	DEALER	218	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:48:42.963285+00
579	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=0,rejected=1	\N	2026-10-26 04:48:42.975007+00
580	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:43.219152+00
581	1	\N	ADVANCE	VEHICLE	TESTCT1026124842	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:48:43.227865+00
582	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026124842	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:48:43.500217+00
583	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:43.572183+00
584	1	\N	ADVANCE	VEHICLE	TESTRP1026124842	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:48:43.57821+00
585	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026124842	\N	requestNo=RPR-D4568222	\N	2026-10-26 04:48:43.589871+00
586	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026124842	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:48:43.594021+00
587	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026124842	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:48:43.626821+00
588	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026124842	\N	policyNo=POL-SMOKE-1026124842,insured=2000000	\N	2026-10-26 04:48:43.636841+00
589	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026124842	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:48:43.642406+00
590	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:43.64785+00
591	1	\N	ADVANCE	VEHICLE	TESTEX1026124842	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:48:43.654017+00
592	1	\N	MARK_SOLD	VEHICLE	TESTEX1026124842	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:48:43.690184+00
593	1	\N	EXTENSION	VEHICLE	TESTEX1026124842	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:48:43.704579+00
594	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026124842	\N	certNo=PAY-6E7D426A,total=1665640	\N	2026-10-26 04:48:43.736323+00
595	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	210	used=4995000	frozen=4995000,reviewNo=AR-CD3526E5	\N	2026-10-26 04:48:43.748793+00
596	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	210	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:48:43.770416+00
597	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:43.803156+00
598	1	\N	ADVANCE	VEHICLE	TESTWN1026124842	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:48:43.833146+00
599	1	\N	MARK_SOLD	VEHICLE	TESTWN1026124842	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:48:43.864266+00
600	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:43.910027+00
601	1	\N	ADVANCE	VEHICLE	TESTGR1026124842	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:48:43.916273+00
602	1	\N	MARK_SOLD	VEHICLE	TESTGR1026124842	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:48:43.9229+00
603	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:43.9561+00
604	1	\N	ADVANCE	VEHICLE	TESTDP1026124842	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:48:43.962943+00
605	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026124842	\N	caseNo=DSP-D741A557,reason=OVERDUE	\N	2026-10-26 04:48:43.968948+00
606	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-D741A557	\N	REPOSSESSED	\N	2026-10-26 04:48:43.975671+00
607	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-D741A557	\N	LIQUIDATING	\N	2026-10-26 04:48:43.980113+00
608	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-D741A557	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:48:43.984272+00
609	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026124842	\N	caseNo=DSP-92C5A00A,reason=AUTO_OOT	\N	2026-10-26 04:48:43.993115+00
610	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@7ddd8ff2	com.company.floorplan.domain.model.RatingConfig@69a72938	\N	2026-10-26 04:48:44.018809+00
611	1	\N	BATCH_INGEST	DEALER	218	\N	accepted=1,rejected=0	\N	2026-10-26 04:48:44.024371+00
612	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@e5166bd	com.company.floorplan.domain.model.RatingConfig@76bc06e	\N	2026-10-26 04:48:44.038913+00
613	1	\N	CREATE_DEALER	DEALER	219	\N	DL-CRUD-90124	\N	2026-10-26 04:48:44.198587+00
614	1	\N	UPDATE_DEALER	DEALER	219	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:48:44.210456+00
615	1	\N	UPDATE_DEALER	DEALER	219	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:48:44.215412+00
616	1	\N	UPDATE_DEALER	DEALER	219	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:48:44.220004+00
617	1	\N	UPDATE_DEALER	DEALER	219	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:48:44.22538+00
728	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:14.006372+00
618	1	\N	UPDATE_DEALER	DEALER	219	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:48:44.268315+00
619	1	\N	DELETE_DEALER	DEALER	219	dealerCode=DL-CRUD-90124,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 04:48:44.275883+00
622	admin	\N	CREATE_DEALER	DEALER	220	\N	DL-BROWSER-90247817	\N	2026-10-26 04:50:50.640091+00
620	admin	\N	UPDATE_DEALER	DEALER	218	dealerCode=DL-SMOKE-90122,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-90122,name=浏览器测试编辑_226953,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:50:27.011661+00
621	admin	\N	UPDATE_DEALER	DEALER	218	dealerCode=DL-SMOKE-90122,name=浏览器测试编辑_226953,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-90122,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:50:45.997143+00
623	admin	\N	DELETE_DEALER	DEALER	220	dealerCode=DL-BROWSER-90247817,name=浏览器临时经销商,status=ACTIVE,riskGrade=null,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	\N	2026-10-26 04:50:52.486379+00
624	admin	\N	UPDATE_DEALER	DEALER	218	dealerCode=DL-SMOKE-90122,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-90122,name=浏览器测试编辑_480279,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:54:40.315191+00
625	admin	\N	UPDATE_DEALER	DEALER	218	dealerCode=DL-SMOKE-90122,name=浏览器测试编辑_480279,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-90122,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 04:54:58.766046+00
626	admin	\N	CREATE_DEALER	DEALER	221	\N	DL-BROWSER-90500572	\N	2026-10-26 04:55:03.417853+00
627	admin	\N	DELETE_DEALER	DEALER	221	dealerCode=DL-BROWSER-90500572,name=浏览器临时经销商,status=ACTIVE,riskGrade=null,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	\N	2026-10-26 04:55:05.266765+00
628	1	\N	CREATE_DEALER	DEALER	222	\N	DL-SMOKE-90515	\N	2026-10-26 04:55:15.098335+00
629	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	211	\N	limit=200000000	\N	2026-10-26 04:55:15.130654+00
630	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:15.165418+00
631	1	\N	ADVANCE	VEHICLE	TESTVIN1026125514	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:55:15.209138+00
632	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026125514	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:55:15.241157+00
633	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026125514	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:55:15.317903+00
634	1	\N	REPAYMENT	VEHICLE	TESTVIN1026125514	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:55:15.326087+00
635	1	\N	INVENTORY_AUDIT	DEALER	222	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:55:15.396442+00
636	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=0,rejected=1	\N	2026-10-26 04:55:15.432707+00
637	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:15.674279+00
638	1	\N	ADVANCE	VEHICLE	TESTCT1026125514	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:55:15.718852+00
639	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026125514	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:55:16.00352+00
640	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:16.08386+00
641	1	\N	ADVANCE	VEHICLE	TESTRP1026125514	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:55:16.111363+00
642	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026125514	\N	requestNo=RPR-21EAF8D8	\N	2026-10-26 04:55:16.135716+00
643	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026125514	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:55:16.152176+00
644	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026125514	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:55:16.177526+00
645	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026125514	\N	policyNo=POL-SMOKE-1026125514,insured=2000000	\N	2026-10-26 04:55:16.249971+00
646	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026125514	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:55:16.257113+00
647	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:16.3009+00
648	1	\N	ADVANCE	VEHICLE	TESTEX1026125514	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:55:16.308843+00
649	1	\N	MARK_SOLD	VEHICLE	TESTEX1026125514	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:55:16.330808+00
650	1	\N	EXTENSION	VEHICLE	TESTEX1026125514	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:55:16.33782+00
651	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026125514	\N	certNo=PAY-0DDBAFF3,total=1665640	\N	2026-10-26 04:55:16.345239+00
652	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	211	used=4995000	frozen=4995000,reviewNo=AR-E79308E0	\N	2026-10-26 04:55:16.386676+00
653	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	211	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:55:16.401388+00
654	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:16.439931+00
655	1	\N	ADVANCE	VEHICLE	TESTWN1026125514	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:55:16.451927+00
656	1	\N	MARK_SOLD	VEHICLE	TESTWN1026125514	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:55:16.487663+00
657	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:16.506402+00
658	1	\N	ADVANCE	VEHICLE	TESTGR1026125514	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:55:16.514682+00
659	1	\N	MARK_SOLD	VEHICLE	TESTGR1026125514	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:55:16.549604+00
660	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:16.607268+00
661	1	\N	ADVANCE	VEHICLE	TESTDP1026125514	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:55:16.62166+00
662	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026125514	\N	caseNo=DSP-525DB2C3,reason=OVERDUE	\N	2026-10-26 04:55:16.633074+00
663	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-525DB2C3	\N	REPOSSESSED	\N	2026-10-26 04:55:16.641881+00
664	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-525DB2C3	\N	LIQUIDATING	\N	2026-10-26 04:55:16.651254+00
665	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-525DB2C3	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:55:16.663426+00
666	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026125514	\N	caseNo=DSP-153862AE,reason=AUTO_OOT	\N	2026-10-26 04:55:16.684047+00
667	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@46039886	com.company.floorplan.domain.model.RatingConfig@335d1a31	\N	2026-10-26 04:55:16.715662+00
668	1	\N	BATCH_INGEST	DEALER	222	\N	accepted=1,rejected=0	\N	2026-10-26 04:55:16.722364+00
669	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@1b8d88d3	com.company.floorplan.domain.model.RatingConfig@e3fca5b	\N	2026-10-26 04:55:16.776356+00
670	1	\N	CREATE_DEALER	DEALER	223	\N	DL-CRUD-90516	\N	2026-10-26 04:55:16.973542+00
671	1	\N	UPDATE_DEALER	DEALER	223	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:55:16.994118+00
672	1	\N	UPDATE_DEALER	DEALER	223	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:55:17.003274+00
673	1	\N	UPDATE_DEALER	DEALER	223	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:55:17.012294+00
674	1	\N	UPDATE_DEALER	DEALER	223	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:55:17.034252+00
676	1	\N	DELETE_DEALER	DEALER	223	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 04:55:17.087395+00
675	1	\N	UPDATE_DEALER	DEALER	223	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90516,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:55:17.075637+00
677	1	\N	CREATE_DEALER	DEALER	224	\N	DL-SMOKE-90624	\N	2026-10-26 04:57:04.914425+00
678	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	212	\N	limit=200000000	\N	2026-10-26 04:57:04.9383+00
679	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:04.954546+00
680	1	\N	ADVANCE	VEHICLE	TESTVIN1026125703	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:04.986009+00
681	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026125703	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:57:05.002192+00
682	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026125703	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:57:05.059908+00
683	1	\N	REPAYMENT	VEHICLE	TESTVIN1026125703	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:57:05.067652+00
684	1	\N	INVENTORY_AUDIT	DEALER	224	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:57:05.0883+00
685	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=0,rejected=1	\N	2026-10-26 04:57:05.127784+00
686	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:05.368953+00
687	1	\N	ADVANCE	VEHICLE	TESTCT1026125703	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:05.392655+00
688	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026125703	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:57:05.685264+00
689	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:05.767666+00
690	1	\N	ADVANCE	VEHICLE	TESTRP1026125703	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:05.774246+00
691	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026125703	\N	requestNo=RPR-5F2EB26C	\N	2026-10-26 04:57:05.783293+00
692	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026125703	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:57:05.790667+00
693	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026125703	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:57:05.798349+00
694	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026125703	\N	policyNo=POL-SMOKE-1026125703,insured=2000000	\N	2026-10-26 04:57:05.810361+00
695	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026125703	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:57:05.839018+00
696	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:05.846067+00
697	1	\N	ADVANCE	VEHICLE	TESTEX1026125703	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:05.853751+00
698	1	\N	MARK_SOLD	VEHICLE	TESTEX1026125703	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:57:05.885136+00
699	1	\N	EXTENSION	VEHICLE	TESTEX1026125703	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:57:05.892417+00
700	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026125703	\N	certNo=PAY-01C6BA81,total=1665640	\N	2026-10-26 04:57:05.89962+00
701	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	212	used=4995000	frozen=4995000,reviewNo=AR-AD837639	\N	2026-10-26 04:57:05.915181+00
702	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	212	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:57:05.92154+00
703	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:05.948794+00
704	1	\N	ADVANCE	VEHICLE	TESTWN1026125703	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:05.956174+00
705	1	\N	MARK_SOLD	VEHICLE	TESTWN1026125703	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:57:05.964169+00
706	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:05.97206+00
707	1	\N	ADVANCE	VEHICLE	TESTGR1026125703	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:05.980602+00
708	1	\N	MARK_SOLD	VEHICLE	TESTGR1026125703	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:57:05.98812+00
709	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:06.011195+00
710	1	\N	ADVANCE	VEHICLE	TESTDP1026125703	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:06.021867+00
711	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026125703	\N	caseNo=DSP-FD69AE1D,reason=OVERDUE	\N	2026-10-26 04:57:06.029798+00
712	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-FD69AE1D	\N	REPOSSESSED	\N	2026-10-26 04:57:06.038372+00
713	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-FD69AE1D	\N	LIQUIDATING	\N	2026-10-26 04:57:06.057757+00
714	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-FD69AE1D	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:57:06.066047+00
715	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026125703	\N	caseNo=DSP-5EFEE6B2,reason=AUTO_OOT	\N	2026-10-26 04:57:06.075427+00
716	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@42586a	com.company.floorplan.domain.model.RatingConfig@6c6fa1ca	\N	2026-10-26 04:57:06.091149+00
717	1	\N	BATCH_INGEST	DEALER	224	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:06.098362+00
718	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@604060d5	com.company.floorplan.domain.model.RatingConfig@39ab7a50	\N	2026-10-26 04:57:06.15107+00
719	1	\N	CREATE_DEALER	DEALER	225	\N	DL-CRUD-90626	\N	2026-10-26 04:57:06.292409+00
720	1	\N	UPDATE_DEALER	DEALER	225	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:06.304752+00
721	1	\N	UPDATE_DEALER	DEALER	225	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:06.311099+00
722	1	\N	UPDATE_DEALER	DEALER	225	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:06.318841+00
723	1	\N	UPDATE_DEALER	DEALER	225	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:06.325072+00
726	1	\N	CREATE_DEALER	DEALER	226	\N	DL-SMOKE-90633	\N	2026-10-26 04:57:13.993322+00
727	1	\N	CREATE_CREDIT_LINE	CREDIT_LINE	213	\N	limit=200000000	\N	2026-10-26 04:57:13.999816+00
724	1	\N	UPDATE_DEALER	DEALER	225	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:06.346629+00
725	1	\N	DELETE_DEALER	DEALER	225	dealerCode=DL-CRUD-90626,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 04:57:06.358368+00
734	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=0,rejected=1	\N	2026-10-26 04:57:14.192886+00
738	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:14.854975+00
740	1	\N	REPURCHASE_REQ	VEHICLE	TESTRP1026125713	\N	requestNo=RPR-6E6D6109	\N	2026-10-26 04:57:14.873188+00
745	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:14.914854+00
747	1	\N	MARK_SOLD	VEHICLE	TESTEX1026125713	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:57:14.932676+00
749	1	\N	PAYOFF_ISSUE	VEHICLE	TESTVIN1026125713	\N	certNo=PAY-5061FAF4,total=1665640	\N	2026-10-26 04:57:14.947251+00
752	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:14.996424+00
754	1	\N	MARK_SOLD	VEHICLE	TESTWN1026125713	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 04:57:15.035677+00
756	1	\N	ADVANCE	VEHICLE	TESTGR1026125713	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:15.089682+00
759	1	\N	ADVANCE	VEHICLE	TESTDP1026125713	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:15.165066+00
761	1	\N	DISPOSAL_REPO	DISPOSAL	DSP-622BF6CA	\N	REPOSSESSED	\N	2026-10-26 04:57:15.180966+00
763	1	\N	DISPOSAL_CLOSE	DISPOSAL	DSP-622BF6CA	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 04:57:15.192407+00
770	1	\N	UPDATE_DEALER	DEALER	227	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:15.406177+00
773	1	\N	UPDATE_DEALER	DEALER	227	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:15.47871+00
774	1	\N	DELETE_DEALER	DEALER	227	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 04:57:15.506856+00
777	system	\N	CREATE_DEALER	DEALER	229	\N	DL-IDEM-1026130538	\N	2026-10-26 05:05:38.539203+00
729	1	\N	ADVANCE	VEHICLE	TESTVIN1026125713	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:14.014306+00
744	1	\N	INSURANCE_CLAIM	VEHICLE	TESTRP1026125713	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 04:57:14.906798+00
758	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:15.145248+00
778	system	\N	CREATE_CREDIT_LINE	CREDIT_LINE	215	\N	limit=10000000	\N	2026-10-26 05:05:38.546043+00
779	system	\N	BATCH_INGEST	DEALER	229	\N	accepted=1,rejected=0	\N	2026-10-26 05:05:38.563262+00
730	1	\N	SET_SECURITY	VEHICLE	TESTVIN1026125713	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 04:57:14.028516+00
732	1	\N	REPAYMENT	VEHICLE	TESTVIN1026125713	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 04:57:14.125409+00
733	1	\N	INVENTORY_AUDIT	DEALER	226	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 04:57:14.157248+00
743	1	\N	INSURANCE_BIND	VEHICLE	TESTRP1026125713	\N	policyNo=POL-SMOKE-1026125713,insured=2000000	\N	2026-10-26 04:57:14.900391+00
746	1	\N	ADVANCE	VEHICLE	TESTEX1026125713	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:14.923963+00
751	1	\N	ANNUAL_REVIEW_DONE	CREDIT_LINE	213	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 04:57:14.97092+00
753	1	\N	ADVANCE	VEHICLE	TESTWN1026125713	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:15.027805+00
760	1	\N	DISPOSAL_OPEN	VEHICLE	TESTDP1026125713	\N	caseNo=DSP-622BF6CA,reason=OVERDUE	\N	2026-10-26 04:57:15.173531+00
766	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:15.218278+00
767	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@1315dfb9	com.company.floorplan.domain.model.RatingConfig@439acbc	\N	2026-10-26 04:57:15.274114+00
768	1	\N	CREATE_DEALER	DEALER	227	\N	DL-CRUD-90635	\N	2026-10-26 04:57:15.375567+00
775	system	\N	CREATE_DEALER	DEALER	228	\N	DL-IDEM-1026130503	\N	2026-10-26 05:05:03.44836+00
780	system	\N	ADVANCE	VEHICLE	TESTIDEM1026130538	status=FINANCED	status=IN_STOCK,amount=1350000	\N	2026-10-26 05:05:38.59311+00
731	1	\N	MARK_SOLD	VEHICLE	TESTVIN1026125713	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 04:57:14.093116+00
735	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:14.452979+00
736	1	\N	ADVANCE	VEHICLE	TESTCT1026125713	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:14.484452+00
737	1	\N	CURTAIL_PAY	VEHICLE	TESTCT1026125713	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 04:57:14.824337+00
739	1	\N	ADVANCE	VEHICLE	TESTRP1026125713	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 04:57:14.864146+00
741	1	\N	REPURCHASE_FULFILL	VEHICLE	TESTRP1026125713	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 04:57:14.879935+00
742	1	\N	PARTIAL_REPAY	VEHICLE	TESTRP1026125713	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 04:57:14.887904+00
748	1	\N	EXTENSION	VEHICLE	TESTEX1026125713	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 04:57:14.940181+00
750	1	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	213	used=4995000	frozen=4995000,reviewNo=AR-0891DD26	\N	2026-10-26 04:57:14.963357+00
755	1	\N	BATCH_INGEST	DEALER	226	\N	accepted=1,rejected=0	\N	2026-10-26 04:57:15.059453+00
757	1	\N	MARK_SOLD	VEHICLE	TESTGR1026125713	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 04:57:15.12054+00
762	1	\N	DISPOSAL_LIQ	DISPOSAL	DSP-622BF6CA	\N	LIQUIDATING	\N	2026-10-26 04:57:15.186718+00
764	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026125713	\N	caseNo=DSP-20BFA898,reason=AUTO_OOT	\N	2026-10-26 04:57:15.19965+00
765	1	\N	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@14cabfbd	com.company.floorplan.domain.model.RatingConfig@7c1af874	\N	2026-10-26 04:57:15.212085+00
769	1	\N	UPDATE_DEALER	DEALER	227	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:15.40096+00
771	1	\N	UPDATE_DEALER	DEALER	227	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:15.411487+00
772	1	\N	UPDATE_DEALER	DEALER	227	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-90635,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 04:57:15.416636+00
776	system	\N	CREATE_CREDIT_LINE	CREDIT_LINE	214	\N	limit=10000000	\N	2026-10-26 05:05:03.467198+00
781	system	\N	CREATE_DEALER	DEALER	230	\N	DL-STAT-1026133350	\N	2026-10-26 05:33:50.508299+00
782	system	\N	CREATE_CREDIT_LINE	CREDIT_LINE	216	\N	limit=10000000	\N	2026-10-26 05:33:50.526498+00
783	system	\N	BATCH_INGEST	DEALER	230	\N	accepted=1,rejected=0	\N	2026-10-26 05:33:50.547742+00
784	system	\N	ADVANCE	VEHICLE	TESTSTAT1026133350	status=FINANCED	status=IN_STOCK,amount=1350000	\N	2026-10-26 05:33:50.558384+00
785	system	\N	MARK_SOLD	VEHICLE	TESTSTAT1026133350	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 05:33:50.581882+00
786	admin	\N	CREATE_DEALER	DEALER	231	\N	DL-0001	\N	2026-10-26 05:37:55.190288+00
788	admin	ADMIN	CREATE_DEALER	DEALER	233	\N	DL-SMOKE-94414	\N	2026-10-26 06:00:14.3709+00
789	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	217	\N	limit=200000000	\N	2026-10-26 06:00:14.4395+00
790	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:14.479831+00
791	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026140013	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:14.536139+00
792	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026140013	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 06:00:14.589043+00
793	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026140013	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 06:00:14.738359+00
794	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026140013	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 06:00:14.769668+00
795	admin	ADMIN	INVENTORY_AUDIT	DEALER	233	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 06:00:14.850089+00
796	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=0,rejected=1	\N	2026-10-26 06:00:14.910021+00
797	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:15.205371+00
798	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026140013	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:15.219204+00
799	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026140013	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 06:00:15.505747+00
800	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:15.648001+00
801	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026140013	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:15.671995+00
802	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026140013	\N	requestNo=RPR-480C3D6C	\N	2026-10-26 06:00:15.711425+00
803	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026140013	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 06:00:15.729745+00
804	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026140013	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 06:00:15.751527+00
805	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026140013	\N	policyNo=POL-SMOKE-1026140013,insured=2000000	\N	2026-10-26 06:00:15.77829+00
806	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026140013	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 06:00:15.793999+00
807	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:15.805769+00
808	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026140013	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:15.821634+00
809	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026140013	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 06:00:15.837865+00
810	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026140013	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 06:00:15.852311+00
811	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026140013	\N	certNo=PAY-D35E7891,total=1665640	\N	2026-10-26 06:00:15.864297+00
812	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	217	used=4995000	frozen=4995000,reviewNo=AR-9D0AF52B	\N	2026-10-26 06:00:15.905531+00
813	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	217	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 06:00:15.925526+00
814	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:15.954437+00
815	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026140013	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:15.96841+00
816	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026140013	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 06:00:15.981759+00
817	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:15.99448+00
818	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026140013	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:16.009987+00
819	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026140013	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 06:00:16.023238+00
820	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:16.073543+00
821	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026140013	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:16.089013+00
822	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026140013	\N	caseNo=DSP-91E010B3,reason=OVERDUE	\N	2026-10-26 06:00:16.100465+00
823	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-91E010B3	\N	REPOSSESSED	\N	2026-10-26 06:00:16.110046+00
824	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-91E010B3	\N	LIQUIDATING	\N	2026-10-26 06:00:16.135102+00
825	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-91E010B3	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 06:00:16.16852+00
826	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026140013	\N	caseNo=DSP-93A6322B,reason=AUTO_OOT	\N	2026-10-26 06:00:16.178406+00
827	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@5f83b09a	com.company.floorplan.domain.model.RatingConfig@2e68cff0	\N	2026-10-26 06:00:16.214678+00
828	admin	ADMIN	BATCH_INGEST	DEALER	233	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:16.230537+00
829	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@63a54607	com.company.floorplan.domain.model.RatingConfig@5e56f37e	\N	2026-10-26 06:00:16.276887+00
831	admin	ADMIN	CREATE_DEALER	DEALER	235	\N	DL-CRUD-94417	\N	2026-10-26 06:00:17.842019+00
832	admin	ADMIN	UPDATE_DEALER	DEALER	235	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:17.867967+00
833	admin	ADMIN	UPDATE_DEALER	DEALER	235	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:17.88656+00
834	admin	ADMIN	UPDATE_DEALER	DEALER	235	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:17.90248+00
835	admin	ADMIN	UPDATE_DEALER	DEALER	235	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:17.915028+00
836	admin	ADMIN	UPDATE_DEALER	DEALER	235	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:17.986523+00
837	admin	ADMIN	DELETE_DEALER	DEALER	235	dealerCode=DL-CRUD-94417,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 06:00:18.002269+00
838	admin	ADMIN	CREATE_DEALER	DEALER	236	\N	DL-SMOKE-94425	\N	2026-10-26 06:00:25.080996+00
839	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	218	\N	limit=200000000	\N	2026-10-26 06:00:25.107256+00
840	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:25.113859+00
841	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026140024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:25.138836+00
842	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026140024	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 06:00:25.186969+00
843	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026140024	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 06:00:25.238749+00
844	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026140024	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 06:00:25.246846+00
845	admin	ADMIN	INVENTORY_AUDIT	DEALER	236	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 06:00:25.281896+00
846	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=0,rejected=1	\N	2026-10-26 06:00:25.337894+00
847	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:25.583918+00
848	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026140024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:25.616767+00
849	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026140024	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 06:00:25.944145+00
850	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:25.972959+00
851	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026140024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:25.982016+00
852	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026140024	\N	requestNo=RPR-F055D43B	\N	2026-10-26 06:00:25.990467+00
853	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026140024	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 06:00:26.020629+00
854	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026140024	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 06:00:26.052826+00
855	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026140024	\N	policyNo=POL-SMOKE-1026140024,insured=2000000	\N	2026-10-26 06:00:26.088524+00
856	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026140024	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 06:00:26.094628+00
857	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:26.115674+00
858	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026140024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:26.123453+00
859	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026140024	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 06:00:26.131751+00
860	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026140024	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 06:00:26.162421+00
861	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026140024	\N	certNo=PAY-5C076AC3,total=1665640	\N	2026-10-26 06:00:26.169801+00
862	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	218	used=4995000	frozen=4995000,reviewNo=AR-43207CB1	\N	2026-10-26 06:00:26.211886+00
863	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	218	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 06:00:26.239296+00
864	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:26.255474+00
865	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026140024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:26.263489+00
866	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026140024	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 06:00:26.272032+00
867	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:26.280266+00
868	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026140024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:26.303298+00
869	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026140024	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 06:00:26.3123+00
870	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:26.350672+00
871	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026140024	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:26.362648+00
872	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026140024	\N	caseNo=DSP-D5531066,reason=OVERDUE	\N	2026-10-26 06:00:26.373312+00
873	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-D5531066	\N	REPOSSESSED	\N	2026-10-26 06:00:26.383845+00
874	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-D5531066	\N	LIQUIDATING	\N	2026-10-26 06:00:26.4136+00
875	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-D5531066	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 06:00:26.425203+00
876	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026140024	\N	caseNo=DSP-7E1BFF6B,reason=AUTO_OOT	\N	2026-10-26 06:00:26.437807+00
877	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@7d601272	com.company.floorplan.domain.model.RatingConfig@4a669b9f	\N	2026-10-26 06:00:26.491192+00
878	admin	ADMIN	BATCH_INGEST	DEALER	236	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:26.498493+00
879	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@67626ad	com.company.floorplan.domain.model.RatingConfig@6d8b9efd	\N	2026-10-26 06:00:26.542566+00
881	admin	ADMIN	CREATE_DEALER	DEALER	238	\N	DL-CRUD-94428	\N	2026-10-26 06:00:28.05744+00
882	admin	ADMIN	UPDATE_DEALER	DEALER	238	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:28.091556+00
883	admin	ADMIN	UPDATE_DEALER	DEALER	238	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:28.11857+00
884	admin	ADMIN	UPDATE_DEALER	DEALER	238	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:28.134908+00
885	admin	ADMIN	UPDATE_DEALER	DEALER	238	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:28.16006+00
886	admin	ADMIN	UPDATE_DEALER	DEALER	238	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:28.221698+00
887	admin	ADMIN	DELETE_DEALER	DEALER	238	dealerCode=DL-CRUD-94428,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 06:00:28.233904+00
888	admin	ADMIN	CREATE_DEALER	DEALER	239	\N	DL-SMOKE-94434	\N	2026-10-26 06:00:34.285184+00
889	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	219	\N	limit=200000000	\N	2026-10-26 06:00:34.315842+00
890	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:34.321592+00
891	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026140033	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:34.329113+00
892	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026140033	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 06:00:34.342556+00
893	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026140033	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 06:00:34.429438+00
894	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026140033	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 06:00:34.437245+00
895	admin	ADMIN	INVENTORY_AUDIT	DEALER	239	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 06:00:34.487449+00
896	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=0,rejected=1	\N	2026-10-26 06:00:34.501769+00
897	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:34.767298+00
898	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026140033	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:34.774296+00
899	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026140033	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 06:00:35.062071+00
900	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:35.110429+00
901	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026140033	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:35.119927+00
902	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026140033	\N	requestNo=RPR-B3B97A43	\N	2026-10-26 06:00:35.130945+00
903	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026140033	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 06:00:35.143472+00
904	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026140033	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 06:00:35.172328+00
905	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026140033	\N	policyNo=POL-SMOKE-1026140033,insured=2000000	\N	2026-10-26 06:00:35.207507+00
906	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026140033	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 06:00:35.213913+00
907	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:35.222013+00
908	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026140033	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:35.232642+00
909	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026140033	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 06:00:35.242022+00
910	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026140033	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 06:00:35.265476+00
911	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026140033	\N	certNo=PAY-CDFCFF0F,total=1665640	\N	2026-10-26 06:00:35.273421+00
912	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	219	used=4995000	frozen=4995000,reviewNo=AR-F5C472C5	\N	2026-10-26 06:00:35.301603+00
913	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	219	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 06:00:35.308246+00
914	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:35.360115+00
915	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026140033	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:35.3672+00
916	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026140033	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 06:00:35.390795+00
917	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:35.422387+00
918	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026140033	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:35.431601+00
919	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026140033	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 06:00:35.453857+00
920	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:35.47575+00
921	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026140033	status=FINANCED	status=IN_STOCK,amount=1665000	\N	2026-10-26 06:00:35.483763+00
922	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026140033	\N	caseNo=DSP-D31FC3D0,reason=OVERDUE	\N	2026-10-26 06:00:35.491919+00
923	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-D31FC3D0	\N	REPOSSESSED	\N	2026-10-26 06:00:35.498409+00
924	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-D31FC3D0	\N	LIQUIDATING	\N	2026-10-26 06:00:35.517059+00
925	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-D31FC3D0	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 06:00:35.548103+00
926	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026140033	\N	caseNo=DSP-686FB319,reason=AUTO_OOT	\N	2026-10-26 06:00:35.557454+00
927	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@746ab80e	com.company.floorplan.domain.model.RatingConfig@73f36c32	\N	2026-10-26 06:00:35.595545+00
928	admin	ADMIN	BATCH_INGEST	DEALER	239	\N	accepted=1,rejected=0	\N	2026-10-26 06:00:35.602546+00
929	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@3304f3da	com.company.floorplan.domain.model.RatingConfig@547b0e39	\N	2026-10-26 06:00:35.647805+00
931	admin	ADMIN	CREATE_DEALER	DEALER	241	\N	DL-CRUD-94437	\N	2026-10-26 06:00:37.379547+00
932	admin	ADMIN	UPDATE_DEALER	DEALER	241	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:37.394265+00
933	admin	ADMIN	UPDATE_DEALER	DEALER	241	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:37.400194+00
934	admin	ADMIN	UPDATE_DEALER	DEALER	241	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:37.424966+00
935	admin	ADMIN	UPDATE_DEALER	DEALER	241	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:37.441906+00
936	admin	ADMIN	UPDATE_DEALER	DEALER	241	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 06:00:37.473148+00
937	admin	ADMIN	DELETE_DEALER	DEALER	241	dealerCode=DL-CRUD-94437,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 06:00:37.494267+00
938	admin	ADMIN	UPDATE_DEALER	DEALER	231	dealerCode=DL-0001,name=大板株式会社,status=ACTIVE,riskGrade=null,businessYears=10,contactPerson=三井一,contactPhone=03-20-499978,address=大板2号路,remark=null	dealerCode=DL-0001,name=浏览器测试编辑_450526,status=ACTIVE,riskGrade=null,businessYears=10,contactPerson=三井一,contactPhone=03-20-499978,address=大板2号路,remark=由浏览器验证脚本写入	\N	2026-10-26 06:00:50.594255+00
939	admin	ADMIN	DELETE_DEALER	DEALER	231	dealerCode=DL-0001,name=浏览器测试编辑_450526,status=ACTIVE,riskGrade=null,businessYears=10,contactPerson=三井一,contactPhone=03-20-499978,address=大板2号路,remark=由浏览器验证脚本写入	\N	\N	2026-10-26 06:01:06.679092+00
940	admin	ADMIN	CREATE_DEALER	DEALER	242	\N	DL-BROWSER-94498698	\N	2026-10-26 06:01:39.647495+00
941	admin	ADMIN	DELETE_DEALER	DEALER	242	dealerCode=DL-BROWSER-94498698,name=浏览器临时经销商,status=ACTIVE,riskGrade=null,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	\N	2026-10-26 06:01:41.469574+00
942	admin	ADMIN	UPDATE_DEALER	DEALER	239	dealerCode=DL-SMOKE-94434,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=null	dealerCode=DL-SMOKE-94434,name=浏览器测试编辑_557095,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 06:02:37.149001+00
944	admin	ADMIN	CREATE_DEALER	DEALER	243	\N	DL-BROWSER-94577936	\N	2026-10-26 06:03:00.788569+00
943	admin	ADMIN	UPDATE_DEALER	DEALER	239	dealerCode=DL-SMOKE-94434,name=浏览器测试编辑_557095,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-94434,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 06:02:56.125932+00
945	admin	ADMIN	DELETE_DEALER	DEALER	243	dealerCode=DL-BROWSER-94577936,name=浏览器临时经销商,status=ACTIVE,riskGrade=null,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	\N	2026-10-26 06:03:02.64877+00
947	admin	ADMIN	UPDATE_DEALER	DEALER	239	dealerCode=DL-SMOKE-94434,name=浏览器测试编辑_597368,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-94434,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 06:03:36.392134+00
946	admin	ADMIN	UPDATE_DEALER	DEALER	239	dealerCode=DL-SMOKE-94434,name=冒烟测试经销商,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	dealerCode=DL-SMOKE-94434,name=浏览器测试编辑_597368,status=ACTIVE,riskGrade=B,businessYears=10,contactPerson=null,contactPhone=null,address=null,remark=由浏览器验证脚本写入	\N	2026-10-26 06:03:17.424203+00
948	admin	ADMIN	CREATE_DEALER	DEALER	244	\N	DL-BROWSER-94618201	\N	2026-10-26 06:03:41.031336+00
949	admin	ADMIN	DELETE_DEALER	DEALER	244	dealerCode=DL-BROWSER-94618201,name=浏览器临时经销商,status=ACTIVE,riskGrade=null,businessYears=null,contactPerson=null,contactPhone=null,address=null,remark=null	\N	\N	2026-10-26 06:03:42.885359+00
950	admin	ADMIN	CREATE_DEALER	DEALER	245	\N	dl-00400	\N	2026-10-26 06:20:17.341799+00
951	admin	ADMIN	UPDATE_DEALER	DEALER	245	dealerCode=dl-00400,name=大板株式会社,status=ACTIVE,riskGrade=null,businessYears=10,contactPerson=三加一,contactPhone=03-00-3849,address=null,remark=null	dealerCode=dl-00400,name=大板株式会社,status=ACTIVE,riskGrade=null,businessYears=10,contactPerson=三加一额,contactPhone=03-00-3849,address=null,remark=null	\N	2026-10-26 06:41:28.370411+00
952	admin	ADMIN	UPDATE_DEALER	DEALER	245	dealerCode=dl-00400,name=大板株式会社,status=ACTIVE,riskGrade=null,businessYears=10,contactPerson=三加一额,contactPhone=03-00-3849,address=null,remark=null	dealerCode=dl-00400,name=大板株式会社,status=ACTIVE,riskGrade=null,businessYears=12,contactPerson=三加一额,contactPhone=03-00-3849,address=null,remark=null	\N	2026-10-26 06:43:50.313488+00
953	admin	ADMIN	CREATE_DEALER	DEALER	250	\N	dl-0002	\N	2026-10-26 06:57:49.385876+00
954	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	220	\N	limit=1000000000	\N	2026-10-26 06:58:45.90093+00
955	admin	ADMIN	CREATE_DEALER	DEALER	251	\N	DL-SMOKE-2209	\N	2026-10-26 08:10:10.004598+00
956	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	221	\N	limit=200000000	\N	2026-10-26 08:10:10.027756+00
957	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:10.0737+00
958	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026161008	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:10.134344+00
959	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026161008	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:10.146338+00
960	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026161008	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 08:10:10.182266+00
961	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026161008	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:10:10.326707+00
962	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026161008	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 08:10:10.344478+00
963	admin	ADMIN	INVENTORY_AUDIT	DEALER	251	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 08:10:10.416999+00
964	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=0,rejected=1	\N	2026-10-26 08:10:10.465023+00
965	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:10.751762+00
966	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026161008	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:10.771992+00
967	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026161008	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:10.777921+00
968	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026161008	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 08:10:11.098536+00
969	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:11.166929+00
970	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026161008	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:11.188683+00
971	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026161008	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:11.19674+00
972	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026161008	\N	requestNo=RPR-C90EFA44	\N	2026-10-26 08:10:11.214813+00
973	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026161008	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 08:10:11.231785+00
974	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026161008	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 08:10:11.258453+00
975	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026161008	\N	policyNo=POL-SMOKE-1026161008,insured=2000000	\N	2026-10-26 08:10:11.319252+00
976	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026161008	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 08:10:11.339266+00
977	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:11.355851+00
978	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026161008	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:11.37608+00
979	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026161008	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:11.384472+00
980	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026161008	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:10:11.399564+00
981	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026161008	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 08:10:11.420443+00
982	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026161008	\N	certNo=PAY-ED07ED5C,total=1665640	\N	2026-10-26 08:10:11.439593+00
983	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	221	used=4995000	frozen=4995000,reviewNo=AR-E752DF83	\N	2026-10-26 08:10:11.478517+00
984	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	221	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 08:10:11.504612+00
985	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:11.537872+00
986	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026161008	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:11.562413+00
987	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026161008	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:11.568497+00
988	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026161008	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 08:10:11.583073+00
989	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:11.598552+00
990	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026161008	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:11.613634+00
991	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026161008	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:11.62097+00
992	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026161008	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 08:10:11.637959+00
993	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:11.693732+00
994	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026161008	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:11.711113+00
995	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026161008	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:11.71787+00
996	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026161008	\N	caseNo=DSP-46194674,reason=OVERDUE	\N	2026-10-26 08:10:11.733483+00
997	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-46194674	\N	REPOSSESSED	\N	2026-10-26 08:10:11.752703+00
998	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-46194674	\N	LIQUIDATING	\N	2026-10-26 08:10:11.765154+00
1237	operator	USER	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:07.427689+00
999	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-46194674	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 08:10:11.778193+00
1000	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026161008	\N	caseNo=DSP-F33AF2DF,reason=AUTO_OOT	\N	2026-10-26 08:10:11.796416+00
1001	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@3547e559	com.company.floorplan.domain.model.RatingConfig@70a3ed09	\N	2026-10-26 08:10:11.830596+00
1002	admin	ADMIN	BATCH_INGEST	DEALER	251	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:11.848608+00
1003	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@c5812cf	com.company.floorplan.domain.model.RatingConfig@77320c82	\N	2026-10-26 08:10:11.886934+00
1005	admin	ADMIN	CREATE_DEALER	DEALER	253	\N	DL-CRUD-2214	\N	2026-10-26 08:10:14.500757+00
1006	admin	ADMIN	UPDATE_DEALER	DEALER	253	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:14.526677+00
1007	admin	ADMIN	UPDATE_DEALER	DEALER	253	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:14.548386+00
1008	admin	ADMIN	UPDATE_DEALER	DEALER	253	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:14.564519+00
1009	admin	ADMIN	UPDATE_DEALER	DEALER	253	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:14.57912+00
1010	admin	ADMIN	UPDATE_DEALER	DEALER	253	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:14.646764+00
1011	admin	ADMIN	DELETE_DEALER	DEALER	253	dealerCode=DL-CRUD-2214,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 08:10:14.669116+00
1012	admin	ADMIN	CREATE_DEALER	DEALER	254	\N	DL-SMOKE-2227	\N	2026-10-26 08:10:27.405361+00
1013	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	222	\N	limit=200000000	\N	2026-10-26 08:10:27.427021+00
1014	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:27.466836+00
1015	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026161026	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:27.553017+00
1016	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026161026	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:27.567885+00
1017	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026161026	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 08:10:27.655189+00
1018	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026161026	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:10:27.855507+00
1019	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026161026	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 08:10:27.873238+00
1020	admin	ADMIN	INVENTORY_AUDIT	DEALER	254	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 08:10:27.949768+00
1021	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=0,rejected=1	\N	2026-10-26 08:10:27.979925+00
1022	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:28.277326+00
1023	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026161026	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:28.338351+00
1024	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026161026	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:28.343312+00
1025	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026161026	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 08:10:28.716971+00
1026	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:28.790984+00
1027	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026161026	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:28.831195+00
1028	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026161026	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:28.836778+00
1029	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026161026	\N	requestNo=RPR-AEFD73C6	\N	2026-10-26 08:10:28.85209+00
1030	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026161026	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 08:10:28.863172+00
1031	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026161026	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 08:10:28.877754+00
1032	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026161026	\N	policyNo=POL-SMOKE-1026161026,insured=2000000	\N	2026-10-26 08:10:28.912075+00
1033	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026161026	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 08:10:28.923621+00
1034	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:28.943443+00
1035	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026161026	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:28.96195+00
1036	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026161026	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:28.969229+00
1037	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026161026	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:10:29.006187+00
1038	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026161026	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 08:10:29.024862+00
1039	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026161026	\N	certNo=PAY-0DB5E9F8,total=1665640	\N	2026-10-26 08:10:29.045969+00
1040	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	222	used=4995000	frozen=4995000,reviewNo=AR-C827FE80	\N	2026-10-26 08:10:29.096003+00
1041	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	222	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 08:10:29.118501+00
1042	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:29.151373+00
1043	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026161026	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:29.178151+00
1044	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026161026	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:29.183436+00
1045	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026161026	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 08:10:29.196998+00
1046	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:29.220248+00
1047	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026161026	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:29.239814+00
1048	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026161026	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:29.244551+00
1049	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026161026	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 08:10:29.257828+00
1050	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:29.31904+00
1051	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026161026	status=PENDING	reserved=1665000	\N	2026-10-26 08:10:29.340189+00
1052	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026161026	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:10:29.345016+00
1053	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026161026	\N	caseNo=DSP-8A9949CB,reason=OVERDUE	\N	2026-10-26 08:10:29.358495+00
1054	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-8A9949CB	\N	REPOSSESSED	\N	2026-10-26 08:10:29.374819+00
1055	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-8A9949CB	\N	LIQUIDATING	\N	2026-10-26 08:10:29.405025+00
1056	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-8A9949CB	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 08:10:29.416008+00
1057	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026161026	\N	caseNo=DSP-4152F8C4,reason=AUTO_OOT	\N	2026-10-26 08:10:29.437999+00
1058	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@6fc94df	com.company.floorplan.domain.model.RatingConfig@384ff5aa	\N	2026-10-26 08:10:29.475839+00
1059	admin	ADMIN	BATCH_INGEST	DEALER	254	\N	accepted=1,rejected=0	\N	2026-10-26 08:10:29.493797+00
1060	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@4fe1e14c	com.company.floorplan.domain.model.RatingConfig@70033b03	\N	2026-10-26 08:10:29.544695+00
1062	admin	ADMIN	CREATE_DEALER	DEALER	256	\N	DL-CRUD-2232	\N	2026-10-26 08:10:32.047221+00
1063	admin	ADMIN	UPDATE_DEALER	DEALER	256	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:32.090217+00
1064	admin	ADMIN	UPDATE_DEALER	DEALER	256	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:32.101515+00
1065	admin	ADMIN	UPDATE_DEALER	DEALER	256	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:32.109419+00
1066	admin	ADMIN	UPDATE_DEALER	DEALER	256	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:32.116498+00
1067	admin	ADMIN	UPDATE_DEALER	DEALER	256	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:10:32.161065+00
1068	admin	ADMIN	DELETE_DEALER	DEALER	256	dealerCode=DL-CRUD-2232,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 08:10:32.214468+00
1069	admin	ADMIN	CREATE_DEALER	DEALER	257	\N	DL-SMOKE-2294	\N	2026-10-26 08:11:34.549935+00
1070	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	223	\N	limit=200000000	\N	2026-10-26 08:11:34.577432+00
1071	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:34.597846+00
1072	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026161133	status=PENDING	reserved=1665000	\N	2026-10-26 08:11:34.634814+00
1073	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026161133	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:11:34.649996+00
1074	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026161133	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 08:11:34.682836+00
1075	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026161133	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:11:34.77116+00
1076	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026161133	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 08:11:34.78841+00
1077	admin	ADMIN	INVENTORY_AUDIT	DEALER	257	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 08:11:34.839229+00
1078	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=0,rejected=1	\N	2026-10-26 08:11:34.878185+00
1079	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:34.921598+00
1080	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026161133	status=PENDING	reserved=1665000	\N	2026-10-26 08:11:34.937203+00
1081	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026161133	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:11:34.943828+00
1082	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026161133	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 08:11:34.987333+00
1083	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:35.048525+00
1084	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026161133	status=PENDING	reserved=1665000	\N	2026-10-26 08:11:35.066442+00
1085	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026161133	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:11:35.073743+00
1086	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026161133	\N	requestNo=RPR-A6F7F3F3	\N	2026-10-26 08:11:35.088194+00
1087	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026161133	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 08:11:35.104746+00
1088	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026161133	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 08:11:35.122139+00
1089	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026161133	\N	policyNo=POL-SMOKE-1026161133,insured=2000000	\N	2026-10-26 08:11:35.14509+00
1090	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026161133	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 08:11:35.160061+00
1091	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:35.174103+00
1092	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026161133	status=PENDING	reserved=1665000	\N	2026-10-26 08:11:35.190372+00
1093	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026161133	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:11:35.197951+00
1094	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026161133	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:11:35.213093+00
1095	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026161133	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 08:11:35.225198+00
1096	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026161133	\N	certNo=PAY-29389E6C,total=1665640	\N	2026-10-26 08:11:35.242846+00
1097	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	223	used=4995000	frozen=4995000,reviewNo=AR-97172A34	\N	2026-10-26 08:11:35.276842+00
1098	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	223	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 08:11:35.292096+00
1099	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:35.318009+00
1100	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026161133	status=PENDING	reserved=1665000	\N	2026-10-26 08:11:35.333949+00
1101	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026161133	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:11:35.340367+00
1102	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026161133	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 08:11:35.352925+00
1103	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:35.364624+00
1104	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026161133	status=PENDING	reserved=1665000	\N	2026-10-26 08:11:35.379023+00
1105	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026161133	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:11:35.384696+00
1106	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026161133	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 08:11:35.399191+00
1107	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:35.437212+00
1108	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026161133	status=PENDING	reserved=1665000	\N	2026-10-26 08:11:35.450805+00
1109	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026161133	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:11:35.458311+00
1110	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026161133	\N	caseNo=DSP-660506D7,reason=OVERDUE	\N	2026-10-26 08:11:35.473882+00
1111	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-660506D7	\N	REPOSSESSED	\N	2026-10-26 08:11:35.491709+00
1112	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-660506D7	\N	LIQUIDATING	\N	2026-10-26 08:11:35.50341+00
1113	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-660506D7	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 08:11:35.51328+00
1114	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026161133	\N	caseNo=DSP-68F4A8B2,reason=AUTO_OOT	\N	2026-10-26 08:11:35.530459+00
1115	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@3d6206b7	com.company.floorplan.domain.model.RatingConfig@564dc164	\N	2026-10-26 08:11:35.558361+00
1116	admin	ADMIN	BATCH_INGEST	DEALER	257	\N	accepted=1,rejected=0	\N	2026-10-26 08:11:35.571525+00
1117	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@73d37d29	com.company.floorplan.domain.model.RatingConfig@47047ecc	\N	2026-10-26 08:11:35.604103+00
1119	admin	ADMIN	CREATE_DEALER	DEALER	259	\N	DL-CRUD-2295	\N	2026-10-26 08:11:35.9194+00
1120	admin	ADMIN	UPDATE_DEALER	DEALER	259	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:11:35.936875+00
1121	admin	ADMIN	UPDATE_DEALER	DEALER	259	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:11:35.962663+00
1122	admin	ADMIN	UPDATE_DEALER	DEALER	259	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:11:35.974114+00
1123	admin	ADMIN	UPDATE_DEALER	DEALER	259	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:11:35.982629+00
1124	admin	ADMIN	UPDATE_DEALER	DEALER	259	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:11:36.017116+00
1125	admin	ADMIN	DELETE_DEALER	DEALER	259	dealerCode=DL-CRUD-2295,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 08:11:36.031488+00
1126	admin	ADMIN	ADVANCE	VEHICLE	TESTRT1026161133	status=PENDING	status=IN_STOCK,amount=500000	\N	2026-10-26 08:14:28.765771+00
1127	admin	ADMIN	ADVANCE	VEHICLE	TESTRT1026161133	status=PENDING	status=FAILED,released=500000	gateway declined	2026-10-26 08:14:31.151142+00
1128	admin	ADMIN	CREATE_DEALER	DEALER	260	\N	DL-SMOKE-3082	\N	2026-10-26 08:24:42.66669+00
1129	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	224	\N	limit=200000000	\N	2026-10-26 08:24:42.688496+00
1130	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:42.729235+00
1131	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:42.754579+00
1132	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:42.817943+00
1133	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026162441	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 08:24:42.882272+00
1134	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026162441	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:24:43.049268+00
1135	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026162441	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 08:24:43.083909+00
1136	admin	ADMIN	INVENTORY_AUDIT	DEALER	260	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 08:24:43.143187+00
1137	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=0,rejected=1	\N	2026-10-26 08:24:43.22127+00
1138	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:43.488993+00
1139	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:43.522374+00
1140	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:43.531848+00
1141	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026162441	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 08:24:43.809324+00
1142	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:43.89349+00
1143	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:43.918302+00
1144	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:43.943901+00
1145	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026162441	\N	requestNo=RPR-424DC0DD	\N	2026-10-26 08:24:43.961008+00
1146	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026162441	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 08:24:43.97256+00
1147	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026162441	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 08:24:43.99602+00
1148	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026162441	\N	policyNo=POL-SMOKE-1026162441,insured=2000000	\N	2026-10-26 08:24:44.042673+00
1149	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026162441	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 08:24:44.063968+00
1150	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:44.086356+00
1151	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:44.104297+00
1152	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:44.12327+00
1153	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026162441	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:24:44.141219+00
1154	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026162441	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 08:24:44.157779+00
1155	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026162441	\N	certNo=PAY-65AA193A,total=1665640	\N	2026-10-26 08:24:44.173313+00
1156	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	224	used=4995000	frozen=4995000,reviewNo=AR-7C557055	\N	2026-10-26 08:24:44.213726+00
1157	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	224	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 08:24:44.230604+00
1158	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:44.261964+00
1159	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:44.280608+00
1160	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:44.299127+00
1161	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026162441	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 08:24:44.313267+00
1162	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:44.325818+00
1163	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:44.336948+00
1164	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:44.354545+00
1165	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026162441	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 08:24:44.386459+00
1166	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:44.469101+00
1167	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:44.481371+00
1168	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:44.499338+00
1169	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026162441	\N	caseNo=DSP-C8AC5545,reason=OVERDUE	\N	2026-10-26 08:24:44.526801+00
1170	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-C8AC5545	\N	REPOSSESSED	\N	2026-10-26 08:24:44.546385+00
1171	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-C8AC5545	\N	LIQUIDATING	\N	2026-10-26 08:24:44.564292+00
1172	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-C8AC5545	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 08:24:44.571292+00
1173	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026162441	\N	caseNo=DSP-29F6ADAA,reason=AUTO_OOT	\N	2026-10-26 08:24:44.582213+00
1174	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@6212eaea	com.company.floorplan.domain.model.RatingConfig@76ecf609	\N	2026-10-26 08:24:44.624857+00
1175	admin	ADMIN	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:44.633328+00
1176	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@33c464c2	com.company.floorplan.domain.model.RatingConfig@5a0bdbfa	\N	2026-10-26 08:24:44.699415+00
1177	operator	USER	BATCH_INGEST	DEALER	260	\N	accepted=1,rejected=0	\N	2026-10-26 08:24:44.832961+00
1178	operator	USER	ADVANCE	VEHICLE	TESTSOD1026162441	status=PENDING	reserved=1665000	\N	2026-10-26 08:24:44.845836+00
1179	admin	ADMIN	ADVANCE	VEHICLE	TESTSOD1026162441	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:24:44.865926+00
1181	admin	ADMIN	CREATE_DEALER	DEALER	262	\N	DL-CRUD-3086	\N	2026-10-26 08:24:46.362144+00
1182	admin	ADMIN	UPDATE_DEALER	DEALER	262	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:24:46.379652+00
1183	admin	ADMIN	UPDATE_DEALER	DEALER	262	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:24:46.412421+00
1184	admin	ADMIN	UPDATE_DEALER	DEALER	262	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:24:46.424786+00
1185	admin	ADMIN	UPDATE_DEALER	DEALER	262	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:24:46.431611+00
1186	admin	ADMIN	UPDATE_DEALER	DEALER	262	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:24:46.469077+00
1187	admin	ADMIN	DELETE_DEALER	DEALER	262	dealerCode=DL-CRUD-3086,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 08:24:46.488022+00
1188	admin	ADMIN	CREATE_DEALER	DEALER	263	\N	DL-SMOKE-3105	\N	2026-10-26 08:25:05.432523+00
1189	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	225	\N	limit=200000000	\N	2026-10-26 08:25:05.440659+00
1190	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:05.464361+00
1191	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:05.480068+00
1192	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:05.514345+00
1193	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026162504	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 08:25:05.536715+00
1194	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026162504	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:25:05.679877+00
1195	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026162504	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 08:25:05.712296+00
1196	admin	ADMIN	INVENTORY_AUDIT	DEALER	263	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 08:25:05.810862+00
1197	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=0,rejected=1	\N	2026-10-26 08:25:05.851711+00
1198	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:06.105556+00
1199	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:06.118078+00
1200	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:06.14214+00
1201	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026162504	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 08:25:06.455026+00
1202	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:06.555152+00
1203	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:06.578899+00
1204	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:06.609766+00
1205	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026162504	\N	requestNo=RPR-F76D761E	\N	2026-10-26 08:25:06.620449+00
1206	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026162504	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 08:25:06.639774+00
1207	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026162504	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 08:25:06.671042+00
1208	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026162504	\N	policyNo=POL-SMOKE-1026162504,insured=2000000	\N	2026-10-26 08:25:06.70367+00
1209	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026162504	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 08:25:06.70935+00
1210	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:06.715757+00
1211	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:06.751124+00
1212	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:06.758408+00
1213	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026162504	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 08:25:06.767793+00
1214	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026162504	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 08:25:06.774315+00
1215	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026162504	\N	certNo=PAY-0F75DA0B,total=1665640	\N	2026-10-26 08:25:06.782617+00
1216	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	225	used=4995000	frozen=4995000,reviewNo=AR-F276CB91	\N	2026-10-26 08:25:06.811482+00
1217	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	225	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 08:25:06.818099+00
1218	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:06.853102+00
1219	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:06.889742+00
1220	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:06.922626+00
1221	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026162504	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 08:25:06.934136+00
1222	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:06.967869+00
1223	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:07.002301+00
1224	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:07.01975+00
1225	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026162504	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 08:25:07.032891+00
1226	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:07.098115+00
1227	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:07.114174+00
1228	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:07.126348+00
1229	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026162504	\N	caseNo=DSP-D21D0C88,reason=OVERDUE	\N	2026-10-26 08:25:07.154583+00
1230	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-D21D0C88	\N	REPOSSESSED	\N	2026-10-26 08:25:07.165796+00
1231	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-D21D0C88	\N	LIQUIDATING	\N	2026-10-26 08:25:07.17613+00
1232	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-D21D0C88	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 08:25:07.185315+00
1233	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026162504	\N	caseNo=DSP-06E94EDD,reason=AUTO_OOT	\N	2026-10-26 08:25:07.216418+00
1234	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@2df938a7	com.company.floorplan.domain.model.RatingConfig@712062d9	\N	2026-10-26 08:25:07.254217+00
1235	admin	ADMIN	BATCH_INGEST	DEALER	263	\N	accepted=1,rejected=0	\N	2026-10-26 08:25:07.266448+00
1236	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@14fc47db	com.company.floorplan.domain.model.RatingConfig@10e0475d	\N	2026-10-26 08:25:07.29757+00
1238	operator	USER	ADVANCE	VEHICLE	TESTSOD1026162504	status=PENDING	reserved=1665000	\N	2026-10-26 08:25:07.440487+00
1239	admin	ADMIN	ADVANCE	VEHICLE	TESTSOD1026162504	status=PENDING	status=IN_STOCK,amount=1665000	\N	2026-10-26 08:25:07.458421+00
1241	admin	ADMIN	CREATE_DEALER	DEALER	265	\N	DL-CRUD-3108	\N	2026-10-26 08:25:08.995795+00
1242	admin	ADMIN	UPDATE_DEALER	DEALER	265	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:25:09.030369+00
1243	admin	ADMIN	UPDATE_DEALER	DEALER	265	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:25:09.035807+00
1244	admin	ADMIN	UPDATE_DEALER	DEALER	265	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:25:09.04498+00
1245	admin	ADMIN	UPDATE_DEALER	DEALER	265	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:25:09.056809+00
1246	admin	ADMIN	UPDATE_DEALER	DEALER	265	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 08:25:09.110333+00
1247	admin	ADMIN	DELETE_DEALER	DEALER	265	dealerCode=DL-CRUD-3108,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 08:25:09.124027+00
1248	admin	ADMIN	CREATE_DEALER	DEALER	266	\N	DL-SMOKE-6636	\N	2026-10-26 09:23:56.421972+00
1249	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	226	\N	limit=200000000	\N	2026-10-26 09:23:56.452595+00
1250	admin	ADMIN	BATCH_INGEST	DEALER	266	\N	accepted=1,rejected=0	\N	2026-10-26 09:23:56.485885+00
1251	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026172353	status=PENDING	reserved=1665000	\N	2026-10-26 09:23:56.517454+00
1252	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026172353	status=PENDING	status=PROCESSING,channelRef=PAY-00000001	\N	2026-10-26 09:23:56.541786+00
1253	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026172353	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:23:56.562932+00
1254	admin	ADMIN	CREATE_DEALER	DEALER	267	\N	DL-SMOKE-6685	\N	2026-10-26 09:24:45.596684+00
1255	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	227	\N	limit=200000000	\N	2026-10-26 09:24:45.611537+00
1256	admin	ADMIN	BATCH_INGEST	DEALER	267	\N	accepted=1,rejected=0	\N	2026-10-26 09:24:45.624505+00
1257	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026172442	status=PENDING	reserved=1665000	\N	2026-10-26 09:24:45.656237+00
1258	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026172442	status=PENDING	status=PROCESSING,channelRef=PAY-00000002	\N	2026-10-26 09:24:45.672383+00
1259	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026172442	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:24:45.704092+00
1260	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026172442	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 09:24:45.781487+00
1261	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026172442	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 09:24:45.919838+00
1262	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026172442	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 09:24:45.95547+00
1263	admin	ADMIN	INVENTORY_AUDIT	DEALER	267	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 09:24:46.00535+00
1264	admin	ADMIN	BATCH_INGEST	DEALER	267	\N	accepted=0,rejected=1	\N	2026-10-26 09:24:46.070259+00
1265	admin	ADMIN	BATCH_INGEST	DEALER	267	\N	accepted=1,rejected=0	\N	2026-10-26 09:24:46.848252+00
1266	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026172442	status=PENDING	reserved=1665000	\N	2026-10-26 09:24:46.864807+00
1267	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026172442	status=PENDING	status=PROCESSING,channelRef=PAY-00000003	\N	2026-10-26 09:24:46.882002+00
1268	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026172442	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:24:46.895695+00
1269	admin	ADMIN	CREATE_DEALER	DEALER	268	\N	DL-SMOKE-6707	\N	2026-10-26 09:25:07.945432+00
1270	admin	ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	228	\N	limit=200000000	\N	2026-10-26 09:25:07.976462+00
1271	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:07.985305+00
1272	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:07.999452+00
1273	admin	ADMIN	ADVANCE	VEHICLE	TESTVIN1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000004	\N	2026-10-26 09:25:08.01326+00
1274	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:08.022597+00
1275	admin	ADMIN	SET_SECURITY	VEHICLE	TESTVIN1026172506	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 09:25:08.084804+00
1276	admin	ADMIN	MARK_SOLD	VEHICLE	TESTVIN1026172506	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 09:25:08.170168+00
1277	admin	ADMIN	REPAYMENT	VEHICLE	TESTVIN1026172506	principal=1665000	settled,interest=640,released=1665000	\N	2026-10-26 09:25:08.194798+00
1278	admin	ADMIN	INVENTORY_AUDIT	DEALER	268	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 09:25:08.273418+00
1279	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=0,rejected=1	\N	2026-10-26 09:25:08.334348+00
1280	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:08.645341+00
1281	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:08.67907+00
1282	admin	ADMIN	ADVANCE	VEHICLE	TESTCT1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000005	\N	2026-10-26 09:25:08.692231+00
1283	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:08.723329+00
1284	admin	ADMIN	CURTAIL_PAY	VEHICLE	TESTCT1026172506	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 09:25:09.042855+00
1285	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:09.089398+00
1286	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:09.120109+00
1287	admin	ADMIN	ADVANCE	VEHICLE	TESTRP1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000006	\N	2026-10-26 09:25:09.149917+00
1288	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:09.160616+00
1289	admin	ADMIN	REPURCHASE_REQ	VEHICLE	TESTRP1026172506	\N	requestNo=RPR-01098802	\N	2026-10-26 09:25:09.171692+00
1290	admin	ADMIN	REPURCHASE_FULFILL	VEHICLE	TESTRP1026172506	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 09:25:09.183314+00
1291	admin	ADMIN	PARTIAL_REPAY	VEHICLE	TESTRP1026172506	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 09:25:09.19509+00
1292	admin	ADMIN	INSURANCE_BIND	VEHICLE	TESTRP1026172506	\N	policyNo=POL-SMOKE-1026172506,insured=2000000	\N	2026-10-26 09:25:09.227176+00
1293	admin	ADMIN	INSURANCE_CLAIM	VEHICLE	TESTRP1026172506	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 09:25:09.238845+00
1294	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:09.24765+00
1295	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:09.258381+00
1296	admin	ADMIN	ADVANCE	VEHICLE	TESTEX1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000007	\N	2026-10-26 09:25:09.269389+00
1297	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTEX1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:09.289847+00
1298	admin	ADMIN	MARK_SOLD	VEHICLE	TESTEX1026172506	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 09:25:09.299463+00
1299	admin	ADMIN	EXTENSION	VEHICLE	TESTEX1026172506	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 09:25:09.310335+00
1300	admin	ADMIN	PAYOFF_ISSUE	VEHICLE	TESTVIN1026172506	\N	certNo=PAY-3253D07D,total=1665640	\N	2026-10-26 09:25:09.322955+00
1301	admin	ADMIN	ANNUAL_REVIEW_INIT	CREDIT_LINE	228	used=4995000	frozen=4995000,reviewNo=AR-EA0A7A99	\N	2026-10-26 09:25:09.344598+00
1302	admin	ADMIN	ANNUAL_REVIEW_DONE	CREDIT_LINE	228	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 09:25:09.35841+00
1303	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:09.382768+00
1304	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:09.411293+00
1305	admin	ADMIN	ADVANCE	VEHICLE	TESTWN1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000008	\N	2026-10-26 09:25:09.421737+00
1306	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTWN1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:09.441691+00
1307	admin	ADMIN	MARK_SOLD	VEHICLE	TESTWN1026172506	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 09:25:09.451299+00
1308	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:09.460376+00
1309	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:09.489792+00
1310	admin	ADMIN	ADVANCE	VEHICLE	TESTGR1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000009	\N	2026-10-26 09:25:09.502621+00
1311	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTGR1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:09.535679+00
1312	admin	ADMIN	MARK_SOLD	VEHICLE	TESTGR1026172506	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 09:25:09.568218+00
1313	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:09.613903+00
1314	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:09.627149+00
1315	admin	ADMIN	ADVANCE	VEHICLE	TESTDP1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000010	\N	2026-10-26 09:25:09.66116+00
1316	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTDP1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:09.692374+00
1317	admin	ADMIN	DISPOSAL_OPEN	VEHICLE	TESTDP1026172506	\N	caseNo=DSP-5D07338C,reason=OVERDUE	\N	2026-10-26 09:25:09.702477+00
1318	admin	ADMIN	DISPOSAL_REPO	DISPOSAL	DSP-5D07338C	\N	REPOSSESSED	\N	2026-10-26 09:25:09.720729+00
1319	admin	ADMIN	DISPOSAL_LIQ	DISPOSAL	DSP-5D07338C	\N	LIQUIDATING	\N	2026-10-26 09:25:09.753192+00
1320	admin	ADMIN	DISPOSAL_CLOSE	DISPOSAL	DSP-5D07338C	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 09:25:09.785694+00
1321	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026172506	\N	caseNo=DSP-C5629AD8,reason=AUTO_OOT	\N	2026-10-26 09:25:09.816263+00
1322	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@5d79e459	com.company.floorplan.domain.model.RatingConfig@2273b4fd	\N	2026-10-26 09:25:09.879897+00
1323	admin	ADMIN	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:09.9104+00
1324	admin	ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@1b79d5f2	com.company.floorplan.domain.model.RatingConfig@5549b8d2	\N	2026-10-26 09:25:09.934072+00
1325	operator	USER	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:10.056388+00
1326	operator	USER	ADVANCE	VEHICLE	TESTSOD1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:10.066883+00
1327	admin	ADMIN	ADVANCE	VEHICLE	TESTSOD1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000011	\N	2026-10-26 09:25:10.114089+00
1328	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTSOD1026172506	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 09:25:10.168765+00
1329	operator	USER	BATCH_INGEST	DEALER	268	\N	accepted=1,rejected=0	\N	2026-10-26 09:25:10.191125+00
1330	operator	USER	ADVANCE	VEHICLE	TESTFAIL1026172506	status=PENDING	reserved=1665000	\N	2026-10-26 09:25:10.201426+00
1331	admin	ADMIN	ADVANCE	VEHICLE	TESTFAIL1026172506	status=PENDING	status=PROCESSING,channelRef=PAY-00000012	\N	2026-10-26 09:25:10.222706+00
1332	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTFAIL1026172506	status=FAILED	status=FAILED,released=1665000	GATEWAY_DECLINED	2026-10-26 09:25:10.25332+00
1334	admin	ADMIN	CREATE_DEALER	DEALER	270	\N	DL-CRUD-6711	\N	2026-10-26 09:25:11.747913+00
1335	admin	ADMIN	UPDATE_DEALER	DEALER	270	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 09:25:11.764813+00
1336	admin	ADMIN	UPDATE_DEALER	DEALER	270	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 09:25:11.793703+00
1337	admin	ADMIN	UPDATE_DEALER	DEALER	270	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 09:25:11.801846+00
1338	admin	ADMIN	UPDATE_DEALER	DEALER	270	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 09:25:11.809796+00
1339	admin	ADMIN	UPDATE_DEALER	DEALER	270	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 09:25:11.845571+00
1340	admin	ADMIN	DELETE_DEALER	DEALER	270	dealerCode=DL-CRUD-6711,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 09:25:11.857241+00
1341	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	271	\N	DL-SMOKE-13090	\N	2026-10-26 11:11:30.840253+00
1342	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	272	\N	DL-SMOKE-13537	\N	2026-10-26 11:18:57.266042+00
1343	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	229	\N	limit=200000000	\N	2026-10-26 11:18:57.299992+00
1344	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	273	\N	DL-SMOKE-13921	\N	2026-10-26 11:25:21.511547+00
1345	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	230	\N	limit=200000000	\N	2026-10-26 11:25:21.532841+00
1346	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	274	\N	DL-SMOKE-14161	\N	2026-10-26 11:29:21.667364+00
1347	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	231	\N	limit=200000000	\N	2026-10-26 11:29:21.686588+00
1348	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	275	\N	DL-SMOKE-14265	\N	2026-10-26 11:31:05.067381+00
1349	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	232	\N	limit=200000000	\N	2026-10-26 11:31:05.088519+00
1350	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	275	\N	accepted=1,rejected=0	\N	2026-10-26 11:31:05.176383+00
1351	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTVIN1026193103	status=PENDING	reserved=1665000	\N	2026-10-26 11:31:05.289092+00
1352	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTVIN1026193103	status=PENDING	status=PROCESSING,channelRef=PAY-00000001	\N	2026-10-26 11:31:05.376794+00
1353	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026193103	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:31:05.390405+00
1354	settlement	SETTLEMENT_OFFICER	SET_SECURITY	VEHICLE	TESTVIN1026193103	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 11:31:05.49782+00
1355	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTVIN1026193103	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:31:05.583215+00
1356	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	TESTVIN1026193103	principal=1665000	settled,interest=0,released=1665000	\N	2026-10-26 11:31:05.610962+00
1357	review_op	PURCHASE_REVIEWER	INVENTORY_AUDIT	DEALER	275	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 11:31:05.643549+00
1358	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	275	\N	accepted=0,rejected=1	\N	2026-10-26 11:31:05.67704+00
1359	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	275	\N	accepted=1,rejected=0	\N	2026-10-26 11:31:05.936825+00
1360	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTCT1026193103	status=PENDING	reserved=1665000	\N	2026-10-26 11:31:05.949094+00
1361	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTCT1026193103	status=PENDING	status=PROCESSING,channelRef=PAY-00000002	\N	2026-10-26 11:31:05.984445+00
1362	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026193103	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:31:06.014166+00
1363	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	275	\N	accepted=1,rejected=0	\N	2026-10-26 11:31:06.027866+00
1364	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTRP1026193103	status=PENDING	reserved=1665000	\N	2026-10-26 11:31:06.039609+00
1365	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTRP1026193103	status=PENDING	status=PROCESSING,channelRef=PAY-00000003	\N	2026-10-26 11:31:06.053243+00
1366	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026193103	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:31:06.062091+00
1367	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_REQ	VEHICLE	TESTRP1026193103	\N	requestNo=RPR-3F6DEB9F	\N	2026-10-26 11:31:06.137555+00
1368	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_FULFILL	VEHICLE	TESTRP1026193103	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 11:31:06.14909+00
1369	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	276	\N	DL-SMOKE-14276	\N	2026-10-26 11:31:16.859942+00
1370	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	233	\N	limit=200000000	\N	2026-10-26 11:31:16.867883+00
1371	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	276	\N	accepted=1,rejected=0	\N	2026-10-26 11:31:16.955293+00
1372	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTVIN1026193115	status=PENDING	reserved=1665000	\N	2026-10-26 11:31:17.053393+00
1373	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTVIN1026193115	status=PENDING	status=PROCESSING,channelRef=PAY-00000004	\N	2026-10-26 11:31:17.145694+00
1374	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026193115	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:31:17.1549+00
1375	settlement	SETTLEMENT_OFFICER	SET_SECURITY	VEHICLE	TESTVIN1026193115	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 11:31:17.283312+00
1376	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTVIN1026193115	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:31:17.341226+00
1377	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	TESTVIN1026193115	principal=1665000	settled,interest=0,released=1665000	\N	2026-10-26 11:31:17.375572+00
1378	review_op	PURCHASE_REVIEWER	INVENTORY_AUDIT	DEALER	276	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 11:31:17.422591+00
1379	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	276	\N	accepted=0,rejected=1	\N	2026-10-26 11:31:17.440608+00
1380	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	276	\N	accepted=1,rejected=0	\N	2026-10-26 11:31:17.739826+00
1381	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTCT1026193115	status=PENDING	reserved=1665000	\N	2026-10-26 11:31:17.771955+00
1382	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTCT1026193115	status=PENDING	status=PROCESSING,channelRef=PAY-00000005	\N	2026-10-26 11:31:17.78542+00
1383	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026193115	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:31:17.818575+00
1384	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	276	\N	accepted=1,rejected=0	\N	2026-10-26 11:31:17.831124+00
1490	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:48.586321+00
1385	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTRP1026193115	status=PENDING	reserved=1665000	\N	2026-10-26 11:31:17.866244+00
1386	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTRP1026193115	status=PENDING	status=PROCESSING,channelRef=PAY-00000006	\N	2026-10-26 11:31:17.88085+00
1387	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026193115	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:31:17.89014+00
1388	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_REQ	VEHICLE	TESTRP1026193115	\N	requestNo=RPR-5F4C8096	\N	2026-10-26 11:31:17.989568+00
1389	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_FULFILL	VEHICLE	TESTRP1026193115	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 11:31:17.998692+00
1390	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	277	\N	DL-SMOKE-14354	\N	2026-10-26 11:32:34.106267+00
1391	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	234	\N	limit=200000000	\N	2026-10-26 11:32:34.112821+00
1392	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	277	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:34.200865+00
1393	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTVIN1026193233	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:34.274112+00
1394	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTVIN1026193233	status=PENDING	status=PROCESSING,channelRef=PAY-00000007	\N	2026-10-26 11:32:34.349938+00
1395	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026193233	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:34.358112+00
1396	settlement	SETTLEMENT_OFFICER	SET_SECURITY	VEHICLE	TESTVIN1026193233	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 11:32:34.482259+00
1397	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTVIN1026193233	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:32:35.14267+00
1398	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	TESTVIN1026193233	principal=1665000	settled,interest=30080,released=1665000	\N	2026-10-26 11:32:35.168858+00
1399	review_op	PURCHASE_REVIEWER	INVENTORY_AUDIT	DEALER	277	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 11:32:35.188025+00
1400	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	277	\N	accepted=0,rejected=1	\N	2026-10-26 11:32:35.22655+00
1401	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	277	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:35.478097+00
1402	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTCT1026193233	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:35.512522+00
1403	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTCT1026193233	status=PENDING	status=PROCESSING,channelRef=PAY-00000008	\N	2026-10-26 11:32:35.522993+00
1404	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026193233	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:35.544152+00
1405	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	277	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:35.660603+00
1406	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTRP1026193233	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:35.669747+00
1407	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTRP1026193233	status=PENDING	status=PROCESSING,channelRef=PAY-00000009	\N	2026-10-26 11:32:35.680284+00
1408	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026193233	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:35.699738+00
1409	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_REQ	VEHICLE	TESTRP1026193233	\N	requestNo=RPR-0BE27C8B	\N	2026-10-26 11:32:35.773121+00
1410	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_FULFILL	VEHICLE	TESTRP1026193233	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 11:32:35.780899+00
1411	collection	COLLECTION_OFFICER	PARTIAL_REPAY	VEHICLE	TESTRP1026193233	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 11:32:35.789573+00
1412	advisory	RISK_ADVISORY_OFFICER	INSURANCE_BIND	VEHICLE	TESTRP1026193233	\N	policyNo=POL-SMOKE-1026193233,insured=2000000	\N	2026-10-26 11:32:35.815693+00
1413	advisory	RISK_ADVISORY_OFFICER	INSURANCE_CLAIM	VEHICLE	TESTRP1026193233	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 11:32:35.826826+00
1414	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	277	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:35.862584+00
1415	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTEX1026193233	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:35.87493+00
1416	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTEX1026193233	status=PENDING	status=PROCESSING,channelRef=PAY-00000010	\N	2026-10-26 11:32:35.886795+00
1417	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTEX1026193233	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:35.894811+00
1418	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTEX1026193233	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:32:35.902955+00
1419	advisory	RISK_ADVISORY_OFFICER	EXTENSION	VEHICLE	TESTEX1026193233	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 11:32:35.910972+00
1420	settlement	SETTLEMENT_OFFICER	PAYOFF_ISSUE	VEHICLE	TESTVIN1026193233	\N	certNo=PAY-051724D8,total=1695080	\N	2026-10-26 11:32:35.9341+00
1421	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	278	\N	DL-SMOKE-14377	\N	2026-10-26 11:32:57.443613+00
1422	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	235	\N	limit=200000000	\N	2026-10-26 11:32:57.451174+00
1423	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:57.522398+00
1424	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTVIN1026193256	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:57.597571+00
1425	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTVIN1026193256	status=PENDING	status=PROCESSING,channelRef=PAY-00000011	\N	2026-10-26 11:32:57.6864+00
1426	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026193256	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:57.693578+00
1427	settlement	SETTLEMENT_OFFICER	SET_SECURITY	VEHICLE	TESTVIN1026193256	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 11:32:57.818485+00
1428	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTVIN1026193256	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:32:58.215078+00
1429	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	TESTVIN1026193256	principal=1665000	settled,interest=33760,released=1665000	\N	2026-10-26 11:32:58.24653+00
1430	review_op	PURCHASE_REVIEWER	INVENTORY_AUDIT	DEALER	278	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 11:32:58.265592+00
1431	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=0,rejected=1	\N	2026-10-26 11:32:58.302323+00
1432	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:58.567316+00
1433	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTCT1026193256	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:58.577062+00
1434	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTCT1026193256	status=PENDING	status=PROCESSING,channelRef=PAY-00000012	\N	2026-10-26 11:32:58.587148+00
1435	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026193256	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:58.594135+00
1436	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:58.683789+00
1437	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTRP1026193256	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:58.693897+00
1595	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:40.794245+00
1438	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTRP1026193256	status=PENDING	status=PROCESSING,channelRef=PAY-00000013	\N	2026-10-26 11:32:58.704131+00
1439	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026193256	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:58.723943+00
1440	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_REQ	VEHICLE	TESTRP1026193256	\N	requestNo=RPR-6530B5F0	\N	2026-10-26 11:32:58.796006+00
1441	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_FULFILL	VEHICLE	TESTRP1026193256	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 11:32:58.803399+00
1442	collection	COLLECTION_OFFICER	PARTIAL_REPAY	VEHICLE	TESTRP1026193256	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 11:32:58.811412+00
1443	advisory	RISK_ADVISORY_OFFICER	INSURANCE_BIND	VEHICLE	TESTRP1026193256	\N	policyNo=POL-SMOKE-1026193256,insured=2000000	\N	2026-10-26 11:32:58.823764+00
1444	advisory	RISK_ADVISORY_OFFICER	INSURANCE_CLAIM	VEHICLE	TESTRP1026193256	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 11:32:58.847935+00
1445	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:58.858169+00
1446	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTEX1026193256	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:58.868782+00
1447	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTEX1026193256	status=PENDING	status=PROCESSING,channelRef=PAY-00000014	\N	2026-10-26 11:32:58.880406+00
1448	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTEX1026193256	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:58.907928+00
1449	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTEX1026193256	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:32:58.915215+00
1450	advisory	RISK_ADVISORY_OFFICER	EXTENSION	VEHICLE	TESTEX1026193256	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 11:32:58.92267+00
1451	settlement	SETTLEMENT_OFFICER	PAYOFF_ISSUE	VEHICLE	TESTVIN1026193256	\N	certNo=PAY-A131FA43,total=1698760	\N	2026-10-26 11:32:58.932416+00
1452	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_INIT	CREDIT_LINE	235	used=4995000	frozen=4995000,reviewNo=AR-403E53E0	\N	2026-10-26 11:32:59.048466+00
1453	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_DONE	CREDIT_LINE	235	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 11:32:59.079912+00
1454	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	232	used=3330000	frozen=3330000,reviewNo=AR-F67DA241	\N	2026-10-26 11:32:59.087865+00
1455	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	233	used=3330000	frozen=3330000,reviewNo=AR-486E765D	\N	2026-10-26 11:32:59.087865+00
1456	system	\N	ANNUAL_REVIEW_INIT	CREDIT_LINE	234	used=4995000	frozen=4995000,reviewNo=AR-A02911CC	\N	2026-10-26 11:32:59.087865+00
1457	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:59.125637+00
1458	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTWN1026193256	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:59.134549+00
1459	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTWN1026193256	status=PENDING	status=PROCESSING,channelRef=PAY-00000015	\N	2026-10-26 11:32:59.144693+00
1460	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTWN1026193256	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:59.152479+00
1461	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTWN1026193256	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 11:32:59.160122+00
1462	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:59.16749+00
1463	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTGR1026193256	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:59.176807+00
1464	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTGR1026193256	status=PENDING	status=PROCESSING,channelRef=PAY-00000016	\N	2026-10-26 11:32:59.187055+00
1465	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTGR1026193256	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:59.194483+00
1466	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTGR1026193256	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 11:32:59.202174+00
1467	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:59.23168+00
1468	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTDP1026193256	status=PENDING	reserved=1665000	\N	2026-10-26 11:32:59.267709+00
1469	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTDP1026193256	status=PENDING	status=PROCESSING,channelRef=PAY-00000017	\N	2026-10-26 11:32:59.278384+00
1470	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTDP1026193256	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:32:59.299536+00
1471	disposal	DISPOSAL_OFFICER	DISPOSAL_OPEN	VEHICLE	TESTDP1026193256	\N	caseNo=DSP-EE7E4489,reason=OVERDUE	\N	2026-10-26 11:32:59.391606+00
1472	disposal	DISPOSAL_OFFICER	DISPOSAL_REPO	DISPOSAL	DSP-EE7E4489	\N	REPOSSESSED	\N	2026-10-26 11:32:59.403657+00
1473	disposal	DISPOSAL_OFFICER	DISPOSAL_LIQ	DISPOSAL	DSP-EE7E4489	\N	LIQUIDATING	\N	2026-10-26 11:32:59.410571+00
1474	disposal	DISPOSAL_OFFICER	DISPOSAL_CLOSE	DISPOSAL	DSP-EE7E4489	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 11:32:59.418102+00
1475	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026193256	\N	caseNo=DSP-46B6C13D,reason=AUTO_OOT	\N	2026-10-26 11:32:59.428398+00
1476	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@5ed385a3	com.company.floorplan.domain.model.RatingConfig@49e00990	\N	2026-10-26 11:32:59.470973+00
1477	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	278	\N	accepted=1,rejected=0	\N	2026-10-26 11:32:59.501543+00
1478	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@2ded6889	com.company.floorplan.domain.model.RatingConfig@44fdb70f	\N	2026-10-26 11:32:59.534099+00
1479	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	279	\N	DL-SMOKE-14427	\N	2026-10-26 11:33:47.786151+00
1480	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	236	\N	limit=200000000	\N	2026-10-26 11:33:47.792942+00
1481	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:47.881+00
1482	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTVIN1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:47.954375+00
1483	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTVIN1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000018	\N	2026-10-26 11:33:48.055901+00
1484	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:48.063367+00
1485	settlement	SETTLEMENT_OFFICER	SET_SECURITY	VEHICLE	TESTVIN1026193346	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 11:33:48.165947+00
1486	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTVIN1026193346	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:33:48.277855+00
1487	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	TESTVIN1026193346	principal=1665000	settled,interest=41920,released=1665000	\N	2026-10-26 11:33:48.305792+00
1488	review_op	PURCHASE_REVIEWER	INVENTORY_AUDIT	DEALER	279	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 11:33:48.322617+00
1489	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=0,rejected=1	\N	2026-10-26 11:33:48.338289+00
1491	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTCT1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:48.595622+00
1492	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTCT1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000019	\N	2026-10-26 11:33:48.606935+00
1493	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:48.614655+00
1494	collection	COLLECTION_OFFICER	CURTAIL_PAY	VEHICLE	TESTCT1026193346	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 11:33:48.963102+00
1495	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:49.041141+00
1496	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTRP1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:49.048876+00
1497	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTRP1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000020	\N	2026-10-26 11:33:49.074282+00
1498	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:49.086133+00
1499	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_REQ	VEHICLE	TESTRP1026193346	\N	requestNo=RPR-C33C9399	\N	2026-10-26 11:33:49.156542+00
1500	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_FULFILL	VEHICLE	TESTRP1026193346	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 11:33:49.162511+00
1501	collection	COLLECTION_OFFICER	PARTIAL_REPAY	VEHICLE	TESTRP1026193346	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 11:33:49.169793+00
1502	advisory	RISK_ADVISORY_OFFICER	INSURANCE_BIND	VEHICLE	TESTRP1026193346	\N	policyNo=POL-SMOKE-1026193346,insured=2000000	\N	2026-10-26 11:33:49.197392+00
1503	advisory	RISK_ADVISORY_OFFICER	INSURANCE_CLAIM	VEHICLE	TESTRP1026193346	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 11:33:49.203334+00
1504	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:49.227774+00
1505	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTEX1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:49.235477+00
1506	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTEX1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000021	\N	2026-10-26 11:33:49.245123+00
1507	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTEX1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:49.251858+00
1508	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTEX1026193346	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:33:49.258735+00
1509	advisory	RISK_ADVISORY_OFFICER	EXTENSION	VEHICLE	TESTEX1026193346	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 11:33:49.265234+00
1510	settlement	SETTLEMENT_OFFICER	PAYOFF_ISSUE	VEHICLE	TESTVIN1026193346	\N	certNo=PAY-71AB0A99,total=1706920	\N	2026-10-26 11:33:49.27242+00
1511	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_INIT	CREDIT_LINE	236	used=4995000	frozen=4995000,reviewNo=AR-AEA363D4	\N	2026-10-26 11:33:49.383488+00
1512	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_DONE	CREDIT_LINE	236	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 11:33:49.389996+00
1513	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:49.422272+00
1514	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTWN1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:49.450855+00
1515	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTWN1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000022	\N	2026-10-26 11:33:49.479139+00
1516	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTWN1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:49.486086+00
1517	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTWN1026193346	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 11:33:49.493468+00
1518	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:49.501395+00
1519	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTGR1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:49.525667+00
1520	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTGR1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000023	\N	2026-10-26 11:33:49.535085+00
1521	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTGR1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:49.556305+00
1522	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTGR1026193346	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 11:33:49.563722+00
1523	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:49.618346+00
1524	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTDP1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:49.629682+00
1525	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTDP1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000024	\N	2026-10-26 11:33:49.641317+00
1526	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTDP1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:49.649389+00
1527	disposal	DISPOSAL_OFFICER	DISPOSAL_OPEN	VEHICLE	TESTDP1026193346	\N	caseNo=DSP-DB4DCF26,reason=OVERDUE	\N	2026-10-26 11:33:49.762776+00
1528	disposal	DISPOSAL_OFFICER	DISPOSAL_REPO	DISPOSAL	DSP-DB4DCF26	\N	REPOSSESSED	\N	2026-10-26 11:33:49.770764+00
1529	disposal	DISPOSAL_OFFICER	DISPOSAL_LIQ	DISPOSAL	DSP-DB4DCF26	\N	LIQUIDATING	\N	2026-10-26 11:33:49.776887+00
1530	disposal	DISPOSAL_OFFICER	DISPOSAL_CLOSE	DISPOSAL	DSP-DB4DCF26	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 11:33:49.784414+00
1531	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026193346	\N	caseNo=DSP-45D7D134,reason=AUTO_OOT	\N	2026-10-26 11:33:49.809749+00
1532	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@4172964b	com.company.floorplan.domain.model.RatingConfig@11584f2a	\N	2026-10-26 11:33:49.839889+00
1533	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:49.8468+00
1534	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@1273b025	com.company.floorplan.domain.model.RatingConfig@128ec75a	\N	2026-10-26 11:33:49.88055+00
1535	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:50.057663+00
1536	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTSOD1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:50.083927+00
1537	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTSOD1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000025	\N	2026-10-26 11:33:50.541892+00
1538	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTSOD1026193346	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:33:50.577932+00
1539	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	279	\N	accepted=1,rejected=0	\N	2026-10-26 11:33:50.585556+00
1540	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTFAIL1026193346	status=PENDING	reserved=1665000	\N	2026-10-26 11:33:50.593298+00
1541	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTFAIL1026193346	status=PENDING	status=PROCESSING,channelRef=PAY-00000026	\N	2026-10-26 11:33:50.617767+00
1583	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_INIT	CREDIT_LINE	237	used=4995000	frozen=4995000,reviewNo=AR-9FC1FB29	\N	2026-10-26 11:42:40.561567+00
1542	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTFAIL1026193346	status=FAILED	status=FAILED,released=1665000	GATEWAY_DECLINED	2026-10-26 11:33:50.628345+00
1544	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	281	\N	DL-CRUD-14431	\N	2026-10-26 11:33:51.956912+00
1545	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	281	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:33:51.993513+00
1546	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	281	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:33:52.019431+00
1547	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	281	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:33:52.035281+00
1548	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	281	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:33:52.041233+00
1549	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	281	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:33:52.06156+00
1550	admin	SYSTEM_ADMIN	DELETE_DEALER	DEALER	281	dealerCode=DL-CRUD-14431,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 11:33:52.071514+00
1551	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	282	\N	DL-SMOKE-14958	\N	2026-10-26 11:42:38.571478+00
1552	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	237	\N	limit=200000000	\N	2026-10-26 11:42:38.585685+00
1553	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:38.675641+00
1554	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTVIN1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:38.764348+00
1555	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTVIN1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000001	\N	2026-10-26 11:42:38.852957+00
1556	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:38.879645+00
1557	settlement	SETTLEMENT_OFFICER	SET_SECURITY	VEHICLE	TESTVIN1026194237	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 11:42:39.033354+00
1558	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTVIN1026194237	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:42:39.251689+00
1559	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	TESTVIN1026194237	principal=1665000	settled,interest=30880,released=1665000	\N	2026-10-26 11:42:39.263114+00
1560	review_op	PURCHASE_REVIEWER	INVENTORY_AUDIT	DEALER	282	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 11:42:39.297461+00
1561	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=0,rejected=1	\N	2026-10-26 11:42:39.3195+00
1562	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:39.6101+00
1563	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTCT1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:39.621741+00
1564	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTCT1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000002	\N	2026-10-26 11:42:39.634235+00
1565	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:39.661191+00
1566	collection	COLLECTION_OFFICER	CURTAIL_PAY	VEHICLE	TESTCT1026194237	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 11:42:40.026126+00
1567	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:40.086081+00
1568	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTRP1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:40.111301+00
1569	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTRP1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000003	\N	2026-10-26 11:42:40.143779+00
1570	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:40.152434+00
1571	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_REQ	VEHICLE	TESTRP1026194237	\N	requestNo=RPR-CCA6AE6E	\N	2026-10-26 11:42:40.226579+00
1572	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_FULFILL	VEHICLE	TESTRP1026194237	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 11:42:40.236115+00
1573	collection	COLLECTION_OFFICER	PARTIAL_REPAY	VEHICLE	TESTRP1026194237	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 11:42:40.246826+00
1574	advisory	RISK_ADVISORY_OFFICER	INSURANCE_BIND	VEHICLE	TESTRP1026194237	\N	policyNo=POL-SMOKE-1026194237,insured=2000000	\N	2026-10-26 11:42:40.286255+00
1575	advisory	RISK_ADVISORY_OFFICER	INSURANCE_CLAIM	VEHICLE	TESTRP1026194237	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 11:42:40.310121+00
1576	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:40.320879+00
1577	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTEX1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:40.358805+00
1578	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTEX1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000004	\N	2026-10-26 11:42:40.391629+00
1579	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTEX1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:40.401908+00
1580	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTEX1026194237	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:42:40.411947+00
1581	advisory	RISK_ADVISORY_OFFICER	EXTENSION	VEHICLE	TESTEX1026194237	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 11:42:40.437823+00
1582	settlement	SETTLEMENT_OFFICER	PAYOFF_ISSUE	VEHICLE	TESTVIN1026194237	\N	certNo=PAY-289FB393,total=1695880	\N	2026-10-26 11:42:40.448569+00
1588	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTWN1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:40.649873+00
1584	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_DONE	CREDIT_LINE	237	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 11:42:40.594132+00
1585	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:40.613465+00
1590	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:40.684394+00
1593	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTGR1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:40.722822+00
1597	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTDP1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000007	\N	2026-10-26 11:42:40.829579+00
1599	disposal	DISPOSAL_OFFICER	DISPOSAL_OPEN	VEHICLE	TESTDP1026194237	\N	caseNo=DSP-479FCF5A,reason=OVERDUE	\N	2026-10-26 11:42:40.936158+00
1601	disposal	DISPOSAL_OFFICER	DISPOSAL_LIQ	DISPOSAL	DSP-479FCF5A	\N	LIQUIDATING	\N	2026-10-26 11:42:40.95346+00
1605	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:41.027328+00
1606	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@61428af	com.company.floorplan.domain.model.RatingConfig@29d69705	\N	2026-10-26 11:42:41.0499+00
1609	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTSOD1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000008	\N	2026-10-26 11:42:41.773758+00
1611	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:41.821014+00
1616	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	284	\N	DL-CRUD-14963	\N	2026-10-26 11:42:43.395645+00
1620	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	284	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:42:43.471848+00
1586	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTWN1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:40.623595+00
1592	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTGR1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000006	\N	2026-10-26 11:42:40.713819+00
1602	disposal	DISPOSAL_OFFICER	DISPOSAL_CLOSE	DISPOSAL	DSP-479FCF5A	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 11:42:40.959748+00
1608	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTSOD1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:41.255044+00
1612	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTFAIL1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:41.83052+00
1619	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	284	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:42:43.444144+00
1621	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	284	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:42:43.511986+00
1587	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTWN1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000005	\N	2026-10-26 11:42:40.639975+00
1589	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTWN1026194237	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 11:42:40.659657+00
1591	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTGR1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:40.69922+00
1594	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTGR1026194237	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 11:42:40.731095+00
1596	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTDP1026194237	status=PENDING	reserved=1665000	\N	2026-10-26 11:42:40.806886+00
1598	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTDP1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:40.844997+00
1600	disposal	DISPOSAL_OFFICER	DISPOSAL_REPO	DISPOSAL	DSP-479FCF5A	\N	REPOSSESSED	\N	2026-10-26 11:42:40.946006+00
1603	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026194237	\N	caseNo=DSP-D0CC7ABC,reason=AUTO_OOT	\N	2026-10-26 11:42:40.972242+00
1604	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@1127a685	com.company.floorplan.domain.model.RatingConfig@3cc88ae9	\N	2026-10-26 11:42:41.01711+00
1607	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	282	\N	accepted=1,rejected=0	\N	2026-10-26 11:42:41.235325+00
1610	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTSOD1026194237	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:42:41.813417+00
1613	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTFAIL1026194237	status=PENDING	status=PROCESSING,channelRef=PAY-00000009	\N	2026-10-26 11:42:41.852818+00
1614	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTFAIL1026194237	status=FAILED	status=FAILED,released=1665000	GATEWAY_DECLINED	2026-10-26 11:42:41.882645+00
1618	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	284	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:42:43.435848+00
1622	admin	SYSTEM_ADMIN	DELETE_DEALER	DEALER	284	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 11:42:43.521905+00
1617	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	284	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-14963,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:42:43.426414+00
1623	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	285	\N	DL-SMOKE-15466	\N	2026-10-26 11:51:06.591601+00
1624	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	238	\N	limit=200000000	\N	2026-10-26 11:51:06.616079+00
1625	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:06.748204+00
1626	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTVIN1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:06.888235+00
1627	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTVIN1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000001	\N	2026-10-26 11:51:07.015698+00
1628	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTVIN1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:07.060141+00
1629	settlement	SETTLEMENT_OFFICER	SET_SECURITY	VEHICLE	TESTVIN1026195105	\N	type=RETENTION,regNo=REG-001	\N	2026-10-26 11:51:07.219907+00
1630	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTVIN1026195105	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:51:07.384933+00
1631	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	TESTVIN1026195105	principal=1665000	settled,interest=16160,released=1665000	\N	2026-10-26 11:51:07.417526+00
1632	review_op	PURCHASE_REVIEWER	INVENTORY_AUDIT	DEALER	285	\N	matched=0,missing=0,unexpected=1	\N	2026-10-26 11:51:07.480332+00
1633	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=0,rejected=1	\N	2026-10-26 11:51:07.537882+00
1634	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:07.78991+00
1635	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTCT1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:07.810629+00
1636	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTCT1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000002	\N	2026-10-26 11:51:07.831258+00
1637	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTCT1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:07.853863+00
1638	collection	COLLECTION_OFFICER	CURTAIL_PAY	VEHICLE	TESTCT1026195105	period=0	period=1,amount=166500,balance=1498500	\N	2026-10-26 11:51:08.280828+00
1639	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:08.391479+00
1640	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTRP1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:08.411339+00
1641	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTRP1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000003	\N	2026-10-26 11:51:08.441684+00
1642	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTRP1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:08.463903+00
1643	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_REQ	VEHICLE	TESTRP1026195105	\N	requestNo=RPR-E8BA3090	\N	2026-10-26 11:51:08.578226+00
1644	advisory	RISK_ADVISORY_OFFICER	REPURCHASE_FULFILL	VEHICLE	TESTRP1026195105	principal=832500	repaid=832500,balance=832500	\N	2026-10-26 11:51:08.625719+00
1645	collection	COLLECTION_OFFICER	PARTIAL_REPAY	VEHICLE	TESTRP1026195105	balance_before=?	paid=100000,balance=732500	\N	2026-10-26 11:51:08.643964+00
1646	advisory	RISK_ADVISORY_OFFICER	INSURANCE_BIND	VEHICLE	TESTRP1026195105	\N	policyNo=POL-SMOKE-1026195105,insured=2000000	\N	2026-10-26 11:51:08.714343+00
1647	advisory	RISK_ADVISORY_OFFICER	INSURANCE_CLAIM	VEHICLE	TESTRP1026195105	ACTIVE	CLAIMED,claimed=500000	\N	2026-10-26 11:51:08.752121+00
1648	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:08.782928+00
1649	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTEX1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:08.800827+00
1650	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTEX1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000004	\N	2026-10-26 11:51:08.824995+00
1651	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTEX1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:08.836228+00
1652	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTEX1026195105	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-28	\N	2026-10-26 11:51:08.843568+00
1653	advisory	RISK_ADVISORY_OFFICER	EXTENSION	VEHICLE	TESTEX1026195105	due=2026-10-28	newDue=2026-11-04	\N	2026-10-26 11:51:08.879095+00
1654	settlement	SETTLEMENT_OFFICER	PAYOFF_ISSUE	VEHICLE	TESTVIN1026195105	\N	certNo=PAY-567BF6D3,total=1681160	\N	2026-10-26 11:51:08.891354+00
1655	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_INIT	CREDIT_LINE	238	used=4995000	frozen=4995000,reviewNo=AR-C2918E2D	\N	2026-10-26 11:51:09.009638+00
1656	credit	CREDIT_REVIEWER	ANNUAL_REVIEW_DONE	CREDIT_LINE	238	status=IN_PROGRESS	passed=true,status=PASSED	\N	2026-10-26 11:51:09.025013+00
1657	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:09.052419+00
1658	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTWN1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:09.070281+00
1659	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTWN1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000005	\N	2026-10-26 11:51:09.099043+00
1660	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTWN1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:09.1438+00
1661	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTWN1026195105	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-26	\N	2026-10-26 11:51:09.16874+00
1662	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:09.178543+00
1663	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTGR1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:09.195881+00
1664	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTGR1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000006	\N	2026-10-26 11:51:09.216853+00
1665	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTGR1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:09.233565+00
1666	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	TESTGR1026195105	status=IN_STOCK	status=SOLD_PENDING,due=2026-10-14	\N	2026-10-26 11:51:09.269112+00
1667	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:09.347888+00
1668	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTDP1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:09.356314+00
1669	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTDP1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000007	\N	2026-10-26 11:51:09.400494+00
1670	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTDP1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:09.413673+00
1671	disposal	DISPOSAL_OFFICER	DISPOSAL_OPEN	VEHICLE	TESTDP1026195105	\N	caseNo=DSP-911FC5D5,reason=OVERDUE	\N	2026-10-26 11:51:09.538916+00
1672	disposal	DISPOSAL_OFFICER	DISPOSAL_REPO	DISPOSAL	DSP-911FC5D5	\N	REPOSSESSED	\N	2026-10-26 11:51:09.555327+00
1673	disposal	DISPOSAL_OFFICER	DISPOSAL_LIQ	DISPOSAL	DSP-911FC5D5	\N	LIQUIDATING	\N	2026-10-26 11:51:09.569426+00
1674	disposal	DISPOSAL_OFFICER	DISPOSAL_CLOSE	DISPOSAL	DSP-911FC5D5	\N	receivable=1665000,proceeds=1332000,loss=333000,status=CLOSED_LOSS	\N	2026-10-26 11:51:09.584558+00
1675	system	\N	DISPOSAL_OPEN	VEHICLE	TESTGR1026195105	\N	caseNo=DSP-F52E7500,reason=AUTO_OOT	\N	2026-10-26 11:51:09.604886+00
1676	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@17a72a1b	com.company.floorplan.domain.model.RatingConfig@e7dc7be	\N	2026-10-26 11:51:09.648993+00
1677	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:09.693503+00
1678	admin	SYSTEM_ADMIN	RATING_CONFIG_UPSERT	RATING_CONFIG	B	com.company.floorplan.domain.model.RatingConfig@2c392d31	com.company.floorplan.domain.model.RatingConfig@71e30e7c	\N	2026-10-26 11:51:09.729192+00
1679	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:10.006101+00
1680	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTSOD1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:10.015506+00
1681	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTSOD1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000008	\N	2026-10-26 11:51:10.551639+00
1682	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTSOD1026195105	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 11:51:10.605+00
1683	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	285	\N	accepted=1,rejected=0	\N	2026-10-26 11:51:10.621608+00
1684	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	TESTFAIL1026195105	status=PENDING	reserved=1665000	\N	2026-10-26 11:51:10.63679+00
1685	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	TESTFAIL1026195105	status=PENDING	status=PROCESSING,channelRef=PAY-00000009	\N	2026-10-26 11:51:10.68596+00
1686	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	TESTFAIL1026195105	status=FAILED	status=FAILED,released=1665000	GATEWAY_DECLINED	2026-10-26 11:51:10.705143+00
1688	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	287	\N	DL-CRUD-15472	\N	2026-10-26 11:51:12.258246+00
1689	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	287	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=初始联系人,contactPhone=03-1111-2222,address=东京都港区,remark=初始备注	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:51:12.278603+00
1690	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	287	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:51:12.294825+00
1691	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	287	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:51:12.314854+00
1692	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	287	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=SUSPENDED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:51:12.329814+00
1693	admin	SYSTEM_ADMIN	UPDATE_DEALER	DEALER	287	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=ACTIVE,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	2026-10-26 11:51:12.358447+00
1694	admin	SYSTEM_ADMIN	DELETE_DEALER	DEALER	287	dealerCode=DL-CRUD-15472,name=CRUD 测试经销商（已改）,status=TERMINATED,riskGrade=B,businessYears=8,contactPerson=null,contactPhone=03-3333-4444,address=东京都港区,remark=null	\N	\N	2026-10-26 11:51:12.376844+00
1695	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	288	\N	DL-COL-017481	\N	2026-10-26 12:24:42.353271+00
1696	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	239	\N	limit=200000000	\N	2026-10-26 12:24:42.398185+00
1697	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	288	\N	accepted=2,rejected=0	\N	2026-10-26 12:24:42.411478+00
1698	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA017481	status=PENDING	reserved=1665000	\N	2026-10-26 12:24:42.443186+00
1699	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB017481	status=PENDING	reserved=1665000	\N	2026-10-26 12:24:42.4603+00
1700	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA017481	status=PENDING	reserved=1665000	\N	2026-10-26 12:24:42.476471+00
1701	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB017481	status=PENDING	reserved=1665000	\N	2026-10-26 12:24:42.489395+00
1702	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	289	\N	DL-COL-017527	\N	2026-10-26 12:25:28.033337+00
1703	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	240	\N	limit=500000000	\N	2026-10-26 12:25:28.06393+00
1704	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	289	\N	accepted=2,rejected=0	\N	2026-10-26 12:25:28.07188+00
1705	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA017527	status=PENDING	reserved=1665000	\N	2026-10-26 12:25:28.08638+00
1706	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLA017527	status=PENDING	status=PROCESSING,channelRef=PAY-00000001	\N	2026-10-26 12:25:28.105912+00
1707	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB017527	status=PENDING	reserved=1665000	\N	2026-10-26 12:25:28.135342+00
1708	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLB017527	status=PENDING	status=PROCESSING,channelRef=PAY-00000002	\N	2026-10-26 12:25:28.162095+00
1709	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	290	\N	DL-COL-017554	\N	2026-10-26 12:25:55.389799+00
1710	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	241	\N	limit=500000000	\N	2026-10-26 12:25:55.420462+00
1711	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	290	\N	accepted=2,rejected=0	\N	2026-10-26 12:25:55.427639+00
1712	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA017554	status=PENDING	reserved=1665000	\N	2026-10-26 12:25:55.439866+00
1713	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLA017554	status=PENDING	status=PROCESSING,channelRef=PAY-00000003	\N	2026-10-26 12:25:55.469933+00
1715	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB017554	status=PENDING	reserved=1665000	\N	2026-10-26 12:25:55.532244+00
1716	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLB017554	status=PENDING	status=PROCESSING,channelRef=PAY-00000004	\N	2026-10-26 12:25:55.546674+00
1718	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	291	\N	DL-COL-017725	\N	2026-10-26 12:28:46.293094+00
1719	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	242	\N	limit=500000000	\N	2026-10-26 12:28:46.362062+00
1720	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	291	\N	accepted=2,rejected=0	\N	2026-10-26 12:28:46.395785+00
1721	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA017725	status=PENDING	reserved=1665000	\N	2026-10-26 12:28:46.460004+00
1722	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLA017725	status=PENDING	status=PROCESSING,channelRef=PAY-00000001	\N	2026-10-26 12:28:46.51302+00
1723	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLA017725	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:28:46.553109+00
1724	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB017725	status=PENDING	reserved=1665000	\N	2026-10-26 12:28:46.596113+00
1725	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLB017725	status=PENDING	status=PROCESSING,channelRef=PAY-00000002	\N	2026-10-26 12:28:46.617388+00
1726	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLB017725	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:28:46.632321+00
1727	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	COLA017725	status=IN_STOCK	status=SOLD_PENDING,due=2026-08-04	\N	2026-10-26 12:28:46.820655+00
1728	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	292	\N	DL-COL-017866	\N	2026-10-26 12:31:06.764149+00
1729	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	243	\N	limit=500000000	\N	2026-10-26 12:31:06.772069+00
1730	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	292	\N	accepted=2,rejected=0	\N	2026-10-26 12:31:06.779074+00
1731	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA017866	status=PENDING	reserved=1665000	\N	2026-10-26 12:31:06.804051+00
1732	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLA017866	status=PENDING	status=PROCESSING,channelRef=PAY-00000003	\N	2026-10-26 12:31:06.837684+00
1733	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLA017866	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:31:06.867412+00
1734	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB017866	status=PENDING	reserved=1665000	\N	2026-10-26 12:31:06.880139+00
1735	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLB017866	status=PENDING	status=PROCESSING,channelRef=PAY-00000004	\N	2026-10-26 12:31:06.917192+00
1736	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLB017866	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:31:06.927668+00
1737	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	COLA017866	status=IN_STOCK	status=SOLD_PENDING,due=2026-08-04	\N	2026-10-26 12:31:07.035082+00
1738	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	293	\N	DL-COL-018493	\N	2026-10-26 12:41:34.483132+00
1739	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	244	\N	limit=500000000	\N	2026-10-26 12:41:34.526928+00
1740	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	293	\N	accepted=2,rejected=0	\N	2026-10-26 12:41:34.563732+00
1741	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA018493	status=PENDING	reserved=1665000	\N	2026-10-26 12:41:34.608939+00
1742	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLA018493	status=PENDING	status=PROCESSING,channelRef=PAY-00000001	\N	2026-10-26 12:41:34.630928+00
1743	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLA018493	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:41:34.643041+00
1744	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB018493	status=PENDING	reserved=1665000	\N	2026-10-26 12:41:34.685725+00
1745	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLB018493	status=PENDING	status=PROCESSING,channelRef=PAY-00000002	\N	2026-10-26 12:41:34.718844+00
1746	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLB018493	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:41:34.72802+00
1747	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	COLA018493	status=IN_STOCK	status=SOLD_PENDING,due=2026-08-04	\N	2026-10-26 12:41:34.891097+00
1748	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	294	\N	DL-COL-018520	\N	2026-10-26 12:42:01.249541+00
1749	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	245	\N	limit=500000000	\N	2026-10-26 12:42:01.257707+00
1750	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	294	\N	accepted=2,rejected=0	\N	2026-10-26 12:42:01.27941+00
1751	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA018520	status=PENDING	reserved=1665000	\N	2026-10-26 12:42:01.294455+00
1752	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLA018520	status=PENDING	status=PROCESSING,channelRef=PAY-00000003	\N	2026-10-26 12:42:01.309777+00
1753	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLA018520	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:42:01.320141+00
1754	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB018520	status=PENDING	reserved=1665000	\N	2026-10-26 12:42:01.333236+00
1755	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLB018520	status=PENDING	status=PROCESSING,channelRef=PAY-00000004	\N	2026-10-26 12:42:01.345728+00
1756	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLB018520	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:42:01.372537+00
1757	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	COLA018520	status=IN_STOCK	status=SOLD_PENDING,due=2026-08-04	\N	2026-10-26 12:42:01.488518+00
1758	admin	SYSTEM_ADMIN	CREATE_DEALER	DEALER	295	\N	DL-COL-018534	\N	2026-10-26 12:42:14.64903+00
1759	admin	SYSTEM_ADMIN	CREATE_CREDIT_LINE	CREDIT_LINE	246	\N	limit=500000000	\N	2026-10-26 12:42:14.656782+00
1760	review_op	PURCHASE_REVIEWER	BATCH_INGEST	DEALER	295	\N	accepted=2,rejected=0	\N	2026-10-26 12:42:14.664348+00
1761	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLA018534	status=PENDING	reserved=1665000	\N	2026-10-26 12:42:14.679225+00
1762	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLA018534	status=PENDING	status=PROCESSING,channelRef=PAY-00000005	\N	2026-10-26 12:42:14.716805+00
1763	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLA018534	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:42:14.746661+00
1764	operator	BUSINESS_OPERATOR	ADVANCE	VEHICLE	COLB018534	status=PENDING	reserved=1665000	\N	2026-10-26 12:42:14.759501+00
1765	cashier	FUNDING_CASHIER	ADVANCE	VEHICLE	COLB018534	status=PENDING	status=PROCESSING,channelRef=PAY-00000006	\N	2026-10-26 12:42:14.774816+00
1766	PAYMENT_GATEWAY	\N	ADVANCE	VEHICLE	COLB018534	status=PAID	status=IN_STOCK,amount=1665000	\N	2026-10-26 12:42:14.783534+00
1767	settlement	SETTLEMENT_OFFICER	MARK_SOLD	VEHICLE	COLA018534	status=IN_STOCK	status=SOLD_PENDING,due=2026-08-04	\N	2026-10-26 12:42:14.848744+00
1768	settlement	SETTLEMENT_OFFICER	REPAYMENT	VEHICLE	COLA018534	principal=1665000	settled,interest=0,released=1665000	\N	2026-10-26 12:42:14.921136+00
\.


--
-- Data for Name: batch_runs; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.batch_runs (id, job_name, biz_date, status, started_at, finished_at, error_detail) FROM stdin;
248	DAILY_INTEREST	2027-02-01	SUCCESS	2026-10-26 11:51:07.234018+00	2026-10-26 11:51:07.234018+00	\N
249	DAILY_INTEREST	2027-02-02	SUCCESS	2026-10-26 11:51:07.333969+00	2026-10-26 11:51:07.333969+00	\N
250	DAILY_INTEREST	2027-02-03	SUCCESS	2026-10-26 11:51:07.348718+00	2026-10-26 11:51:07.348718+00	\N
251	ANNUAL_REVIEW_SCAN	2026-10-26	SUCCESS	2026-10-26 11:51:09.038186+00	2026-10-26 11:51:09.038186+00	\N
252	SETTLE_WINDOW_SCAN	2026-10-26	SUCCESS	2026-10-26 11:51:09.279627+00	2026-10-26 11:51:09.279627+00	\N
253	DEFAULT_DISPOSAL	2026-10-26	SUCCESS	2026-10-26 11:51:09.604886+00	2026-10-26 11:51:09.604886+00	\N
114	INTEREST_ARCHIVE	2026-10-01	SUCCESS	2026-10-26 02:12:41.525306+00	2026-10-26 02:12:41.525306+00	\N
\.


--
-- Data for Name: collateral_evidence_links; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.collateral_evidence_links (id, ledger_id, vin, evidence_type, ref_type, ref_id, attachment_id, event_at, note, recorded_by, created_at) FROM stdin;
1	1	COLA017725	ADVANCE	INTERNAL	ADV-D5A8AFFF	\N	2026-10-26 12:28:46.573724+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:28:46.553109+00
2	2	COLB017725	ADVANCE	INTERNAL	ADV-137BD379	\N	2026-10-26 12:28:46.642248+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:28:46.632321+00
3	1	COLA017725	CONTRACT	INTERNAL	SOLD:COLA017725	\N	2026-07-31 16:00:00+00	售出，担保物清单已扣减；回款须进入指定账户或用于还款	settlement	2026-10-26 12:28:46.820655+00
4	6	COLA017866	ADVANCE	INTERNAL	ADV-7D400122	\N	2026-10-26 12:31:06.872739+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:31:06.867412+00
5	7	COLB017866	ADVANCE	INTERNAL	ADV-D86C294A	\N	2026-10-26 12:31:06.93349+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:31:06.927668+00
6	6	COLA017866	CONTRACT	INTERNAL	SOLD:COLA017866	\N	2026-07-31 16:00:00+00	售出，担保物清单已扣减；回款须进入指定账户或用于还款	settlement	2026-10-26 12:31:07.035082+00
7	11	COLA018493	ADVANCE	INTERNAL	ADV-AE7150A1	\N	2026-10-26 12:41:34.65171+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:41:34.643041+00
8	12	COLB018493	ADVANCE	INTERNAL	ADV-8246F5D6	\N	2026-10-26 12:41:34.734075+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:41:34.72802+00
9	11	COLA018493	CONTRACT	INTERNAL	SOLD:COLA018493	\N	2026-07-31 16:00:00+00	售出，担保物清单已扣减；回款须进入指定账户或用于还款	settlement	2026-10-26 12:41:34.891097+00
10	16	COLA018520	ADVANCE	INTERNAL	ADV-483BA4AE	\N	2026-10-26 12:42:01.32572+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:42:01.320141+00
11	17	COLB018520	ADVANCE	INTERNAL	ADV-8273C5C2	\N	2026-10-26 12:42:01.377759+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:42:01.372537+00
12	16	COLA018520	CONTRACT	INTERNAL	SOLD:COLA018520	\N	2026-07-31 16:00:00+00	售出，担保物清单已扣减；回款须进入指定账户或用于还款	settlement	2026-10-26 12:42:01.488518+00
13	21	COLA018534	ADVANCE	INTERNAL	ADV-D2C4F3E0	\N	2026-10-26 12:42:14.750781+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:42:14.746661+00
14	22	COLB018534	ADVANCE	INTERNAL	ADV-B96BFDA2	\N	2026-10-26 12:42:14.78782+00	放款确认，金额=1665000	PAYMENT_GATEWAY	2026-10-26 12:42:14.783534+00
15	21	COLA018534	CONTRACT	INTERNAL	SOLD:COLA018534	\N	2026-07-31 16:00:00+00	售出，担保物清单已扣减；回款须进入指定账户或用于还款	settlement	2026-10-26 12:42:14.848744+00
16	21	COLA018534	REPAYMENT	INTERNAL	REPAID:COLA018534	\N	2026-10-26 12:42:14.929199+00	回款 1665000 日元，账户=未指定，专用于还款=true	settlement	2026-10-26 12:42:14.921136+00
\.


--
-- Data for Name: collateral_ledger; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.collateral_ledger (id, vin, dealer_id, financed, financed_at, advance_no, sold, sold_at, sold_flagged_by, repaid, repaid_at, repaid_amount, released, released_at, release_reason, security_type, security_status, required_account_ref, account_checked, account_checked_at, account_checked_by, last_audit_date, audit_mismatch_count, last_audit_by, disposal_case_no, disposed_at, registration_due, registration_note, created_at, updated_at) FROM stdin;
2	COLB017725	291	t	2026-10-26 12:28:46.640249+00	ADV-137BD379	f	\N	\N	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:28:46.632321+00	2026-10-26 12:28:46.678502+00
1	COLA017725	291	t	2026-10-26 12:28:46.570731+00	ADV-D5A8AFFF	t	2026-07-31 16:00:00+00	settlement	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:28:46.553109+00	2026-10-26 12:28:46.820655+00
7	COLB017866	292	t	2026-10-26 12:31:06.932494+00	ADV-D86C294A	f	\N	\N	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:31:06.927668+00	2026-10-26 12:31:06.944962+00
6	COLA017866	292	t	2026-10-26 12:31:06.871741+00	ADV-7D400122	t	2026-07-31 16:00:00+00	settlement	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:31:06.867412+00	2026-10-26 12:31:07.035082+00
12	COLB018493	293	t	2026-10-26 12:41:34.733075+00	ADV-8246F5D6	f	\N	\N	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:41:34.72802+00	2026-10-26 12:41:34.798466+00
11	COLA018493	293	t	2026-10-26 12:41:34.649701+00	ADV-AE7150A1	t	2026-07-31 16:00:00+00	settlement	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:41:34.643041+00	2026-10-26 12:41:34.891097+00
17	COLB018520	294	t	2026-10-26 12:42:01.376746+00	ADV-8273C5C2	f	\N	\N	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:42:01.372537+00	2026-10-26 12:42:01.408034+00
16	COLA018520	294	t	2026-10-26 12:42:01.324715+00	ADV-483BA4AE	t	2026-07-31 16:00:00+00	settlement	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:42:01.320141+00	2026-10-26 12:42:01.488518+00
22	COLB018534	295	t	2026-10-26 12:42:14.786802+00	ADV-B96BFDA2	f	\N	\N	f	\N	\N	f	\N	\N	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:42:14.783534+00	2026-10-26 12:42:14.799092+00
21	COLA018534	295	t	2026-10-26 12:42:14.749782+00	ADV-D2C4F3E0	t	2026-07-31 16:00:00+00	settlement	t	2026-10-26 12:42:14.929199+00	1665000	t	2026-10-26 12:42:14.933215+00	SETTLED	ASSIGNMENT	REGISTERED	\N	f	\N	\N	\N	0	\N	\N	\N	f	\N	2026-10-26 12:42:14.746661+00	2026-10-26 12:42:14.921136+00
\.


--
-- Data for Name: collateral_registration_batches; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.collateral_registration_batches (id, batch_no, registration_no, registration_type, perfection_method, registry_office, registered_at, expires_at, contract_attachment_id, contract_no, contract_signed_at, certificate_attachment_id, certificate_no, certificate_uploaded_at, cancellation_status, cancellation_no, cancellation_applied_at, cancellation_completed_at, cancellation_certificate_attachment_id, cancellation_requested_by, cancellation_note, priority_rank, co_signed_by, vehicle_count, created_by, created_at, updated_at) FROM stdin;
13	CRB-1ECE3A9F	R-2026-018534	ASSIGNMENT	REGISTRATION	東京法務局 動産登記課	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	CT-018534	2026-06-28 02:00:00+00	\N	CERT-018534	\N	NOT_REQUIRED	\N	\N	\N	\N	\N	\N	\N	\N	2	collateral	2026-10-26 12:42:14.799092+00	2026-10-26 12:42:14.799092+00
1	CRB-1604312A	R-2026-017527	ASSIGNMENT	REGISTRATION	東京法務局 動産登記課	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	CT-017527	2026-06-28 02:00:00+00	\N	CERT-017527	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:25:28.20712+00	2026-10-26 12:25:28.20712+00
2	CRB-7BE38494	R-EMPTY-017527	ASSIGNMENT	REGISTRATION	\N	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	\N	\N	\N	\N	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:25:28.243931+00	2026-10-26 12:25:28.243931+00
3	CRB-0D1C44BF	R-2026-017554	ASSIGNMENT	REGISTRATION	東京法務局 動産登記課	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	CT-017554	2026-06-28 02:00:00+00	\N	CERT-017554	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:25:55.596186+00	2026-10-26 12:25:55.596186+00
4	CRB-803D76E0	R-EMPTY-017554	ASSIGNMENT	REGISTRATION	\N	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	\N	\N	\N	\N	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:25:55.657456+00	2026-10-26 12:25:55.657456+00
5	CRB-4EF4B15D	R-2026-017725	ASSIGNMENT	REGISTRATION	東京法務局 動産登記課	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	CT-017725	2026-06-28 02:00:00+00	\N	CERT-017725	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	2	collateral	2026-10-26 12:28:46.678502+00	2026-10-26 12:28:46.678502+00
6	CRB-7E13736A	R-EMPTY-017725	ASSIGNMENT	REGISTRATION	\N	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	\N	\N	\N	\N	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:28:46.755512+00	2026-10-26 12:28:46.755512+00
14	CRB-112984A4	R-EMPTY-018534	ASSIGNMENT	REGISTRATION	\N	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	\N	\N	\N	\N	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:42:14.829222+00	2026-10-26 12:42:14.829222+00
7	CRB-246D6066	R-2026-017866	ASSIGNMENT	REGISTRATION	東京法務局 動産登記課	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	CT-017866	2026-06-28 02:00:00+00	\N	CERT-017866	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	2	collateral	2026-10-26 12:31:06.944962+00	2026-10-26 12:31:06.944962+00
8	CRB-EA972145	R-EMPTY-017866	ASSIGNMENT	REGISTRATION	\N	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	\N	\N	\N	\N	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:31:06.992245+00	2026-10-26 12:31:06.992245+00
9	CRB-71AB30C9	R-2026-018493	ASSIGNMENT	REGISTRATION	東京法務局 動産登記課	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	CT-018493	2026-06-28 02:00:00+00	\N	CERT-018493	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	2	collateral	2026-10-26 12:41:34.798466+00	2026-10-26 12:41:34.798466+00
10	CRB-BCD4BC14	R-EMPTY-018493	ASSIGNMENT	REGISTRATION	\N	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	\N	\N	\N	\N	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:41:34.843136+00	2026-10-26 12:41:34.843136+00
11	CRB-9B9063F0	R-2026-018520	ASSIGNMENT	REGISTRATION	東京法務局 動産登記課	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	CT-018520	2026-06-28 02:00:00+00	\N	CERT-018520	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	2	collateral	2026-10-26 12:42:01.408034+00	2026-10-26 12:42:01.408034+00
12	CRB-EE92B671	R-EMPTY-018520	ASSIGNMENT	REGISTRATION	\N	2026-07-01 02:00:00+00	2031-07-01 02:00:00+00	\N	\N	\N	\N	\N	\N	NOT_DUE	\N	\N	\N	\N	\N	\N	\N	\N	0	collateral	2026-10-26 12:42:01.450339+00	2026-10-26 12:42:01.450339+00
\.


--
-- Data for Name: collateral_registration_items; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.collateral_registration_items (id, batch_id, ledger_id, vin, created_at) FROM stdin;
1	5	1	COLA017725	2026-10-26 12:28:46.678502+00
2	5	2	COLB017725	2026-10-26 12:28:46.678502+00
3	7	6	COLA017866	2026-10-26 12:31:06.944962+00
4	7	7	COLB017866	2026-10-26 12:31:06.944962+00
5	9	11	COLA018493	2026-10-26 12:41:34.798466+00
6	9	12	COLB018493	2026-10-26 12:41:34.798466+00
7	11	16	COLA018520	2026-10-26 12:42:01.408034+00
8	11	17	COLB018520	2026-10-26 12:42:01.408034+00
9	13	21	COLA018534	2026-10-26 12:42:14.799092+00
10	13	22	COLB018534	2026-10-26 12:42:14.799092+00
\.


--
-- Data for Name: credit_lines; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.credit_lines (id, dealer_id, approved_limit, used_amount, frozen_amount, status, version, created_at, updated_at) FROM stdin;
220	245	1000000000	0	0	ACTIVE	0	2026-10-26 06:58:45.90093+00	2026-10-26 06:58:45.90093+00
238	285	200000000	11655000	0	ACTIVE	13	2026-10-26 11:51:06.616079+00	2026-10-26 11:51:10.705143+00
239	288	200000000	6660000	0	ACTIVE	4	2026-10-26 12:24:42.398185+00	2026-10-26 12:24:42.489395+00
240	289	500000000	3330000	0	ACTIVE	2	2026-10-26 12:25:28.06393+00	2026-10-26 12:25:28.135342+00
241	290	500000000	3330000	0	ACTIVE	2	2026-10-26 12:25:55.420462+00	2026-10-26 12:25:55.532244+00
242	291	500000000	3330000	0	ACTIVE	2	2026-10-26 12:28:46.362062+00	2026-10-26 12:28:46.596113+00
243	292	500000000	3330000	0	ACTIVE	2	2026-10-26 12:31:06.772069+00	2026-10-26 12:31:06.880139+00
244	293	500000000	3330000	0	ACTIVE	2	2026-10-26 12:41:34.526928+00	2026-10-26 12:41:34.685725+00
245	294	500000000	3330000	0	ACTIVE	2	2026-10-26 12:42:01.257707+00	2026-10-26 12:42:01.333236+00
246	295	500000000	1665000	0	ACTIVE	3	2026-10-26 12:42:14.656782+00	2026-10-26 12:42:14.921136+00
\.


--
-- Data for Name: curtailment_payments; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.curtailment_payments (id, vin, period_no, amount, paid_at, idempotency_key, operator) FROM stdin;
24	TESTCT1026195105	1	166500	2026-10-26 11:51:08.280828+00	curt-TESTCT1026195105	collection
\.


--
-- Data for Name: dealer_bank_accounts; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.dealer_bank_accounts (id, dealer_id, bank_name, account_holder, account_no_cipher, account_no_mask, account_ref, status, effective_from, effective_to, reviewer, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dealers; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.dealers (id, dealer_code, name, status, risk_grade, business_years, created_at, updated_at, contact_person, contact_phone, address, remark) FROM stdin;
289	DL-COL-017527	担保台账验证经销商	ACTIVE	B	10	2026-10-26 12:25:28.033337+00	2026-10-26 12:25:28.033337+00	\N	\N	\N	\N
290	DL-COL-017554	担保台账验证经销商	ACTIVE	B	10	2026-10-26 12:25:55.389799+00	2026-10-26 12:25:55.389799+00	\N	\N	\N	\N
291	DL-COL-017725	担保台账验证经销商	ACTIVE	B	10	2026-10-26 12:28:46.293094+00	2026-10-26 12:28:46.293094+00	\N	\N	\N	\N
292	DL-COL-017866	担保台账验证经销商	ACTIVE	B	10	2026-10-26 12:31:06.764149+00	2026-10-26 12:31:06.764149+00	\N	\N	\N	\N
293	DL-COL-018493	担保台账验证经销商	ACTIVE	B	10	2026-10-26 12:41:34.483132+00	2026-10-26 12:41:34.483132+00	\N	\N	\N	\N
245	dl-00400	大板株式会社	ACTIVE	\N	12	2026-10-26 06:20:17.341799+00	2026-10-26 06:43:50.313488+00	三加一额	03-00-3849	\N	\N
250	dl-0002	东京株式会社	ACTIVE	B	10	2026-10-26 06:57:49.385876+00	2026-10-26 06:57:49.385876+00	半井	\N	\N	\N
294	DL-COL-018520	担保台账验证经销商	ACTIVE	B	10	2026-10-26 12:42:01.249541+00	2026-10-26 12:42:01.249541+00	\N	\N	\N	\N
295	DL-COL-018534	担保台账验证经销商	ACTIVE	B	10	2026-10-26 12:42:14.64903+00	2026-10-26 12:42:14.64903+00	\N	\N	\N	\N
285	DL-SMOKE-15466	冒烟测试经销商	ACTIVE	B	10	2026-10-26 11:51:06.591601+00	2026-10-26 11:51:06.591601+00	\N	\N	\N	\N
288	DL-COL-017481	担保台账测试经销商	ACTIVE	B	10	2026-10-26 12:24:42.353271+00	2026-10-26 12:24:42.353271+00	\N	\N	\N	\N
\.


--
-- Data for Name: disposal_cases; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.disposal_cases (id, case_no, vin, dealer_id, credit_line_id, reason, status, repossessed_at, proceeds, loss_amount, opened_at, closed_at) FROM stdin;
112	DSP-911FC5D5	TESTDP1026195105	285	238	OVERDUE	CLOSED_LOSS	2026-10-26 11:51:09.557287+00	1332000	333000	2026-10-26 11:51:09.541138+00	2026-10-26 11:51:09.586283+00
116	DSP-F52E7500	TESTGR1026195105	285	238	AUTO_OOT	OPEN	\N	0	0	2026-10-26 11:51:09.607065+00	\N
\.


--
-- Data for Name: domain_events; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.domain_events (id, event_type, source, dealer_id, vin, biz_key, payload, ref_type, ref_id, event_time, received_at, status, error_detail, processed_at) FROM stdin;
\.


--
-- Data for Name: extension_requests; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.extension_requests (id, request_no, vin, ext_days, reason, status, original_due, new_due, created_at) FROM stdin;
25	EXT-0BCEE5A5	TESTEX1026195105	7	客户贷款审批中	APPROVED	2026-10-28	2026-11-04	2026-10-26 11:51:08.879095+00
\.


--
-- Data for Name: financing_lien_checks; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.financing_lien_checks (id, vin, check_source, encumbered, checked_at, note, operator) FROM stdin;
29	TESTLN1026195105	MANUAL	t	2026-10-26 11:51:07.523521+00	他行抵押登记	review_op
\.


--
-- Data for Name: financing_terms; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.financing_terms (id, vin, change_type, old_maturity_date, new_maturity_date, old_grace_days, new_grace_days, term_source, source_ref, reason, operator, operated_at) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	init	SQL	V1__init.sql	-845748185	floorplan	2026-10-26 00:17:32.808811	112	t
2	2	business gap features	SQL	V2__business_gap_features.sql	-133845080	floorplan	2026-10-26 09:40:06.88851	134	t
3	3	rating config	SQL	V3__rating_config.sql	-961652621	floorplan	2026-10-26 09:40:07.192134	16	t
4	4	insurance claimed amount	SQL	V4__insurance_claimed_amount.sql	-891238388	floorplan	2026-10-26 10:12:00.532357	14	t
5	5	users auth	SQL	V5__users_auth.sql	-1165419861	floorplan	2026-10-26 11:38:08.416952	91	t
6	6	dealer profile and roles	SQL	V6__dealer_profile_and_roles.sql	880560887	floorplan	2026-10-26 12:34:24.121877	70	t
7	7	purchase order and payee	SQL	V7__purchase_order_and_payee.sql	30682759	floorplan	2026-10-26 19:09:16.666999	144	t
8	8	user roles	SQL	V8__user_roles.sql	837164423	floorplan	2026-10-26 19:09:16.854679	363	t
9	9	seed role accounts	SQL	V9__seed_role_accounts.sql	-2050264294	floorplan	2026-10-26 19:16:02.530615	263	t
10	10	collateral ledger	SQL	V10__collateral_ledger.sql	-111405767	floorplan	2026-10-26 20:23:55.318956	125	t
11	11	postlending monitoring	SQL	V11__postlending_monitoring.sql	-1856443363	floorplan	2026-10-26 14:23:06.564773	136	t
12	12	vehicle pending advance	SQL	V12__vehicle_pending_advance.sql	478813128	floorplan	2026-10-26 14:23:06.749004	29	t
\.


--
-- Data for Name: holidays; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.holidays (biz_date, is_business_day, note) FROM stdin;
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.import_batches (id, channel, filename, file_hash, total_rows, accepted_rows, rejected_rows, total_amount, status, operator, created_at, committed_at) FROM stdin;
\.


--
-- Data for Name: import_row_errors; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.import_row_errors (id, batch_id, row_no, field_name, reason, raw_value, created_at) FROM stdin;
\.


--
-- Data for Name: insurance_policies; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.insurance_policies (id, policy_no, vin, insurer, insured_amount, start_date, end_date, status, created_at, claimed_amount) FROM stdin;
47	POL-SMOKE-1026195105	TESTRP1026195105	东京海上日动	2000000	2026-10-26	2027-10-26	CLAIMED	2026-10-26 11:51:08.714343+00	500000
\.


--
-- Data for Name: interest_ledger; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.interest_ledger (id, vin, biz_date, principal_balance, daily_interest, rate_snapshot, created_at) FROM stdin;
3580	TESTVIN1026195105	2026-10-26	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3581	TESTVIN1026195105	2026-10-27	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3582	TESTVIN1026195105	2026-10-28	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3583	TESTVIN1026195105	2026-10-29	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3584	TESTVIN1026195105	2026-10-30	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3585	TESTVIN1026195105	2026-10-31	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3586	TESTVIN1026195105	2026-11-01	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3587	TESTVIN1026195105	2026-11-02	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3588	TESTVIN1026195105	2026-11-03	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3589	TESTVIN1026195105	2026-11-04	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3590	TESTVIN1026195105	2026-11-05	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3591	TESTVIN1026195105	2026-11-06	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3592	TESTVIN1026195105	2026-11-07	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3593	TESTVIN1026195105	2026-11-08	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3594	TESTVIN1026195105	2026-11-09	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3595	TESTVIN1026195105	2026-11-10	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3596	TESTVIN1026195105	2026-11-11	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3597	TESTVIN1026195105	2026-11-12	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3598	TESTVIN1026195105	2026-11-13	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3599	TESTVIN1026195105	2026-11-14	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3600	TESTVIN1026195105	2026-11-15	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3601	TESTVIN1026195105	2026-11-16	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3602	TESTVIN1026195105	2026-11-17	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3603	TESTVIN1026195105	2026-11-18	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3604	TESTVIN1026195105	2026-11-19	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3605	TESTVIN1026195105	2026-11-20	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3606	TESTVIN1026195105	2026-11-21	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3607	TESTVIN1026195105	2026-11-22	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3608	TESTVIN1026195105	2026-11-23	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3609	TESTVIN1026195105	2026-11-24	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3610	TESTVIN1026195105	2026-11-25	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3611	TESTVIN1026195105	2026-11-26	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3612	TESTVIN1026195105	2026-11-27	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3613	TESTVIN1026195105	2026-11-28	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3614	TESTVIN1026195105	2026-11-29	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3615	TESTVIN1026195105	2026-11-30	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3616	TESTVIN1026195105	2026-12-01	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3617	TESTVIN1026195105	2026-12-02	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3618	TESTVIN1026195105	2026-12-03	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3619	TESTVIN1026195105	2026-12-04	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3620	TESTVIN1026195105	2026-12-05	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3621	TESTVIN1026195105	2026-12-06	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3622	TESTVIN1026195105	2026-12-07	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3623	TESTVIN1026195105	2026-12-08	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3624	TESTVIN1026195105	2026-12-09	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3625	TESTVIN1026195105	2026-12-10	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3626	TESTVIN1026195105	2026-12-11	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3627	TESTVIN1026195105	2026-12-12	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3628	TESTVIN1026195105	2026-12-13	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3629	TESTVIN1026195105	2026-12-14	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3630	TESTVIN1026195105	2026-12-15	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3631	TESTVIN1026195105	2026-12-16	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3632	TESTVIN1026195105	2026-12-17	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3633	TESTVIN1026195105	2026-12-18	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3634	TESTVIN1026195105	2026-12-19	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3635	TESTVIN1026195105	2026-12-20	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3636	TESTVIN1026195105	2026-12-21	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3637	TESTVIN1026195105	2026-12-22	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3638	TESTVIN1026195105	2026-12-23	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3639	TESTVIN1026195105	2026-12-24	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3640	TESTVIN1026195105	2026-12-25	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3641	TESTVIN1026195105	2026-12-26	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3642	TESTVIN1026195105	2026-12-27	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3643	TESTVIN1026195105	2026-12-28	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3644	TESTVIN1026195105	2026-12-29	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3645	TESTVIN1026195105	2026-12-30	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3646	TESTVIN1026195105	2026-12-31	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3647	TESTVIN1026195105	2027-01-01	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3648	TESTVIN1026195105	2027-01-02	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3649	TESTVIN1026195105	2027-01-03	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3650	TESTVIN1026195105	2027-01-04	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3651	TESTVIN1026195105	2027-01-05	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3652	TESTVIN1026195105	2027-01-06	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3653	TESTVIN1026195105	2027-01-07	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3654	TESTVIN1026195105	2027-01-08	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3655	TESTVIN1026195105	2027-01-09	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3656	TESTVIN1026195105	2027-01-10	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3657	TESTVIN1026195105	2027-01-11	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3658	TESTVIN1026195105	2027-01-12	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3659	TESTVIN1026195105	2027-01-13	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3660	TESTVIN1026195105	2027-01-14	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3661	TESTVIN1026195105	2027-01-15	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3662	TESTVIN1026195105	2027-01-16	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3663	TESTVIN1026195105	2027-01-17	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3664	TESTVIN1026195105	2027-01-18	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3665	TESTVIN1026195105	2027-01-19	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3666	TESTVIN1026195105	2027-01-20	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3667	TESTVIN1026195105	2027-01-21	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3668	TESTVIN1026195105	2027-01-22	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3669	TESTVIN1026195105	2027-01-23	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3670	TESTVIN1026195105	2027-01-24	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3671	TESTVIN1026195105	2027-01-25	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3672	TESTVIN1026195105	2027-01-26	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3673	TESTVIN1026195105	2027-01-27	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3674	TESTVIN1026195105	2027-01-28	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3675	TESTVIN1026195105	2027-01-29	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3676	TESTVIN1026195105	2027-01-30	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3677	TESTVIN1026195105	2027-01-31	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3678	TESTVIN1026195105	2027-02-01	1665000	160	0.0350	2026-10-26 11:51:07.234018+00
3679	TESTVIN1026195105	2027-02-02	1665000	160	0.0350	2026-10-26 11:51:07.333969+00
3680	TESTVIN1026195105	2027-02-03	1665000	160	0.0350	2026-10-26 11:51:07.348718+00
\.


--
-- Data for Name: interest_ledger_archive; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.interest_ledger_archive (id, vin, biz_date, principal_balance, daily_interest, rate_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: payoff_certificates; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.payoff_certificates (id, cert_no, vin, principal, interest, total_amount, issued_at, operator) FROM stdin;
1	PAY-9F1F76CA	TESTVIN1026095442	1665000	640	1665640	2026-10-26 01:54:44.568997+00	1
2	PAY-900BBBCA	TESTVIN1026101239	1665000	640	1665640	2026-10-26 02:12:41.004281+00	1
3	PAY-95670781	TESTVIN1026114006	1665000	640	1665640	2026-10-26 03:40:08.355482+00	1
4	PAY-3B175A06	TESTVIN1026122110	1665000	640	1665640	2026-10-26 04:21:12.115497+00	1
5	PAY-D141D337	TESTVIN1026124738	1665000	640	1665640	2026-10-26 04:47:40.465502+00	1
6	PAY-60A5293E	TESTVIN1026124747	1665000	640	1665640	2026-10-26 04:47:48.862146+00	1
7	PAY-ADE8EC00	TESTVIN1026124750	1665000	640	1665640	2026-10-26 04:47:51.908868+00	1
8	PAY-6E7D426A	TESTVIN1026124842	1665000	640	1665640	2026-10-26 04:48:43.736676+00	1
9	PAY-0DDBAFF3	TESTVIN1026125514	1665000	640	1665640	2026-10-26 04:55:16.347409+00	1
10	PAY-01C6BA81	TESTVIN1026125703	1665000	640	1665640	2026-10-26 04:57:05.90016+00	1
11	PAY-5061FAF4	TESTVIN1026125713	1665000	640	1665640	2026-10-26 04:57:14.947859+00	1
12	PAY-D35E7891	TESTVIN1026140013	1665000	640	1665640	2026-10-26 06:00:15.866549+00	admin
13	PAY-5C076AC3	TESTVIN1026140024	1665000	640	1665640	2026-10-26 06:00:26.170593+00	admin
14	PAY-CDFCFF0F	TESTVIN1026140033	1665000	640	1665640	2026-10-26 06:00:35.273831+00	admin
15	PAY-ED07ED5C	TESTVIN1026161008	1665000	640	1665640	2026-10-26 08:10:11.44234+00	admin
16	PAY-0DB5E9F8	TESTVIN1026161026	1665000	640	1665640	2026-10-26 08:10:29.048746+00	admin
17	PAY-29389E6C	TESTVIN1026161133	1665000	640	1665640	2026-10-26 08:11:35.245099+00	admin
18	PAY-65AA193A	TESTVIN1026162441	1665000	640	1665640	2026-10-26 08:24:44.174515+00	admin
19	PAY-0F75DA0B	TESTVIN1026162504	1665000	640	1665640	2026-10-26 08:25:06.78337+00	admin
20	PAY-3253D07D	TESTVIN1026172506	1665000	640	1665640	2026-10-26 09:25:09.323836+00	admin
21	PAY-051724D8	TESTVIN1026193233	1665000	30080	1695080	2026-10-26 11:32:35.935188+00	settlement
22	PAY-A131FA43	TESTVIN1026193256	1665000	33760	1698760	2026-10-26 11:32:58.933486+00	settlement
23	PAY-71AB0A99	TESTVIN1026193346	1665000	41920	1706920	2026-10-26 11:33:49.272894+00	settlement
24	PAY-289FB393	TESTVIN1026194237	1665000	30880	1695880	2026-10-26 11:42:40.449916+00	settlement
25	PAY-567BF6D3	TESTVIN1026195105	1665000	16160	1681160	2026-10-26 11:51:08.8922+00	settlement
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.purchase_orders (id, order_no, dealer_id, credit_line_id, supplier_id, supplier_type, payee_account_id, payee_account_snapshot, total_amount, vehicle_count, purchased_at, evidence_no, evidence_attachment_id, status, ingest_channel, import_batch_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rating_configs; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.rating_configs (grade, grade_name, rate_surcharge, allowed, sort_order, remark, updated_at, updated_by) FROM stdin;
A	优质（默认）	0.0000	t	1	默认：执行基准利率	2026-10-26 01:40:07.204021+00	system
C	关注（默认）	0.0100	t	3	默认：基准 + 1.0%	2026-10-26 01:40:07.204021+00	system
D	观察（默认）	0.0200	f	4	默认：基准 + 2.0%，暂不准入新业务	2026-10-26 01:40:07.204021+00	system
B	标准（预设）	0.0050	t	2	预设：基准 + 0.5%，待客户确认	2026-10-26 11:51:09.729192+00	admin
\.


--
-- Data for Name: repayments; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.repayments (id, repayment_no, vin, principal, interest, total_amount, settled_at, operator_id, idempotency_key, created_at, repayment_type, account_ref, designated_use) FROM stdin;
153	REP-366489B6	TESTVIN1026195105	1665000	16160	1681160	2026-10-26 11:51:07.421527+00	7	rep-smoke-TESTVIN1026195105	2026-10-26 11:51:07.417526+00	FULL	\N	f
154	REP-4B99056A	TESTRP1026195105	100000	0	100000	2026-10-26 11:51:08.646028+00	\N	part-TESTRP1026195105	2026-10-26 11:51:08.643964+00	PARTIAL	\N	f
155	REP-8791F62D	COLA018534	1665000	0	1665000	2026-10-26 12:42:14.925205+00	7	1b33a58a-aa39-415f-924b-f7fdca197a5c	2026-10-26 12:42:14.921136+00	FULL	\N	f
\.


--
-- Data for Name: repurchase_requests; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.repurchase_requests (id, request_no, vin, dealer_id, credit_line_id, reason, status, repurchase_amount, fulfilled_at, created_at) FROM stdin;
55	RPR-E8BA3090	TESTRP1026195105	285	238	滞销库存厂家回购承诺	FULFILLED	832500	2026-10-26 11:51:08.628504+00	2026-10-26 11:51:08.578226+00
\.


--
-- Data for Name: risk_alerts; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.risk_alerts (id, alert_code, severity, dealer_id, vin, batch_id, metric_value, threshold_value, detail, evidence_refs, first_seen_at, last_seen_at, occurrence_count, status) FROM stdin;
\.


--
-- Data for Name: risk_concentration_snapshots; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.risk_concentration_snapshots (id, biz_date, dimension, dimension_key, exposure, total_exposure, ratio, vehicle_count, created_at) FROM stdin;
\.


--
-- Data for Name: risk_rules; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.risk_rules (id, rule_code, metric, threshold_type, threshold_value, unit, severity, window_days, enabled, applies_to, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: security_records; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.security_records (id, vin, security_type, reg_no, owner_name, set_date, release_date, doc_status, created_at) FROM stdin;
\.


--
-- Data for Name: supplier_bank_accounts; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.supplier_bank_accounts (id, supplier_id, bank_name, account_holder, account_no_cipher, account_no_mask, account_ref, status, effective_from, effective_to, reviewer, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.suppliers (id, supplier_code, name, supplier_type, status, risk_grade, guarantee_ability, contact_person, contact_phone, remark, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.user_roles (id, username, role_code, is_primary, granted_at, granted_by) FROM stdin;
1	admin	SYSTEM_ADMIN	t	2026-10-26 19:09:16.863149	\N
2	operator	BUSINESS_OPERATOR	t	2026-10-26 19:09:16.863149	\N
3	import_op	PURCHASE_OPERATOR	t	2026-10-26 19:09:16.863149	\N
4	review_op	PURCHASE_REVIEWER	t	2026-10-26 19:09:16.863149	\N
5	fund_rev	FUNDING_REVIEWER	t	2026-10-26 19:09:16.863149	\N
6	cashier	FUNDING_CASHIER	t	2026-10-26 19:09:16.863149	\N
7	settlement	SETTLEMENT_OFFICER	t	2026-10-26 19:09:16.863149	\N
8	disposal	DISPOSAL_OFFICER	t	2026-10-26 19:09:16.863149	\N
9	multi_role	PURCHASE_OPERATOR	t	2026-10-26 19:09:16.863149	\N
10	multi_role	RISK_ADVISORY_OFFICER	f	2026-10-26 19:09:16.863149	\N
11	credit	CREDIT_REVIEWER	t	2026-10-26 19:16:02.546432	\N
12	advisory	RISK_ADVISORY_OFFICER	t	2026-10-26 19:16:02.546432	\N
13	post_lending	POST_LENDING_MANAGER	t	2026-10-26 19:16:02.546432	\N
14	collection	COLLECTION_OFFICER	t	2026-10-26 19:16:02.546432	\N
15	collateral	COLLATERAL_OFFICER	t	2026-10-26 19:16:02.546432	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.users (id, username, password_hash, display_name, role, enabled, created_at) FROM stdin;
1	admin	$2a$10$rSHkoomcbu88AxugvnqOROE7GObx82LMwX9erg/yMkg27aTeM3xLm	系统管理员	SYSTEM_ADMIN	t	2026-10-26 11:38:08.435757
2	operator	$2a$10$5.0A5e9JKWs185Zq.Qx1BOSn/CPUvPIdx0SlvA1fuIKXSUND/WETi	业务操作员	BUSINESS_OPERATOR	t	2026-10-26 12:34:24.138825
3	import_op	$2a$10$ypdX26Eb4Ao/0P8Qj5W0JeH2rAJrpe4cf0wKSx1fClDi0CatjxCxi	采购数据录入岗	PURCHASE_OPERATOR	t	2026-10-26 19:09:16.863149
4	review_op	$2a$10$1iochXDsIsSe4ytua.jjMuIDdZUgUG.GeFHr/IKgrCMlCxovmyAlu	采购审核岗	PURCHASE_REVIEWER	t	2026-10-26 19:09:16.863149
5	fund_rev	$2a$10$9yQhARP5PyKiUC1fPaW9PO4VvLkaS6GUZDZGKZuoEdrIV3MCs5Y7W	资金复核岗	FUNDING_REVIEWER	t	2026-10-26 19:09:16.863149
6	cashier	$2a$10$zO0dhZz8OdKaF5SY8FmhVesinkhoMVfEyfQxPErw3BZ25r8hjL9my	资金出纳岗	FUNDING_CASHIER	t	2026-10-26 19:09:16.863149
7	settlement	$2a$10$uLGy2grSByW7nU8adhhEQuCMY5hhNjzYutcBkE4KhhlxAoDZT2U92	结算岗	SETTLEMENT_OFFICER	t	2026-10-26 19:09:16.863149
8	disposal	$2a$10$m9jfsqP9kn42ZRhHng1VOu2BswbiKmy.gorj5HXnUO8PUop9DlkJ6	违约处置岗	DISPOSAL_OFFICER	t	2026-10-26 19:09:16.863149
9	multi_role	$2a$10$fKGJ4reV2ESh0NlvAXsmnuQjVRuoJbaOwGlX54yFFHusoB2nFQnBq	多岗兼任测试账号	PURCHASE_OPERATOR	t	2026-10-26 19:09:16.863149
11	credit	$2a$10$oPr8/UayUo7uYb7gScQ6U..3Y3bn7Q26FdYh2ZauKD9aFv/FnjkV6	授信审查岗	CREDIT_REVIEWER	t	2026-10-26 19:16:02.546432
12	advisory	$2a$10$98rpL6u0HSWa.13E1OiaCOm.QJaazlpSOUWa6qWWK1Z2aSElbqUWu	增信业务岗	RISK_ADVISORY_OFFICER	t	2026-10-26 19:16:02.546432
13	post_lending	$2a$10$Hg/1wghZwAysLrEdzoIpc.gbkgpY0wpoIGxTEYXwgftZuOQGp4B.u	贷后管理岗	POST_LENDING_MANAGER	t	2026-10-26 19:16:02.546432
14	collection	$2a$10$vJeAvZXZvGKwcACs7uc2RuOgc5DRBFS7R7P3La1UUaSWACxgfkN8G	催收岗	COLLECTION_OFFICER	t	2026-10-26 19:16:02.546432
15	collateral	$2a$10$usyVizJFMvqc4V53i3Z54er23Wrdi0U5CmORrqCrQLcb6pQe//7B.	担保管理岗	COLLATERAL_OFFICER	t	2026-10-26 19:16:02.546432
\.


--
-- Data for Name: vehicle_units; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.vehicle_units (vin, dealer_id, credit_line_id, advance_id, brand, model, model_year, mileage, color, vehicle_type, supplier_name, purchase_channel, invoice_amount, advance_amount, advance_ratio, advanced_at, principal_balance, paid_principal, annual_rate, rate_type, accrued_interest, last_interest_date, stock_in_date, sold_at, settle_due_date, settled_at, aging_days, turnover_days, status, security_type, security_status, overdue_days, risk_level, oot_suspected, last_audit_date, audit_mismatch_count, version, created_at, updated_at, purchase_order_id, maturity_date, grace_period_days, overdue_rate, term_source, term_confirmed_at, term_confirmed_by, residual_value_estimated, residual_value_source, residual_value_at) FROM stdin;
TESTVIN1026195105	285	238	\N	TOYOTA	COROLLA	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	0	1665000	0.0350	FLOATING	16160	2027-02-03	2026-10-26	2026-10-26	2026-10-28	2026-10-26	0	\N	SETTLED	RETENTION	RELEASED	0	\N	f	\N	0	7	2026-10-26 11:51:06.748204+00	2026-10-26 11:51:07.417526+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTCT1026195105	285	238	\N	TOYOTA	SMOKE	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	1498500	166500	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	2	2026-10-26 11:51:07.78991+00	2026-10-26 11:51:08.280828+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTRP1026195105	285	238	\N	TOYOTA	SMOKE	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	732500	932500	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	3	2026-10-26 11:51:08.391479+00	2026-10-26 11:51:08.643964+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTEX1026195105	285	238	\N	TOYOTA	SMOKE	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-10-26	2026-11-04	\N	0	\N	SOLD_PENDING	\N	\N	0	LOW	f	\N	0	3	2026-10-26 11:51:08.782928+00	2026-10-26 11:51:08.879095+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTWN1026195105	285	238	\N	TOYOTA	SMOKE	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-10-22	2026-10-26	\N	0	\N	SOLD_PENDING	\N	\N	0	\N	f	\N	0	2	2026-10-26 11:51:09.052419+00	2026-10-26 11:51:09.16874+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTDP1026195105	285	238	\N	TOYOTA	SMOKE	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	CLOSED	\N	\N	0	HIGH	f	\N	0	3	2026-10-26 11:51:09.347888+00	2026-10-26 11:51:09.584558+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTGR1026195105	285	238	\N	TOYOTA	SMOKE	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-10-12	2026-10-14	\N	0	\N	DISPOSING	\N	\N	12	HIGH	t	\N	0	4	2026-10-26 11:51:09.178543+00	2026-10-26 11:51:09.604886+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTSOD1026195105	285	238	\N	TOYOTA	SOD	2026	\N	WHITE	\N	SOD 厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	1	2026-10-26 11:51:10.006101+00	2026-10-26 11:51:10.605+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB017725	291	242	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	1	2026-10-26 12:28:46.395785+00	2026-10-26 12:28:46.632321+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA017725	291	242	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-08-01	2026-08-04	\N	0	\N	SOLD_PENDING	\N	\N	0	\N	f	\N	0	2	2026-10-26 12:28:46.395785+00	2026-10-26 12:28:46.820655+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB018493	293	244	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	1	2026-10-26 12:41:34.563732+00	2026-10-26 12:41:34.72802+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA018493	293	244	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-08-01	2026-08-04	\N	0	\N	SOLD_PENDING	\N	\N	0	\N	f	\N	0	2	2026-10-26 12:41:34.563732+00	2026-10-26 12:41:34.891097+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB018520	294	245	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	1	2026-10-26 12:42:01.27941+00	2026-10-26 12:42:01.372537+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA018520	294	245	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-08-01	2026-08-04	\N	0	\N	SOLD_PENDING	\N	\N	0	\N	f	\N	0	2	2026-10-26 12:42:01.27941+00	2026-10-26 12:42:01.488518+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB018534	295	246	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	1	2026-10-26 12:42:14.664348+00	2026-10-26 12:42:14.783534+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA018534	295	246	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	0	1665000	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-08-01	2026-08-04	2026-10-26	0	\N	SETTLED	\N	RELEASED	0	\N	f	\N	0	3	2026-10-26 12:42:14.664348+00	2026-10-26 12:42:14.921136+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTRT1026195105	285	238	\N	HONDA	FIT	2026	\N	BLUE	\N	测试厂家	OEM	1500000	1350000	0.9000	\N	0	0	0.0380	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 11:51:09.693503+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
TESTFAIL1026195105	285	238	\N	TOYOTA	FAIL	2026	\N	WHITE	\N	FAIL 厂家	OEM	1850000	1665000	0.9000	\N	0	0	0.0350	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 11:51:10.621608+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB017866	292	243	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	\N	\N	\N	0	\N	IN_STOCK	\N	\N	0	\N	f	\N	0	1	2026-10-26 12:31:06.779074+00	2026-10-26 12:31:06.927668+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA017866	292	243	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	1665000	0	0.0350	FLOATING	0	2026-10-25	2026-10-26	2026-08-01	2026-08-04	\N	0	\N	SOLD_PENDING	\N	\N	0	\N	f	\N	0	2	2026-10-26 12:31:06.779074+00	2026-10-26 12:31:07.035082+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA017481	288	239	\N	TOYOTA	COL	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	0	0	0.0350	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 12:24:42.411478+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB017481	288	239	\N	TOYOTA	COL	2026	\N	WHITE	\N	测试厂家	OEM	1850000	1665000	0.9000	\N	0	0	0.0350	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 12:24:42.411478+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA017527	289	240	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	0	0	0.0350	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 12:25:28.07188+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB017527	289	240	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	0	0	0.0350	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 12:25:28.07188+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLA017554	290	241	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	0	0	0.0350	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 12:25:55.427639+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
COLB017554	290	241	\N	TOYOTA	COL	2026	\N	WHITE	\N	验证厂家	OEM	1850000	1665000	0.9000	\N	0	0	0.0350	FLOATING	0	\N	\N	\N	\N	\N	0	\N	PENDING_ADVANCE	\N	\N	0	\N	f	\N	0	0	2026-10-26 12:25:55.427639+00	2026-10-26 14:23:06.758553+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: work_order_actions; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.work_order_actions (id, order_id, action_type, action_data, attachment_id, operator, operated_at) FROM stdin;
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: floorplan
--

COPY public.work_orders (id, order_no, order_type, source_alert_id, dealer_id, vin, batch_id, severity, priority, status, assignee, sla_due_at, sla_breached, resolution, resolution_code, created_by, created_at, acknowledged_at, resolved_at) FROM stdin;
\.


--
-- Name: advances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.advances_id_seq', 380, true);


--
-- Name: aging_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.aging_plans_id_seq', 48, true);


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.alerts_id_seq', 223, true);


--
-- Name: annual_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.annual_reviews_id_seq', 62, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, false);


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.audit_events_id_seq', 1768, true);


--
-- Name: batch_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.batch_runs_id_seq', 253, true);


--
-- Name: collateral_evidence_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.collateral_evidence_links_id_seq', 16, true);


--
-- Name: collateral_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.collateral_ledger_id_seq', 27, true);


--
-- Name: collateral_registration_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.collateral_registration_batches_id_seq', 14, true);


--
-- Name: collateral_registration_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.collateral_registration_items_id_seq', 10, true);


--
-- Name: credit_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.credit_lines_id_seq', 246, true);


--
-- Name: curtailment_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.curtailment_payments_id_seq', 24, true);


--
-- Name: dealer_bank_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.dealer_bank_accounts_id_seq', 1, false);


--
-- Name: dealers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.dealers_id_seq', 295, true);


--
-- Name: disposal_cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.disposal_cases_id_seq', 116, true);


--
-- Name: domain_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.domain_events_id_seq', 1, false);


--
-- Name: extension_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.extension_requests_id_seq', 25, true);


--
-- Name: financing_lien_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.financing_lien_checks_id_seq', 29, true);


--
-- Name: financing_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.financing_terms_id_seq', 1, false);


--
-- Name: import_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.import_batches_id_seq', 1, false);


--
-- Name: import_row_errors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.import_row_errors_id_seq', 1, false);


--
-- Name: insurance_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.insurance_policies_id_seq', 48, true);


--
-- Name: interest_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.interest_ledger_id_seq', 3680, true);


--
-- Name: payoff_certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.payoff_certificates_id_seq', 25, true);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 1, false);


--
-- Name: repayments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.repayments_id_seq', 155, true);


--
-- Name: repurchase_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.repurchase_requests_id_seq', 56, true);


--
-- Name: risk_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.risk_alerts_id_seq', 1, false);


--
-- Name: risk_concentration_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.risk_concentration_snapshots_id_seq', 1, false);


--
-- Name: risk_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.risk_rules_id_seq', 1, false);


--
-- Name: security_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.security_records_id_seq', 1, false);


--
-- Name: supplier_bank_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.supplier_bank_accounts_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 15, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.users_id_seq', 15, true);


--
-- Name: work_order_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.work_order_actions_id_seq', 1, false);


--
-- Name: work_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: floorplan
--

SELECT pg_catalog.setval('public.work_orders_id_seq', 1, false);


--
-- Name: advances advances_advance_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.advances
    ADD CONSTRAINT advances_advance_no_key UNIQUE (advance_no);


--
-- Name: advances advances_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.advances
    ADD CONSTRAINT advances_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: advances advances_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.advances
    ADD CONSTRAINT advances_pkey PRIMARY KEY (id);


--
-- Name: aging_plans aging_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.aging_plans
    ADD CONSTRAINT aging_plans_pkey PRIMARY KEY (id);


--
-- Name: aging_plans aging_plans_vin_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.aging_plans
    ADD CONSTRAINT aging_plans_vin_key UNIQUE (vin);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: annual_reviews annual_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.annual_reviews
    ADD CONSTRAINT annual_reviews_pkey PRIMARY KEY (id);


--
-- Name: annual_reviews annual_reviews_review_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.annual_reviews
    ADD CONSTRAINT annual_reviews_review_no_key UNIQUE (review_no);


--
-- Name: attachments attachments_object_key_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_object_key_key UNIQUE (object_key);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: batch_runs batch_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.batch_runs
    ADD CONSTRAINT batch_runs_pkey PRIMARY KEY (id);


--
-- Name: collateral_evidence_links collateral_evidence_links_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_evidence_links
    ADD CONSTRAINT collateral_evidence_links_pkey PRIMARY KEY (id);


--
-- Name: collateral_ledger collateral_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_ledger
    ADD CONSTRAINT collateral_ledger_pkey PRIMARY KEY (id);


--
-- Name: collateral_ledger collateral_ledger_vin_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_ledger
    ADD CONSTRAINT collateral_ledger_vin_key UNIQUE (vin);


--
-- Name: collateral_registration_batches collateral_registration_batches_batch_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_batches
    ADD CONSTRAINT collateral_registration_batches_batch_no_key UNIQUE (batch_no);


--
-- Name: collateral_registration_batches collateral_registration_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_batches
    ADD CONSTRAINT collateral_registration_batches_pkey PRIMARY KEY (id);


--
-- Name: collateral_registration_batches collateral_registration_batches_registration_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_batches
    ADD CONSTRAINT collateral_registration_batches_registration_no_key UNIQUE (registration_no);


--
-- Name: collateral_registration_items collateral_registration_items_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_items
    ADD CONSTRAINT collateral_registration_items_pkey PRIMARY KEY (id);


--
-- Name: credit_lines credit_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.credit_lines
    ADD CONSTRAINT credit_lines_pkey PRIMARY KEY (id);


--
-- Name: curtailment_payments curtailment_payments_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.curtailment_payments
    ADD CONSTRAINT curtailment_payments_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: curtailment_payments curtailment_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.curtailment_payments
    ADD CONSTRAINT curtailment_payments_pkey PRIMARY KEY (id);


--
-- Name: dealer_bank_accounts dealer_bank_accounts_account_ref_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.dealer_bank_accounts
    ADD CONSTRAINT dealer_bank_accounts_account_ref_key UNIQUE (account_ref);


--
-- Name: dealer_bank_accounts dealer_bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.dealer_bank_accounts
    ADD CONSTRAINT dealer_bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: dealers dealers_dealer_code_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_dealer_code_key UNIQUE (dealer_code);


--
-- Name: dealers dealers_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.dealers
    ADD CONSTRAINT dealers_pkey PRIMARY KEY (id);


--
-- Name: disposal_cases disposal_cases_case_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.disposal_cases
    ADD CONSTRAINT disposal_cases_case_no_key UNIQUE (case_no);


--
-- Name: disposal_cases disposal_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.disposal_cases
    ADD CONSTRAINT disposal_cases_pkey PRIMARY KEY (id);


--
-- Name: domain_events domain_events_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.domain_events
    ADD CONSTRAINT domain_events_pkey PRIMARY KEY (id);


--
-- Name: extension_requests extension_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.extension_requests
    ADD CONSTRAINT extension_requests_pkey PRIMARY KEY (id);


--
-- Name: extension_requests extension_requests_request_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.extension_requests
    ADD CONSTRAINT extension_requests_request_no_key UNIQUE (request_no);


--
-- Name: financing_lien_checks financing_lien_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.financing_lien_checks
    ADD CONSTRAINT financing_lien_checks_pkey PRIMARY KEY (id);


--
-- Name: financing_terms financing_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.financing_terms
    ADD CONSTRAINT financing_terms_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: holidays holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.holidays
    ADD CONSTRAINT holidays_pkey PRIMARY KEY (biz_date);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_row_errors import_row_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.import_row_errors
    ADD CONSTRAINT import_row_errors_pkey PRIMARY KEY (id);


--
-- Name: insurance_policies insurance_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.insurance_policies
    ADD CONSTRAINT insurance_policies_pkey PRIMARY KEY (id);


--
-- Name: insurance_policies insurance_policies_policy_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.insurance_policies
    ADD CONSTRAINT insurance_policies_policy_no_key UNIQUE (policy_no);


--
-- Name: interest_ledger_archive interest_ledger_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.interest_ledger_archive
    ADD CONSTRAINT interest_ledger_archive_pkey PRIMARY KEY (id);


--
-- Name: interest_ledger_archive interest_ledger_archive_vin_biz_date_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.interest_ledger_archive
    ADD CONSTRAINT interest_ledger_archive_vin_biz_date_key UNIQUE (vin, biz_date);


--
-- Name: interest_ledger interest_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.interest_ledger
    ADD CONSTRAINT interest_ledger_pkey PRIMARY KEY (id);


--
-- Name: payoff_certificates payoff_certificates_cert_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.payoff_certificates
    ADD CONSTRAINT payoff_certificates_cert_no_key UNIQUE (cert_no);


--
-- Name: payoff_certificates payoff_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.payoff_certificates
    ADD CONSTRAINT payoff_certificates_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_order_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_order_no_key UNIQUE (order_no);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: rating_configs rating_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.rating_configs
    ADD CONSTRAINT rating_configs_pkey PRIMARY KEY (grade);


--
-- Name: repayments repayments_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.repayments
    ADD CONSTRAINT repayments_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: repayments repayments_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.repayments
    ADD CONSTRAINT repayments_pkey PRIMARY KEY (id);


--
-- Name: repayments repayments_repayment_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.repayments
    ADD CONSTRAINT repayments_repayment_no_key UNIQUE (repayment_no);


--
-- Name: repurchase_requests repurchase_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.repurchase_requests
    ADD CONSTRAINT repurchase_requests_pkey PRIMARY KEY (id);


--
-- Name: repurchase_requests repurchase_requests_request_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.repurchase_requests
    ADD CONSTRAINT repurchase_requests_request_no_key UNIQUE (request_no);


--
-- Name: risk_alerts risk_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_alerts
    ADD CONSTRAINT risk_alerts_pkey PRIMARY KEY (id);


--
-- Name: risk_concentration_snapshots risk_concentration_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_concentration_snapshots
    ADD CONSTRAINT risk_concentration_snapshots_pkey PRIMARY KEY (id);


--
-- Name: risk_rules risk_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_rules
    ADD CONSTRAINT risk_rules_pkey PRIMARY KEY (id);


--
-- Name: risk_rules risk_rules_rule_code_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_rules
    ADD CONSTRAINT risk_rules_rule_code_key UNIQUE (rule_code);


--
-- Name: security_records security_records_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.security_records
    ADD CONSTRAINT security_records_pkey PRIMARY KEY (id);


--
-- Name: supplier_bank_accounts supplier_bank_accounts_account_ref_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.supplier_bank_accounts
    ADD CONSTRAINT supplier_bank_accounts_account_ref_key UNIQUE (account_ref);


--
-- Name: supplier_bank_accounts supplier_bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.supplier_bank_accounts
    ADD CONSTRAINT supplier_bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_supplier_code_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_supplier_code_key UNIQUE (supplier_code);


--
-- Name: collateral_registration_items uk_cri_batch_vin; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_items
    ADD CONSTRAINT uk_cri_batch_vin UNIQUE (batch_id, vin);


--
-- Name: domain_events uk_domain_event; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.domain_events
    ADD CONSTRAINT uk_domain_event UNIQUE (source, event_type, biz_key);


--
-- Name: risk_concentration_snapshots uk_rcs; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.risk_concentration_snapshots
    ADD CONSTRAINT uk_rcs UNIQUE (biz_date, dimension, dimension_key);


--
-- Name: user_roles uk_user_role; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT uk_user_role UNIQUE (username, role_code);


--
-- Name: batch_runs uq_batch_job_date; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.batch_runs
    ADD CONSTRAINT uq_batch_job_date UNIQUE (job_name, biz_date);


--
-- Name: interest_ledger uq_interest_vin_date; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.interest_ledger
    ADD CONSTRAINT uq_interest_vin_date UNIQUE (vin, biz_date);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vehicle_units vehicle_units_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.vehicle_units
    ADD CONSTRAINT vehicle_units_pkey PRIMARY KEY (vin);


--
-- Name: work_order_actions work_order_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.work_order_actions
    ADD CONSTRAINT work_order_actions_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_order_no_key; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_order_no_key UNIQUE (order_no);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_advances_po; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_advances_po ON public.advances USING btree (purchase_order_id);


--
-- Name: idx_advances_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_advances_vin ON public.advances USING btree (vin);


--
-- Name: idx_aging_next_due; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_aging_next_due ON public.aging_plans USING btree (next_due_date);


--
-- Name: idx_alerts_type_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_alerts_type_status ON public.alerts USING btree (alert_type, status);


--
-- Name: idx_attachment_biz; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_attachment_biz ON public.attachments USING btree (biz_type, biz_id);


--
-- Name: idx_audit_target; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_audit_target ON public.audit_events USING btree (target_type, target_id);


--
-- Name: idx_cel_ledger; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cel_ledger ON public.collateral_evidence_links USING btree (ledger_id);


--
-- Name: idx_cel_ref; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cel_ref ON public.collateral_evidence_links USING btree (ref_type, ref_id);


--
-- Name: idx_cel_type; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cel_type ON public.collateral_evidence_links USING btree (evidence_type);


--
-- Name: idx_cel_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cel_vin ON public.collateral_evidence_links USING btree (vin);


--
-- Name: idx_cl_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cl_dealer ON public.collateral_ledger USING btree (dealer_id);


--
-- Name: idx_cl_due; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cl_due ON public.collateral_ledger USING btree (registration_due) WHERE (registration_due = true);


--
-- Name: idx_cl_sold_unpaid; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cl_sold_unpaid ON public.collateral_ledger USING btree (sold, repaid) WHERE ((sold = true) AND (repaid = false));


--
-- Name: idx_crb_cancel_todo; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_crb_cancel_todo ON public.collateral_registration_batches USING btree (cancellation_status) WHERE ((cancellation_status)::text = ANY ((ARRAY['REQUESTED'::character varying, 'APPLIED'::character varying])::text[]));


--
-- Name: idx_crb_expires; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_crb_expires ON public.collateral_registration_batches USING btree (expires_at) WHERE ((expires_at IS NOT NULL) AND ((cancellation_status)::text <> ALL ((ARRAY['DONE'::character varying, 'CANCELLED'::character varying])::text[])));


--
-- Name: idx_crb_regno; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_crb_regno ON public.collateral_registration_batches USING btree (registration_no) WHERE (registration_no IS NOT NULL);


--
-- Name: idx_credit_lines_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_credit_lines_dealer ON public.credit_lines USING btree (dealer_id);


--
-- Name: idx_cri_batch; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cri_batch ON public.collateral_registration_items USING btree (batch_id);


--
-- Name: idx_cri_ledger; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cri_ledger ON public.collateral_registration_items USING btree (ledger_id);


--
-- Name: idx_cri_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_cri_vin ON public.collateral_registration_items USING btree (vin);


--
-- Name: idx_curtail_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_curtail_vin ON public.curtailment_payments USING btree (vin);


--
-- Name: idx_dealer_accounts_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_dealer_accounts_dealer ON public.dealer_bank_accounts USING btree (dealer_id);


--
-- Name: idx_dealer_accounts_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_dealer_accounts_status ON public.dealer_bank_accounts USING btree (status);


--
-- Name: idx_disposal_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_disposal_status ON public.disposal_cases USING btree (status);


--
-- Name: idx_disposal_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_disposal_vin ON public.disposal_cases USING btree (vin);


--
-- Name: idx_domain_events_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_domain_events_status ON public.domain_events USING btree (status, received_at);


--
-- Name: idx_domain_events_type; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_domain_events_type ON public.domain_events USING btree (event_type, event_time DESC);


--
-- Name: idx_domain_events_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_domain_events_vin ON public.domain_events USING btree (vin);


--
-- Name: idx_ext_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_ext_vin ON public.extension_requests USING btree (vin);


--
-- Name: idx_financing_terms_at; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_financing_terms_at ON public.financing_terms USING btree (operated_at DESC);


--
-- Name: idx_financing_terms_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_financing_terms_vin ON public.financing_terms USING btree (vin);


--
-- Name: idx_import_batches_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_import_batches_status ON public.import_batches USING btree (status);


--
-- Name: idx_import_row_errors_batch; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_import_row_errors_batch ON public.import_row_errors USING btree (batch_id);


--
-- Name: idx_ins_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_ins_vin ON public.insurance_policies USING btree (vin);


--
-- Name: idx_lien_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_lien_vin ON public.financing_lien_checks USING btree (vin);


--
-- Name: idx_payoff_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_payoff_vin ON public.payoff_certificates USING btree (vin);


--
-- Name: idx_po_batch; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_po_batch ON public.purchase_orders USING btree (import_batch_id);


--
-- Name: idx_po_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_po_dealer ON public.purchase_orders USING btree (dealer_id);


--
-- Name: idx_po_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_po_status ON public.purchase_orders USING btree (status);


--
-- Name: idx_po_supplier; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_po_supplier ON public.purchase_orders USING btree (supplier_id);


--
-- Name: idx_rcs_dim; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_rcs_dim ON public.risk_concentration_snapshots USING btree (dimension, biz_date DESC);


--
-- Name: idx_repayments_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_repayments_vin ON public.repayments USING btree (vin);


--
-- Name: idx_repurchase_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_repurchase_vin ON public.repurchase_requests USING btree (vin);


--
-- Name: idx_review_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_review_dealer ON public.annual_reviews USING btree (dealer_id);


--
-- Name: idx_risk_alerts_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_risk_alerts_dealer ON public.risk_alerts USING btree (dealer_id);


--
-- Name: idx_risk_alerts_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_risk_alerts_status ON public.risk_alerts USING btree (status, severity);


--
-- Name: idx_risk_alerts_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_risk_alerts_vin ON public.risk_alerts USING btree (vin);


--
-- Name: idx_security_vin; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_security_vin ON public.security_records USING btree (vin);


--
-- Name: idx_supplier_accounts_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_supplier_accounts_status ON public.supplier_bank_accounts USING btree (status);


--
-- Name: idx_supplier_accounts_supplier; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_supplier_accounts_supplier ON public.supplier_bank_accounts USING btree (supplier_id);


--
-- Name: idx_suppliers_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_suppliers_status ON public.suppliers USING btree (status);


--
-- Name: idx_suppliers_type; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_suppliers_type ON public.suppliers USING btree (supplier_type);


--
-- Name: idx_user_roles_username; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_user_roles_username ON public.user_roles USING btree (username);


--
-- Name: idx_vehicle_units_po; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vehicle_units_po ON public.vehicle_units USING btree (purchase_order_id);


--
-- Name: idx_vu_aging; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vu_aging ON public.vehicle_units USING btree (aging_days);


--
-- Name: idx_vu_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vu_dealer ON public.vehicle_units USING btree (dealer_id);


--
-- Name: idx_vu_interest; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vu_interest ON public.vehicle_units USING btree (last_interest_date);


--
-- Name: idx_vu_pending_advance; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vu_pending_advance ON public.vehicle_units USING btree (dealer_id, created_at) WHERE ((status)::text = 'PENDING_ADVANCE'::text);


--
-- Name: INDEX idx_vu_pending_advance; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON INDEX public.idx_vu_pending_advance IS '待放款清单：仅索引 PENDING_ADVANCE 行';


--
-- Name: idx_vu_settle_due; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vu_settle_due ON public.vehicle_units USING btree (settle_due_date);


--
-- Name: idx_vu_status; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vu_status ON public.vehicle_units USING btree (status);


--
-- Name: idx_vu_term_missing; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_vu_term_missing ON public.vehicle_units USING btree (advanced_at) WHERE ((maturity_date IS NULL) AND (term_source IS NULL));


--
-- Name: idx_wo_assignee; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_wo_assignee ON public.work_orders USING btree (assignee, status);


--
-- Name: idx_wo_dealer; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_wo_dealer ON public.work_orders USING btree (dealer_id);


--
-- Name: idx_wo_sla; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_wo_sla ON public.work_orders USING btree (status, sla_due_at);


--
-- Name: idx_woa_order; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE INDEX idx_woa_order ON public.work_order_actions USING btree (order_id);


--
-- Name: uk_po_vin_active; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE UNIQUE INDEX uk_po_vin_active ON public.vehicle_units USING btree (vin) WHERE ((purchase_order_id IS NOT NULL) AND ((status)::text = ANY ((ARRAY['PENDING_ADVANCE'::character varying, 'FINANCED'::character varying, 'IN_STOCK'::character varying, 'SOLD_PENDING'::character varying])::text[])));


--
-- Name: INDEX uk_po_vin_active; Type: COMMENT; Schema: public; Owner: floorplan
--

COMMENT ON INDEX public.uk_po_vin_active IS 'VIN 幂等：同一 VIN 不得出现在两个未终结采购订单中；状态集合须与 VehicleStatus.ACTIVE 同步（V12 起含 PENDING_ADVANCE）';


--
-- Name: uk_risk_alert_open; Type: INDEX; Schema: public; Owner: floorplan
--

CREATE UNIQUE INDEX uk_risk_alert_open ON public.risk_alerts USING btree (alert_code, COALESCE(vin, ''::character varying), COALESCE(batch_id, (0)::bigint)) WHERE ((status)::text = ANY ((ARRAY['OPEN'::character varying, 'ACKNOWLEDGED'::character varying, 'IN_PROGRESS'::character varying])::text[]));


--
-- Name: advances advances_payee_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.advances
    ADD CONSTRAINT advances_payee_supplier_id_fkey FOREIGN KEY (payee_supplier_id) REFERENCES public.suppliers(id);


--
-- Name: advances advances_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.advances
    ADD CONSTRAINT advances_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: collateral_evidence_links collateral_evidence_links_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_evidence_links
    ADD CONSTRAINT collateral_evidence_links_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachments(id);


--
-- Name: collateral_evidence_links collateral_evidence_links_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_evidence_links
    ADD CONSTRAINT collateral_evidence_links_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.collateral_ledger(id);


--
-- Name: collateral_registration_batches collateral_registration_batch_cancellation_certificate_att_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_batches
    ADD CONSTRAINT collateral_registration_batch_cancellation_certificate_att_fkey FOREIGN KEY (cancellation_certificate_attachment_id) REFERENCES public.attachments(id);


--
-- Name: collateral_registration_batches collateral_registration_batches_certificate_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_batches
    ADD CONSTRAINT collateral_registration_batches_certificate_attachment_id_fkey FOREIGN KEY (certificate_attachment_id) REFERENCES public.attachments(id);


--
-- Name: collateral_registration_batches collateral_registration_batches_contract_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_batches
    ADD CONSTRAINT collateral_registration_batches_contract_attachment_id_fkey FOREIGN KEY (contract_attachment_id) REFERENCES public.attachments(id);


--
-- Name: collateral_registration_items collateral_registration_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_items
    ADD CONSTRAINT collateral_registration_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.collateral_registration_batches(id);


--
-- Name: collateral_registration_items collateral_registration_items_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.collateral_registration_items
    ADD CONSTRAINT collateral_registration_items_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.collateral_ledger(id);


--
-- Name: credit_lines credit_lines_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.credit_lines
    ADD CONSTRAINT credit_lines_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id);


--
-- Name: dealer_bank_accounts dealer_bank_accounts_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.dealer_bank_accounts
    ADD CONSTRAINT dealer_bank_accounts_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id);


--
-- Name: import_row_errors import_row_errors_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.import_row_errors
    ADD CONSTRAINT import_row_errors_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_credit_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_credit_line_id_fkey FOREIGN KEY (credit_line_id) REFERENCES public.credit_lines(id);


--
-- Name: purchase_orders purchase_orders_dealer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_dealer_id_fkey FOREIGN KEY (dealer_id) REFERENCES public.dealers(id);


--
-- Name: purchase_orders purchase_orders_evidence_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_evidence_attachment_id_fkey FOREIGN KEY (evidence_attachment_id) REFERENCES public.attachments(id);


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: supplier_bank_accounts supplier_bank_accounts_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.supplier_bank_accounts
    ADD CONSTRAINT supplier_bank_accounts_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: vehicle_units vehicle_units_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.vehicle_units
    ADD CONSTRAINT vehicle_units_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: work_order_actions work_order_actions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.work_order_actions
    ADD CONSTRAINT work_order_actions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.work_orders(id);


--
-- Name: work_orders work_orders_source_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: floorplan
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_source_alert_id_fkey FOREIGN KEY (source_alert_id) REFERENCES public.risk_alerts(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 192N2oB6AKhsJ0tPCT9b2Cpm5djJTUDdZPEkZqIuDOhd8BRRNbNOs5NPm6FjUfM

